"""
AI Mocap Studio - AI-powered motion capture for Blender.
Capture body motion from webcam or video using AI pose estimation.
"""

bl_info = {
    "name": "AI Mocap Studio",
    "author": "AI Mocap Studio Team",
    "version": (1, 0, 0),
    "blender": (3, 6, 0),
    "location": "View3D > Sidebar > AI Mocap",
    "description": "AI-powered motion capture: body, hands, face from webcam or video",
    "category": "Animation",
    "doc_url": "",
    "tracker_url": "",
}

import bpy
from bpy.props import EnumProperty, FloatProperty, StringProperty, BoolProperty, IntProperty

# Module imports
from .preferences import AIMocapPreferences
from .operators import (
    capture_ops, retarget_ops, export_ops, model_ops,
    processing_ops, multicam_ops, multiperson_ops, batch_ops, take_ops,
    streaming_ops,
)
from .ui import panels


# All classes to register
_classes = [
    AIMocapPreferences,
    *capture_ops.classes,
    *retarget_ops.classes,
    *export_ops.classes,
    *model_ops.classes,
    *processing_ops.classes,
    *multicam_ops.classes,
    *multiperson_ops.classes,
    *batch_ops.classes,
    *take_ops.classes,
    *streaming_ops.classes,
    *panels.classes,
]


def _register_scene_properties():
    """Register custom properties on bpy.types.Scene."""
    bpy.types.Scene.aimocap_rig_type = EnumProperty(
        name="Rig Type",
        description="Type of armature rig for retargeting",
        items=[
            ("SIMPLE", "Simple", "Generic humanoid armature"),
            ("RIGIFY", "Rigify", "Blender Rigify metarig"),
            ("MIXAMO", "Mixamo", "Mixamo rigged character"),
            ("AUTO_RIG_PRO", "Auto Rig Pro", "Auto Rig Pro rigged character (FK bones)"),
        ],
        default="SIMPLE",
    )

    bpy.types.Scene.aimocap_scale = FloatProperty(
        name="Mocap Scale",
        description="Scale factor for motion capture data",
        default=1.0,
        min=0.01,
        max=100.0,
        step=10,
    )

    bpy.types.Scene.aimocap_capture_mode = EnumProperty(
        name="Capture Mode",
        description="What to track during capture",
        items=[
            ("BODY", "Body Only", "Track body pose only (33 landmarks)"),
            ("HANDS", "Hands Only", "Track hands only (21 landmarks per hand)"),
            ("FACE", "Face Only", "Track face only (468 landmarks + blendshapes)"),
            ("HOLISTIC", "Holistic", "Track body + hands + face simultaneously"),
        ],
        default="BODY",
    )

    bpy.types.Scene.aimocap_face_mesh = StringProperty(
        name="Face Mesh",
        description="Mesh object to apply face blendshapes to",
        default="",
    )

    bpy.types.Scene.aimocap_multicam_indices = StringProperty(
        name="Camera Indices",
        description="Comma-separated camera device indices (e.g. 0,1,2)",
        default="0,1",
    )

    bpy.types.Scene.aimocap_multicam_sync_tolerance = FloatProperty(
        name="Sync Tolerance",
        description="Maximum timestamp difference (seconds) for frame synchronization",
        default=0.033,
        min=0.001,
        max=0.5,
        step=1,
        precision=3,
    )

    bpy.types.Scene.aimocap_multicam_occlusion_resolve = BoolProperty(
        name="Occlusion Resolution",
        description="Reject views with high reprojection error and re-triangulate",
        default=True,
    )

    # Streaming: Live Link
    bpy.types.Scene.aimocap_livelink_ip = StringProperty(
        name="Live Link IP",
        description="IP address for Live Link UDP stream",
        default="127.0.0.1",
    )
    bpy.types.Scene.aimocap_livelink_port = IntProperty(
        name="Live Link Port",
        description="UDP port for Live Link stream",
        default=11111,
        min=1024,
        max=65535,
    )
    bpy.types.Scene.aimocap_livelink_subject = StringProperty(
        name="Live Link Subject",
        description="Subject name visible in Unreal Engine",
        default="AIMocap",
    )

    # Streaming: VMC
    bpy.types.Scene.aimocap_vmc_ip = StringProperty(
        name="VMC IP",
        description="IP address for VMC protocol stream",
        default="127.0.0.1",
    )
    bpy.types.Scene.aimocap_vmc_port = IntProperty(
        name="VMC Port",
        description="UDP port for VMC protocol stream",
        default=39539,
        min=1024,
        max=65535,
    )
    bpy.types.Scene.aimocap_vmc_blendshapes = BoolProperty(
        name="VMC Blendshapes",
        description="Send ARKit blendshapes via VMC protocol",
        default=True,
    )


def _unregister_scene_properties():
    """Remove custom scene properties."""
    del bpy.types.Scene.aimocap_rig_type
    del bpy.types.Scene.aimocap_scale
    del bpy.types.Scene.aimocap_capture_mode
    del bpy.types.Scene.aimocap_face_mesh
    del bpy.types.Scene.aimocap_multicam_indices
    del bpy.types.Scene.aimocap_multicam_sync_tolerance
    del bpy.types.Scene.aimocap_multicam_occlusion_resolve
    del bpy.types.Scene.aimocap_livelink_ip
    del bpy.types.Scene.aimocap_livelink_port
    del bpy.types.Scene.aimocap_livelink_subject
    del bpy.types.Scene.aimocap_vmc_ip
    del bpy.types.Scene.aimocap_vmc_port
    del bpy.types.Scene.aimocap_vmc_blendshapes


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)
    _register_scene_properties()
    print(f"AI Mocap Studio v{'.'.join(str(v) for v in bl_info['version'])} registered")


def unregister():
    # Stop all running capture sessions before unregistering classes
    from .operators.capture_ops import _capture_state, _cleanup_capture
    from .operators.multicam_ops import _multicam_state, _cleanup_multicam
    from .operators.multiperson_ops import _mp_state, _cleanup_multiperson
    from .ui.viewport_draw import disable_viewport_draw
    from .models.manager import get_model_manager

    try:
        if _capture_state.get("running"):
            _capture_state["running"] = False
            _cleanup_capture(bpy.context)
    except Exception:
        pass

    try:
        if _multicam_state.get("running"):
            _multicam_state["running"] = False
            _cleanup_multicam(bpy.context)
    except Exception:
        pass

    try:
        if _mp_state.get("running"):
            _mp_state["running"] = False
            _cleanup_multiperson(bpy.context)
    except Exception:
        pass

    disable_viewport_draw()
    get_model_manager().release_all()

    # Stop all streaming
    try:
        from .streaming.bridge import stop_all as stop_all_streams
        stop_all_streams()
    except Exception:
        pass

    _unregister_scene_properties()
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
    print("AI Mocap Studio unregistered")


if __name__ == "__main__":
    register()
