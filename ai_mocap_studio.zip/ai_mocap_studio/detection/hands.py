"""
AI Mocap Studio - Hand pose detection using MediaPipe Hands.
21 landmarks per hand with full finger segment tracking.
"""

from ..utils.math_utils import mediapipe_to_blender_coords, smooth_vector
from ..core.constants import MP_HAND_LANDMARK

_mp = None
_mp_hands = None


def _ensure_mediapipe():
    global _mp, _mp_hands
    if _mp_hands is not None:
        return
    import mediapipe as mp
    _mp = mp
    if hasattr(mp, 'solutions') and hasattr(mp.solutions, 'hands'):
        _mp_hands = mp.solutions.hands
    else:
        print("[AI Mocap] Warning: mp.solutions.hands not available in this MediaPipe version.")


class HandDetector:
    """Detects hand landmarks using MediaPipe Hands."""

    def __init__(
        self,
        static_image_mode=False,
        max_num_hands=2,
        model_complexity=1,
        min_detection_confidence=0.5,
        min_tracking_confidence=0.5,
    ):
        _ensure_mediapipe()

        self.hands = _mp_hands.Hands(
            static_image_mode=static_image_mode,
            max_num_hands=max_num_hands,
            model_complexity=model_complexity,
            min_detection_confidence=min_detection_confidence,
            min_tracking_confidence=min_tracking_confidence,
        )
        self._previous_landmarks = {"Left": None, "Right": None}
        self._smoothing_factor = 0.3

    def detect(self, frame):
        """
        Detect hands in a BGR frame.
        Returns list of HandResult or empty list if no hands detected.
        """
        import cv2
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        rgb_frame.flags.writeable = False
        results = self.hands.process(rgb_frame)

        if results.multi_hand_landmarks is None:
            return []

        hand_results = []
        for i, hand_landmarks in enumerate(results.multi_hand_landmarks):
            handedness = "Left"
            if results.multi_handedness and i < len(results.multi_handedness):
                handedness = results.multi_handedness[i].classification[0].label

            hand_results.append(HandResult(
                landmarks=hand_landmarks.landmark,
                handedness=handedness,
            ))

        return hand_results

    def detect_with_smoothing(self, frame, smoothing_factor=0.3):
        """Detect hands and apply temporal smoothing."""
        results = self.detect(frame)
        self._smoothing_factor = smoothing_factor

        for result in results:
            side = result.handedness
            prev = self._previous_landmarks.get(side)

            if prev is not None:
                smoothed = []
                for j, lm in enumerate(result.landmarks):
                    curr_vec = mediapipe_to_blender_coords(lm.x, lm.y, lm.z)
                    prev_vec = mediapipe_to_blender_coords(prev[j].x, prev[j].y, prev[j].z)
                    smoothed.append(smooth_vector(curr_vec, prev_vec, smoothing_factor))
                result._smoothed_positions = smoothed

            self._previous_landmarks[side] = list(result.landmarks)

        return results

    def release(self):
        if getattr(self, 'hands', None):
            self.hands.close()
            self.hands = None

    def __del__(self):
        self.release()


class HandResult:
    """Container for hand detection results."""

    def __init__(self, landmarks, handedness="Left"):
        self.landmarks = landmarks
        self.handedness = handedness  # "Left" or "Right"
        self._smoothed_positions = None

    def get_landmark(self, name):
        """Get a landmark by name from MP_HAND_LANDMARK."""
        idx = MP_HAND_LANDMARK.get(name)
        if idx is not None and idx < len(self.landmarks):
            return self.landmarks[idx]
        return None

    def get_blender_position(self, index, scale=1.0):
        """Get landmark position in Blender coordinate space."""
        if self._smoothed_positions and index < len(self._smoothed_positions):
            return self._smoothed_positions[index] * scale

        if index < len(self.landmarks):
            lm = self.landmarks[index]
            return mediapipe_to_blender_coords(lm.x, lm.y, lm.z, scale)
        return None

    def get_all_blender_positions(self, scale=1.0):
        """Get all landmarks as Blender-space vectors."""
        if self._smoothed_positions:
            return [v * scale for v in self._smoothed_positions]
        return [
            mediapipe_to_blender_coords(lm.x, lm.y, lm.z, scale)
            for lm in self.landmarks
        ]

    def get_finger_curl(self, finger_name):
        """
        Calculate curl amount for a finger (0.0 = straight, 1.0 = fully curled).
        finger_name: 'thumb', 'index', 'middle', 'ring', 'pinky'
        """
        finger_indices = FINGER_LANDMARKS.get(finger_name)
        if finger_indices is None or len(finger_indices) < 4:
            return 0.0

        positions = []
        for idx in finger_indices:
            lm = self.landmarks[idx]
            positions.append(mediapipe_to_blender_coords(lm.x, lm.y, lm.z))

        # Calculate angle between segments
        total_angle = 0.0
        for i in range(len(positions) - 2):
            v1 = positions[i + 1] - positions[i]
            v2 = positions[i + 2] - positions[i + 1]
            if v1.length > 0.0001 and v2.length > 0.0001:
                angle = v1.angle(v2)
                total_angle += angle

        # Normalize: max curl ~pi radians across joints
        import math
        max_curl = math.pi * (len(positions) - 2)
        return min(total_angle / max_curl, 1.0) if max_curl > 0 else 0.0

    def get_finger_spread(self, finger1, finger2):
        """
        Calculate spread between two fingers (angle at MCP joints).
        Returns angle in radians.
        """
        f1_mcp = FINGER_LANDMARKS.get(finger1, [0, 0])[1]
        f2_mcp = FINGER_LANDMARKS.get(finger2, [0, 0])[1]
        wrist_idx = MP_HAND_LANDMARK["WRIST"]

        wrist = mediapipe_to_blender_coords(
            self.landmarks[wrist_idx].x,
            self.landmarks[wrist_idx].y,
            self.landmarks[wrist_idx].z,
        )
        mcp1 = mediapipe_to_blender_coords(
            self.landmarks[f1_mcp].x,
            self.landmarks[f1_mcp].y,
            self.landmarks[f1_mcp].z,
        )
        mcp2 = mediapipe_to_blender_coords(
            self.landmarks[f2_mcp].x,
            self.landmarks[f2_mcp].y,
            self.landmarks[f2_mcp].z,
        )

        v1 = mcp1 - wrist
        v2 = mcp2 - wrist
        if v1.length > 0.0001 and v2.length > 0.0001:
            return v1.angle(v2)
        return 0.0

    @property
    def is_left(self):
        return self.handedness == "Left"

    @property
    def is_right(self):
        return self.handedness == "Right"

    @property
    def num_landmarks(self):
        return len(self.landmarks) if self.landmarks else 0


# Finger landmark indices grouped by finger
FINGER_LANDMARKS = {
    "thumb": [
        MP_HAND_LANDMARK["WRIST"] if "MP_HAND_LANDMARK" in dir() else 0,
        1, 2, 3, 4,  # CMC, MCP, IP, TIP
    ],
    "index": [0, 5, 6, 7, 8],     # WRIST, MCP, PIP, DIP, TIP
    "middle": [0, 9, 10, 11, 12],  # WRIST, MCP, PIP, DIP, TIP
    "ring": [0, 13, 14, 15, 16],   # WRIST, MCP, PIP, DIP, TIP
    "pinky": [0, 17, 18, 19, 20],  # WRIST, MCP, PIP, DIP, TIP
}
