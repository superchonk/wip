"""
AI Mocap Studio - Body pose detection using MediaPipe.
Supports both legacy mp.solutions.pose API and new mp.tasks API (0.10.14+).
"""

from ..utils.math_utils import mediapipe_to_blender_coords, smooth_vector
from ..core.constants import MP_LANDMARK

# Lazy import to avoid issues if mediapipe not installed
_mp = None
_mp_pose = None          # Legacy: mp.solutions.pose (or None)
_use_tasks_api = False   # True when using the new Tasks-based API
_init_done = False


def _ensure_mediapipe():
    global _mp, _mp_pose, _use_tasks_api, _init_done
    if _init_done:
        return
    import mediapipe as mp
    _mp = mp

    # Try legacy API first (mp.solutions.pose)
    try:
        if hasattr(mp, 'solutions') and hasattr(mp.solutions, 'pose'):
            _mp_pose = mp.solutions.pose
            _use_tasks_api = False
            _init_done = True
            return
    except Exception:
        pass

    # Fall back to new Tasks API (mediapipe >= 0.10.14)
    try:
        from mediapipe.tasks.python import vision as _vision
        _use_tasks_api = True
        _init_done = True
    except ImportError:
        _init_done = True
        print("[AI Mocap] Warning: MediaPipe legacy and Tasks API both unavailable. "
              "Try: pip install --upgrade mediapipe")


def _get_task_model_path():
    """Locate or download the pose_landmarker.task model file."""
    from pathlib import Path
    cache_dir = Path.home() / ".ai_mocap_studio" / "models" / "mediapipe"
    cache_dir.mkdir(parents=True, exist_ok=True)
    model_path = cache_dir / "pose_landmarker_lite.task"

    if model_path.exists():
        return str(model_path)

    url = (
        "https://storage.googleapis.com/mediapipe-models/"
        "pose_landmarker/pose_landmarker_lite/float16/latest/"
        "pose_landmarker_lite.task"
    )
    import urllib.request
    try:
        urllib.request.urlretrieve(url, str(model_path))
    except Exception as e:
        print(f"[AI Mocap] Failed to download pose model: {e}")
        return None

    return str(model_path)


class PoseDetector:
    """Detects body pose landmarks using MediaPipe Pose.
    Automatically uses legacy or Tasks API depending on installed version."""

    def __init__(
        self,
        static_image_mode=False,
        model_complexity=1,
        smooth_landmarks=True,
        min_detection_confidence=0.5,
        min_tracking_confidence=0.5,
    ):
        _ensure_mediapipe()

        self.pose = None
        self._landmarker = None
        self._frame_timestamp_ms = 0

        if not _use_tasks_api:
            # Legacy API
            self.pose = _mp_pose.Pose(
                static_image_mode=static_image_mode,
                model_complexity=model_complexity,
                smooth_landmarks=smooth_landmarks,
                min_detection_confidence=min_detection_confidence,
                min_tracking_confidence=min_tracking_confidence,
            )
        else:
            # New Tasks API
            from mediapipe.tasks.python import BaseOptions
            from mediapipe.tasks.python.vision import (
                PoseLandmarker,
                PoseLandmarkerOptions,
                RunningMode,
            )

            task_model = _get_task_model_path()
            if task_model is None:
                print("[AI Mocap] Could not obtain pose model file. Detection disabled.")
            else:
                running_mode = RunningMode.IMAGE if static_image_mode else RunningMode.VIDEO
                options = PoseLandmarkerOptions(
                    base_options=BaseOptions(model_asset_path=task_model),
                    running_mode=running_mode,
                    num_poses=1,
                    min_pose_detection_confidence=min_detection_confidence,
                    min_tracking_confidence=min_tracking_confidence,
                    min_pose_presence_confidence=min_detection_confidence,
                )
                self._landmarker = PoseLandmarker.create_from_options(options)

        self._previous_landmarks = None
        self._smoothing_factor = 0.3

    def detect(self, frame):
        """
        Detect pose in a BGR frame.
        Returns a PoseResult or None if no pose detected.
        """
        import cv2
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        rgb_frame.flags.writeable = False

        if not _use_tasks_api:
            return self._detect_legacy(rgb_frame)
        else:
            return self._detect_tasks(rgb_frame)

    def _detect_legacy(self, rgb_frame):
        """Detect using legacy mp.solutions.pose API."""
        results = self.pose.process(rgb_frame)

        if results.pose_landmarks is None:
            return None

        return PoseResult(
            landmarks=results.pose_landmarks.landmark,
            world_landmarks=(
                results.pose_world_landmarks.landmark
                if results.pose_world_landmarks
                else None
            ),
        )

    def _detect_tasks(self, rgb_frame):
        """Detect using new mediapipe.tasks API."""
        mp_image = _mp.Image(image_format=_mp.ImageFormat.SRGB, data=rgb_frame)
        self._frame_timestamp_ms += 33  # ~30 fps increment

        if self._landmarker is None:
            return None

        try:
            results = self._landmarker.detect_for_video(
                mp_image, self._frame_timestamp_ms
            )
        except Exception:
            # Fallback for IMAGE mode
            try:
                results = self._landmarker.detect(mp_image)
            except Exception:
                return None

        if not results.pose_landmarks:
            return None

        landmarks = results.pose_landmarks[0]
        world_landmarks = (
            results.pose_world_landmarks[0]
            if results.pose_world_landmarks
            else None
        )

        # Wrap Tasks API landmarks to match legacy format
        wrapped_landmarks = [
            _TasksLandmarkWrapper(lm) for lm in landmarks
        ]
        wrapped_world = None
        if world_landmarks:
            wrapped_world = [
                _TasksLandmarkWrapper(lm) for lm in world_landmarks
            ]

        return PoseResult(
            landmarks=wrapped_landmarks,
            world_landmarks=wrapped_world,
        )

    def detect_with_smoothing(self, frame, smoothing_factor=0.3):
        """Detect pose and apply temporal smoothing."""
        result = self.detect(frame)
        if result is None:
            return None

        self._smoothing_factor = smoothing_factor

        if self._previous_landmarks is not None and result.world_landmarks:
            smoothed = []
            for i, lm in enumerate(result.world_landmarks):
                prev = self._previous_landmarks[i]
                curr_vec = mediapipe_to_blender_coords(lm.x, lm.y, lm.z)
                prev_vec = mediapipe_to_blender_coords(prev.x, prev.y, prev.z)
                smoothed_vec = smooth_vector(curr_vec, prev_vec, smoothing_factor)
                smoothed.append(smoothed_vec)
            result._smoothed_positions = smoothed

        if result.world_landmarks:
            self._previous_landmarks = list(result.world_landmarks)

        return result

    def release(self):
        """Release MediaPipe resources."""
        if getattr(self, 'pose', None):
            self.pose.close()
            self.pose = None
        if getattr(self, '_landmarker', None):
            self._landmarker.close()
            self._landmarker = None

    def __del__(self):
        self.release()


class _TasksLandmarkWrapper:
    """Wraps a Tasks API landmark to match the legacy landmark interface
    (attributes: x, y, z, visibility)."""

    def __init__(self, lm):
        self.x = lm.x
        self.y = lm.y
        self.z = lm.z
        self.visibility = getattr(lm, 'visibility', getattr(lm, 'presence', 0.5))


class PoseResult:
    """Container for pose detection results."""

    def __init__(self, landmarks, world_landmarks=None):
        self.landmarks = landmarks  # Normalized screen coordinates
        self.world_landmarks = world_landmarks  # Real-world 3D coordinates (meters)
        self._smoothed_positions = None

    def get_landmark(self, name):
        """Get a landmark by name (from MP_LANDMARK constants)."""
        idx = MP_LANDMARK.get(name)
        if idx is not None and idx < len(self.landmarks):
            return self.landmarks[idx]
        return None

    def get_world_landmark(self, name):
        """Get a world landmark by name."""
        if self.world_landmarks is None:
            return None
        idx = MP_LANDMARK.get(name)
        if idx is not None and idx < len(self.world_landmarks):
            return self.world_landmarks[idx]
        return None

    def get_blender_position(self, index, scale=1.0):
        """Get landmark position in Blender coordinate space."""
        if self._smoothed_positions and index < len(self._smoothed_positions):
            return self._smoothed_positions[index] * scale

        source = self.world_landmarks if self.world_landmarks else self.landmarks
        if source and index < len(source):
            lm = source[index]
            return mediapipe_to_blender_coords(lm.x, lm.y, lm.z, scale)
        return None

    def get_all_blender_positions(self, scale=1.0):
        """Get all landmarks as Blender-space vectors."""
        if self._smoothed_positions:
            return [v * scale for v in self._smoothed_positions]

        source = self.world_landmarks if self.world_landmarks else self.landmarks
        if source is None:
            return []
        return [
            mediapipe_to_blender_coords(lm.x, lm.y, lm.z, scale)
            for lm in source
        ]

    def get_confidence(self, index):
        """Get visibility/confidence for a landmark."""
        if index < len(self.landmarks):
            return self.landmarks[index].visibility
        return 0.0

    @property
    def num_landmarks(self):
        return len(self.landmarks) if self.landmarks else 0
