"""
AI Mocap Studio - Face detection using MediaPipe Face Mesh.
468 landmarks with ARKit blendshape computation.
"""

import math

from ..utils.math_utils import mediapipe_to_blender_coords, smooth_value
from ..core.constants import (
    MP_FACE_LANDMARK,
    ARKIT_BLENDSHAPES,
    FACE_OVAL_INDICES,
    LEFT_EYE_INDICES,
    RIGHT_EYE_INDICES,
    LIPS_OUTER_INDICES,
    LIPS_INNER_INDICES,
)

_mp = None
_mp_face = None


def _ensure_mediapipe():
    global _mp, _mp_face
    if _mp_face is not None:
        return
    import mediapipe as mp
    _mp = mp
    if hasattr(mp, 'solutions') and hasattr(mp.solutions, 'face_mesh'):
        _mp_face = mp.solutions.face_mesh
    else:
        print("[AI Mocap] Warning: mp.solutions.face_mesh not available in this MediaPipe version.")


class FaceDetector:
    """Detects face landmarks using MediaPipe Face Mesh (468 points)."""

    def __init__(
        self,
        static_image_mode=False,
        max_num_faces=1,
        refine_landmarks=True,
        min_detection_confidence=0.5,
        min_tracking_confidence=0.5,
    ):
        _ensure_mediapipe()

        self.face_mesh = _mp_face.FaceMesh(
            static_image_mode=static_image_mode,
            max_num_faces=max_num_faces,
            refine_landmarks=refine_landmarks,
            min_detection_confidence=min_detection_confidence,
            min_tracking_confidence=min_tracking_confidence,
        )
        self._previous_blendshapes = None
        self._smoothing_factor = 0.3

    def detect(self, frame):
        """
        Detect face in a BGR frame.
        Returns list of FaceResult or empty list.
        """
        import cv2
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        rgb_frame.flags.writeable = False
        results = self.face_mesh.process(rgb_frame)

        if results.multi_face_landmarks is None:
            return []

        face_results = []
        for face_landmarks in results.multi_face_landmarks:
            result = FaceResult(landmarks=face_landmarks.landmark)
            result.compute_blendshapes()
            face_results.append(result)

        return face_results

    def detect_with_smoothing(self, frame, smoothing_factor=0.3):
        """Detect face and apply temporal smoothing to blendshapes."""
        results = self.detect(frame)
        self._smoothing_factor = smoothing_factor

        for result in results:
            if self._previous_blendshapes is not None:
                smoothed = {}
                for name, value in result.blendshapes.items():
                    prev = self._previous_blendshapes.get(name, value)
                    smoothed[name] = smooth_value(value, prev, smoothing_factor)
                result.blendshapes = smoothed

            self._previous_blendshapes = dict(result.blendshapes)

        return results

    def release(self):
        if getattr(self, 'face_mesh', None):
            self.face_mesh.close()
            self.face_mesh = None

    def __del__(self):
        self.release()


class FaceResult:
    """Container for face detection results with ARKit blendshape computation."""

    def __init__(self, landmarks):
        self.landmarks = landmarks
        self.blendshapes = {}

    def get_landmark(self, index):
        """Get face landmark by index (0-467)."""
        if index < len(self.landmarks):
            return self.landmarks[index]
        return None

    def get_blender_position(self, index, scale=1.0):
        """Get landmark in Blender coordinate space."""
        if index < len(self.landmarks):
            lm = self.landmarks[index]
            return mediapipe_to_blender_coords(lm.x, lm.y, lm.z, scale)
        return None

    def compute_blendshapes(self):
        """
        Compute ARKit-compatible blendshapes from face landmarks.
        52 blendshapes mapped from 468 landmark positions.
        """
        lm = self.landmarks
        if len(lm) < 468:
            return

        # Helper: distance between two landmarks
        def dist(i, j):
            dx = lm[i].x - lm[j].x
            dy = lm[i].y - lm[j].y
            dz = lm[i].z - lm[j].z
            return math.sqrt(dx*dx + dy*dy + dz*dz)

        # Helper: vertical distance (y-axis)
        def ydist(i, j):
            return abs(lm[i].y - lm[j].y)

        # Helper: horizontal distance (x-axis)
        def xdist(i, j):
            return abs(lm[i].x - lm[j].x)

        # Reference distances for normalization
        face_height = dist(10, 152)  # forehead to chin
        face_width = dist(234, 454)  # left cheek to right cheek

        if face_height < 0.001 or face_width < 0.001:
            return

        # === EYE BLENDSHAPES ===
        # Left eye openness (top to bottom eyelid)
        left_eye_open = ydist(159, 145) / face_height
        right_eye_open = ydist(386, 374) / face_height

        # Eye open reference (calibrated baseline)
        eye_open_ref = 0.04

        self.blendshapes["eyeBlinkLeft"] = max(0.0, min(1.0,
            1.0 - (left_eye_open / eye_open_ref)))
        self.blendshapes["eyeBlinkRight"] = max(0.0, min(1.0,
            1.0 - (right_eye_open / eye_open_ref)))

        # Eye wide
        self.blendshapes["eyeWideLeft"] = max(0.0, min(1.0,
            (left_eye_open / eye_open_ref - 1.0) * 2.0))
        self.blendshapes["eyeWideRight"] = max(0.0, min(1.0,
            (right_eye_open / eye_open_ref - 1.0) * 2.0))

        # Eye squint (lower eyelid raised)
        left_squint = ydist(145, 23) / face_height
        right_squint = ydist(374, 253) / face_height
        squint_ref = 0.06
        self.blendshapes["eyeSquintLeft"] = max(0.0, min(1.0,
            1.0 - left_squint / squint_ref))
        self.blendshapes["eyeSquintRight"] = max(0.0, min(1.0,
            1.0 - right_squint / squint_ref))

        # Eye look directions (iris tracking using refine_landmarks)
        # Landmarks 468-472 are iris landmarks when refine_landmarks=True
        if len(lm) > 472:
            # Left iris center = 468, Left eye corners = 33, 133
            left_iris_x = lm[468].x
            left_eye_left = lm[33].x
            left_eye_right = lm[133].x
            left_eye_width = abs(left_eye_right - left_eye_left)
            if left_eye_width > 0.001:
                left_iris_ratio = (left_iris_x - left_eye_left) / left_eye_width
                self.blendshapes["eyeLookInLeft"] = max(0.0, min(1.0,
                    (left_iris_ratio - 0.5) * 4.0))
                self.blendshapes["eyeLookOutLeft"] = max(0.0, min(1.0,
                    (0.5 - left_iris_ratio) * 4.0))

            left_iris_y = lm[468].y
            left_eye_top = lm[159].y
            left_eye_bottom = lm[145].y
            left_eye_height = abs(left_eye_bottom - left_eye_top)
            if left_eye_height > 0.001:
                left_iris_y_ratio = (left_iris_y - left_eye_top) / left_eye_height
                self.blendshapes["eyeLookUpLeft"] = max(0.0, min(1.0,
                    (0.5 - left_iris_y_ratio) * 4.0))
                self.blendshapes["eyeLookDownLeft"] = max(0.0, min(1.0,
                    (left_iris_y_ratio - 0.5) * 4.0))

            # Right iris center = 473, Right eye corners = 362, 263
            right_iris_x = lm[473].x
            right_eye_left = lm[362].x
            right_eye_right = lm[263].x
            right_eye_width = abs(right_eye_right - right_eye_left)
            if right_eye_width > 0.001:
                right_iris_ratio = (right_iris_x - right_eye_left) / right_eye_width
                self.blendshapes["eyeLookInRight"] = max(0.0, min(1.0,
                    (0.5 - right_iris_ratio) * 4.0))
                self.blendshapes["eyeLookOutRight"] = max(0.0, min(1.0,
                    (right_iris_ratio - 0.5) * 4.0))

            right_iris_y = lm[473].y
            right_eye_top = lm[386].y
            right_eye_bottom = lm[374].y
            right_eye_height = abs(right_eye_bottom - right_eye_top)
            if right_eye_height > 0.001:
                right_iris_y_ratio = (right_iris_y - right_eye_top) / right_eye_height
                self.blendshapes["eyeLookUpRight"] = max(0.0, min(1.0,
                    (0.5 - right_iris_y_ratio) * 4.0))
                self.blendshapes["eyeLookDownRight"] = max(0.0, min(1.0,
                    (right_iris_y_ratio - 0.5) * 4.0))

        # === EYEBROW BLENDSHAPES ===
        # Brow positions relative to eye
        left_brow_height = ydist(105, 159) / face_height
        right_brow_height = ydist(334, 386) / face_height
        brow_ref = 0.06

        self.blendshapes["browDownLeft"] = max(0.0, min(1.0,
            1.0 - left_brow_height / brow_ref))
        self.blendshapes["browDownRight"] = max(0.0, min(1.0,
            1.0 - right_brow_height / brow_ref))

        inner_brow_left = ydist(107, 159) / face_height
        inner_brow_right = ydist(336, 386) / face_height
        self.blendshapes["browInnerUp"] = max(0.0, min(1.0,
            (inner_brow_left + inner_brow_right) / (2.0 * brow_ref) - 0.5))

        outer_brow_left = ydist(70, 159) / face_height
        outer_brow_right = ydist(300, 386) / face_height
        self.blendshapes["browOuterUpLeft"] = max(0.0, min(1.0,
            outer_brow_left / brow_ref - 0.7))
        self.blendshapes["browOuterUpRight"] = max(0.0, min(1.0,
            outer_brow_right / brow_ref - 0.7))

        # === JAW BLENDSHAPES ===
        # Jaw open (distance between upper and lower lip)
        jaw_open = ydist(13, 14) / face_height
        jaw_ref = 0.06
        self.blendshapes["jawOpen"] = max(0.0, min(1.0, jaw_open / jaw_ref))

        # Jaw left/right (chin horizontal displacement)
        chin_x = lm[152].x
        nose_x = lm[1].x
        jaw_lr = (chin_x - nose_x) / face_width
        self.blendshapes["jawLeft"] = max(0.0, min(1.0, jaw_lr * 10.0))
        self.blendshapes["jawRight"] = max(0.0, min(1.0, -jaw_lr * 10.0))

        # Jaw forward
        jaw_z = lm[152].z - lm[1].z
        self.blendshapes["jawForward"] = max(0.0, min(1.0, -jaw_z * 10.0))

        # === MOUTH BLENDSHAPES ===
        # Mouth open/close
        mouth_open_h = ydist(13, 14) / face_height
        self.blendshapes["mouthClose"] = max(0.0, min(1.0,
            1.0 - mouth_open_h / 0.01))

        # Mouth width (smile / pucker)
        mouth_width = xdist(61, 291) / face_width
        mouth_width_ref = 0.28
        self.blendshapes["mouthSmileLeft"] = max(0.0, min(1.0,
            (mouth_width / mouth_width_ref - 1.0) * 2.0))
        self.blendshapes["mouthSmileRight"] = self.blendshapes["mouthSmileLeft"]

        self.blendshapes["mouthPucker"] = max(0.0, min(1.0,
            (1.0 - mouth_width / mouth_width_ref) * 2.0))
        self.blendshapes["mouthFunnel"] = max(0.0, min(1.0,
            mouth_open_h / 0.04 * (1.0 - mouth_width / mouth_width_ref)))

        # Mouth left/right
        mouth_center_x = (lm[61].x + lm[291].x) / 2.0
        mouth_lr = (mouth_center_x - nose_x) / face_width
        self.blendshapes["mouthLeft"] = max(0.0, min(1.0, mouth_lr * 10.0))
        self.blendshapes["mouthRight"] = max(0.0, min(1.0, -mouth_lr * 10.0))

        # Mouth stretch (corner pull)
        left_corner_pull = ydist(61, 13) / face_height
        right_corner_pull = ydist(291, 13) / face_height
        self.blendshapes["mouthStretchLeft"] = max(0.0, min(1.0,
            left_corner_pull / 0.05))
        self.blendshapes["mouthStretchRight"] = max(0.0, min(1.0,
            right_corner_pull / 0.05))

        # Frown
        left_frown = ydist(61, 145) / face_height
        right_frown = ydist(291, 374) / face_height
        frown_ref = 0.08
        self.blendshapes["mouthFrownLeft"] = max(0.0, min(1.0,
            1.0 - left_frown / frown_ref))
        self.blendshapes["mouthFrownRight"] = max(0.0, min(1.0,
            1.0 - right_frown / frown_ref))

        # Upper/lower lip
        upper_lip_raise = ydist(0, 13) / face_height
        lower_lip_depress = ydist(17, 14) / face_height
        self.blendshapes["mouthUpperUpLeft"] = max(0.0, min(1.0,
            upper_lip_raise / 0.03))
        self.blendshapes["mouthUpperUpRight"] = self.blendshapes["mouthUpperUpLeft"]
        self.blendshapes["mouthLowerDownLeft"] = max(0.0, min(1.0,
            lower_lip_depress / 0.04))
        self.blendshapes["mouthLowerDownRight"] = self.blendshapes["mouthLowerDownLeft"]

        # Lip roll
        upper_lip_z = lm[13].z
        lower_lip_z = lm[14].z
        self.blendshapes["mouthRollUpper"] = max(0.0, min(1.0,
            upper_lip_z * 10.0))
        self.blendshapes["mouthRollLower"] = max(0.0, min(1.0,
            lower_lip_z * 10.0))

        # Mouth shrug
        self.blendshapes["mouthShrugUpper"] = max(0.0, min(1.0,
            upper_lip_raise / 0.02 - 0.5))
        self.blendshapes["mouthShrugLower"] = max(0.0, min(1.0,
            lower_lip_depress / 0.03 - 0.5))

        # Dimple
        self.blendshapes["mouthDimpleLeft"] = max(0.0, min(1.0,
            self.blendshapes.get("mouthSmileLeft", 0) * 0.5))
        self.blendshapes["mouthDimpleRight"] = max(0.0, min(1.0,
            self.blendshapes.get("mouthSmileRight", 0) * 0.5))

        # Mouth press
        self.blendshapes["mouthPressLeft"] = max(0.0, min(1.0,
            1.0 - mouth_open_h / 0.005))
        self.blendshapes["mouthPressRight"] = self.blendshapes["mouthPressLeft"]

        # === NOSE BLENDSHAPES ===
        left_nostril = xdist(102, 48) / face_width
        right_nostril = xdist(331, 278) / face_width
        nostril_ref = 0.04
        self.blendshapes["noseSneerLeft"] = max(0.0, min(1.0,
            left_nostril / nostril_ref - 0.5))
        self.blendshapes["noseSneerRight"] = max(0.0, min(1.0,
            right_nostril / nostril_ref - 0.5))

        # === CHEEK BLENDSHAPES ===
        self.blendshapes["cheekPuff"] = max(0.0, min(1.0,
            (face_width / dist(234, 454) - 1.0) * 5.0)) if dist(234, 454) > 0.001 else 0.0
        self.blendshapes["cheekSquintLeft"] = self.blendshapes.get("eyeSquintLeft", 0) * 0.7
        self.blendshapes["cheekSquintRight"] = self.blendshapes.get("eyeSquintRight", 0) * 0.7

        # === TONGUE ===
        # Tongue detection is limited with Face Mesh alone
        self.blendshapes["tongueOut"] = 0.0

        # Fill any missing blendshapes with 0.0
        for name in ARKIT_BLENDSHAPES:
            if name not in self.blendshapes:
                self.blendshapes[name] = 0.0

    def get_head_rotation(self):
        """
        Estimate head rotation (pitch, yaw, roll) from face landmarks.
        Returns (pitch, yaw, roll) in radians.
        """
        lm = self.landmarks
        if len(lm) < 468:
            return (0, 0, 0)

        import numpy as np
        # Use nose tip, chin, and eye corners for rotation estimation
        nose = np.array([lm[1].x, lm[1].y, lm[1].z])
        chin = np.array([lm[152].x, lm[152].y, lm[152].z])
        left_eye = np.array([lm[33].x, lm[33].y, lm[33].z])
        right_eye = np.array([lm[263].x, lm[263].y, lm[263].z])

        # Face up vector (chin to nose direction)
        face_up = nose - chin
        face_up_norm = np.linalg.norm(face_up)
        if face_up_norm > 0.001:
            face_up = face_up / face_up_norm

        # Face right vector
        face_right = right_eye - left_eye
        face_right_norm = np.linalg.norm(face_right)
        if face_right_norm > 0.001:
            face_right = face_right / face_right_norm

        # Pitch (nodding)
        pitch = math.asin(max(-1.0, min(1.0, -face_up[2])))

        # Yaw (turning left/right)
        yaw = math.atan2(face_up[0], face_up[1])

        # Roll (tilting head)
        roll = math.atan2(face_right[1], face_right[0])

        return (pitch, yaw, roll)

    @property
    def num_landmarks(self):
        return len(self.landmarks) if self.landmarks else 0
