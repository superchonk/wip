"""
AI Mocap Studio - Multi-person tracker.

Maintains persistent person IDs across frames using bounding box IoU
and pose similarity matching. Handles person enter/exit events.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple


@dataclass
class TrackedPerson:
    """A tracked person with persistent ID."""
    track_id: int
    bbox: Tuple[float, float, float, float]  # x1, y1, x2, y2
    keypoints: list  # List of Keypoint
    score: float = 0.0
    frames_seen: int = 0
    frames_missing: int = 0
    last_frame: int = -1

    # Smoothed keypoint positions for stability
    smoothed_keypoints: Optional[list] = None


class PersonTracker:
    """
    Track multiple persons across frames.

    Uses Hungarian algorithm (or greedy) matching based on
    bounding box IoU + optional pose similarity.
    """

    def __init__(self, max_missing_frames=10, iou_threshold=0.3,
                 max_persons=10):
        """
        max_missing_frames: frames before a lost track is removed
        iou_threshold: minimum IoU to match a detection to a track
        max_persons: maximum simultaneous tracked persons
        """
        self.max_missing_frames = max_missing_frames
        self.iou_threshold = iou_threshold
        self.max_persons = max_persons

        self._tracks: Dict[int, TrackedPerson] = {}
        self._next_id = 0
        self._current_frame = 0

    @property
    def active_tracks(self) -> Dict[int, TrackedPerson]:
        """All currently active tracks."""
        return {
            tid: t for tid, t in self._tracks.items()
            if t.frames_missing <= self.max_missing_frames
        }

    @property
    def num_tracked(self) -> int:
        return len(self.active_tracks)

    def update(self, detection_result) -> Dict[int, TrackedPerson]:
        """
        Update tracks with new detections.

        detection_result: DetectionResult from model
        Returns: dict {track_id: TrackedPerson} of active tracks
        """
        self._current_frame += 1

        if not detection_result or not detection_result.has_detections:
            # Mark all tracks as missing
            for track in self._tracks.values():
                track.frames_missing += 1
            self._prune_lost_tracks()
            return self.active_tracks

        persons = detection_result.persons
        current_tracks = list(self.active_tracks.values())

        if not current_tracks:
            # No existing tracks — create new ones
            for person in persons[:self.max_persons]:
                self._create_track(person)
            return self.active_tracks

        # Compute cost matrix (IoU-based)
        cost_matrix = self._compute_cost_matrix(current_tracks, persons)

        # Match using greedy assignment
        matched_tracks, matched_dets, unmatched_tracks, unmatched_dets = (
            self._greedy_match(cost_matrix, current_tracks, persons)
        )

        # Update matched tracks
        for track_idx, det_idx in zip(matched_tracks, matched_dets):
            track = current_tracks[track_idx]
            person = persons[det_idx]
            self._update_track(track, person)

        # Mark unmatched tracks as missing
        for track_idx in unmatched_tracks:
            current_tracks[track_idx].frames_missing += 1

        # Create new tracks for unmatched detections
        for det_idx in unmatched_dets:
            if self.num_tracked < self.max_persons:
                self._create_track(persons[det_idx])

        self._prune_lost_tracks()
        return self.active_tracks

    def _compute_cost_matrix(self, tracks, persons):
        """Compute IoU cost matrix between tracks and detections."""
        n_tracks = len(tracks)
        n_dets = len(persons)
        import numpy as np
        cost = np.zeros((n_tracks, n_dets))

        for i, track in enumerate(tracks):
            for j, person in enumerate(persons):
                if track.bbox and person.bbox:
                    iou = _compute_iou(track.bbox, person.bbox)
                    cost[i, j] = iou
                else:
                    # Fallback: use keypoint distance
                    cost[i, j] = self._keypoint_similarity(track, person)

        return cost

    def _keypoint_similarity(self, track, person):
        """Compute similarity between track and detection keypoints."""
        if not track.keypoints or not person.keypoints:
            return 0.0

        n = min(len(track.keypoints), len(person.keypoints))
        if n == 0:
            return 0.0

        total_dist = 0.0
        count = 0
        for k in range(n):
            tk = track.keypoints[k]
            pk = person.keypoints[k]
            import math
            dist = math.sqrt((tk.x - pk.x) ** 2 + (tk.y - pk.y) ** 2)
            total_dist += dist
            count += 1

        if count == 0:
            return 0.0

        avg_dist = total_dist / count
        # Convert distance to similarity (0-1)
        return max(0.0, 1.0 - avg_dist * 5.0)

    def _greedy_match(self, cost_matrix, tracks, persons):
        """Greedy matching: assign best IoU pairs first."""
        n_tracks, n_dets = cost_matrix.shape
        matched_tracks = []
        matched_dets = []

        used_tracks = set()
        used_dets = set()

        # Flatten and sort by cost (highest IoU first)
        pairs = []
        for i in range(n_tracks):
            for j in range(n_dets):
                pairs.append((cost_matrix[i, j], i, j))
        pairs.sort(reverse=True)

        for score, i, j in pairs:
            if i in used_tracks or j in used_dets:
                continue
            if score < self.iou_threshold:
                break
            matched_tracks.append(i)
            matched_dets.append(j)
            used_tracks.add(i)
            used_dets.add(j)

        unmatched_tracks = [i for i in range(n_tracks) if i not in used_tracks]
        unmatched_dets = [j for j in range(n_dets) if j not in used_dets]

        return matched_tracks, matched_dets, unmatched_tracks, unmatched_dets

    def _create_track(self, person):
        """Create a new track from a detection."""
        track = TrackedPerson(
            track_id=self._next_id,
            bbox=person.bbox,
            keypoints=person.keypoints,
            score=person.score,
            frames_seen=1,
            frames_missing=0,
            last_frame=self._current_frame,
        )
        self._tracks[self._next_id] = track
        self._next_id += 1

    def _update_track(self, track, person):
        """Update existing track with new detection."""
        track.bbox = person.bbox
        track.keypoints = person.keypoints
        track.score = person.score
        track.frames_seen += 1
        track.frames_missing = 0
        track.last_frame = self._current_frame

    def _prune_lost_tracks(self):
        """Remove tracks that have been missing too long."""
        to_remove = [
            tid for tid, t in self._tracks.items()
            if t.frames_missing > self.max_missing_frames
        ]
        for tid in to_remove:
            del self._tracks[tid]

    def get_track(self, track_id) -> Optional[TrackedPerson]:
        """Get a specific track by ID."""
        return self._tracks.get(track_id)

    def reset(self):
        """Clear all tracks."""
        self._tracks.clear()
        self._next_id = 0
        self._current_frame = 0


# ============================================================
# Utility
# ============================================================

def _compute_iou(box_a, box_b):
    """Compute Intersection over Union between two bounding boxes."""
    x1 = max(box_a[0], box_b[0])
    y1 = max(box_a[1], box_b[1])
    x2 = min(box_a[2], box_b[2])
    y2 = min(box_a[3], box_b[3])

    intersection = max(0, x2 - x1) * max(0, y2 - y1)
    if intersection == 0:
        return 0.0

    area_a = (box_a[2] - box_a[0]) * (box_a[3] - box_a[1])
    area_b = (box_b[2] - box_b[0]) * (box_b[3] - box_b[1])
    union = area_a + area_b - intersection

    return intersection / max(union, 1e-6)
