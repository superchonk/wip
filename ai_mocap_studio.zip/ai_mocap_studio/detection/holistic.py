"""
AI Mocap Studio - Holistic detection combining body, hands, and face.
Uses MediaPipe Holistic for synchronized multi-modal tracking.
Supports both legacy mp.solutions.holistic API and fallback to separate detectors.
"""

from ..utils.math_utils import mediapipe_to_blender_coords, smooth_vector, smooth_value
from ..core.constants import MP_LANDMARK, MP_HAND_LANDMARK

_mp = None
_mp_holistic = None
_use_legacy = False
_init_done = False


def _ensure_mediapipe():
    global _mp, _mp_holistic, _use_legacy, _init_done
    if _init_done:
        return
    import mediapipe as mp
    _mp = mp

    # Try legacy API (mp.solutions.holistic)
    try:
        if hasattr(mp, 'solutions') and hasattr(mp.solutions, 'holistic'):
            _mp_holistic = mp.solutions.holistic
            _use_legacy = True
            _init_done = True
            return
    except Exception:
        pass

    # No holistic in Tasks API — will fall back to body-only via PoseDetector
    _use_legacy = False
    _init_done = True


class HolisticDetector:
    """
    Combined body + hands + face detection using MediaPipe Holistic.
    On newer MediaPipe versions without mp.solutions, falls back to body-only
    detection via PoseDetector (Tasks API).
    """

    def __init__(
        self,
        static_image_mode=False,
        model_complexity=1,
        smooth_landmarks=True,
        enable_segmentation=False,
        min_detection_confidence=0.5,
        min_tracking_confidence=0.5,
    ):
        _ensure_mediapipe()

        self.holistic = None
        self._body_fallback = None

        if _use_legacy:
            self.holistic = _mp_holistic.Holistic(
                static_image_mode=static_image_mode,
                model_complexity=model_complexity,
                smooth_landmarks=smooth_landmarks,
                enable_segmentation=enable_segmentation,
                min_detection_confidence=min_detection_confidence,
                min_tracking_confidence=min_tracking_confidence,
            )
        else:
            # Fall back to PoseDetector (supports Tasks API)
            from .body import PoseDetector
            self._body_fallback = PoseDetector(
                static_image_mode=static_image_mode,
                model_complexity=model_complexity,
                smooth_landmarks=smooth_landmarks,
                min_detection_confidence=min_detection_confidence,
                min_tracking_confidence=min_tracking_confidence,
            )

        self._prev_body = None
        self._prev_left_hand = None
        self._prev_right_hand = None
        self._prev_face_blendshapes = None

    def detect(self, frame):
        """
        Detect body, hands, and face in a single BGR frame.
        Returns a HolisticResult.
        """
        if _use_legacy:
            return self._detect_legacy(frame)
        else:
            return self._detect_fallback(frame)

    def _detect_legacy(self, frame):
        """Detect using legacy mp.solutions.holistic."""
        import cv2
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        rgb_frame.flags.writeable = False
        results = self.holistic.process(rgb_frame)

        return HolisticResult(
            pose_landmarks=results.pose_landmarks,
            pose_world_landmarks=results.pose_world_landmarks,
            left_hand_landmarks=results.left_hand_landmarks,
            right_hand_landmarks=results.right_hand_landmarks,
            face_landmarks=results.face_landmarks,
        )

    def _detect_fallback(self, frame):
        """Fallback: use PoseDetector for body only (no hands/face)."""
        result = self._body_fallback.detect(frame)
        if result is None:
            return HolisticResult()

        # Wrap PoseResult into HolisticResult (body only)
        return HolisticResult(
            _pose_result=result,
        )

    def detect_with_smoothing(self, frame, smoothing_factor=0.3):
        """Detect holistic and apply temporal smoothing."""
        result = self.detect(frame)

        # Smooth body
        if result.has_pose and result.pose_world_landmarks:
            if self._prev_body is not None:
                smoothed = []
                for i, lm in enumerate(result.pose_world_landmarks.landmark):
                    curr = mediapipe_to_blender_coords(lm.x, lm.y, lm.z)
                    prev_lm = self._prev_body.landmark[i]
                    prev = mediapipe_to_blender_coords(prev_lm.x, prev_lm.y, prev_lm.z)
                    smoothed.append(smooth_vector(curr, prev, smoothing_factor))
                result._smoothed_body = smoothed
            self._prev_body = result.pose_world_landmarks

        # Smooth left hand
        if result.has_left_hand:
            if self._prev_left_hand is not None:
                smoothed = []
                for i, lm in enumerate(result.left_hand_landmarks.landmark):
                    curr = mediapipe_to_blender_coords(lm.x, lm.y, lm.z)
                    prev_lm = self._prev_left_hand.landmark[i]
                    prev = mediapipe_to_blender_coords(prev_lm.x, prev_lm.y, prev_lm.z)
                    smoothed.append(smooth_vector(curr, prev, smoothing_factor))
                result._smoothed_left_hand = smoothed
            self._prev_left_hand = result.left_hand_landmarks

        # Smooth right hand
        if result.has_right_hand:
            if self._prev_right_hand is not None:
                smoothed = []
                for i, lm in enumerate(result.right_hand_landmarks.landmark):
                    curr = mediapipe_to_blender_coords(lm.x, lm.y, lm.z)
                    prev_lm = self._prev_right_hand.landmark[i]
                    prev = mediapipe_to_blender_coords(prev_lm.x, prev_lm.y, prev_lm.z)
                    smoothed.append(smooth_vector(curr, prev, smoothing_factor))
                result._smoothed_right_hand = smoothed
            self._prev_right_hand = result.right_hand_landmarks

        return result

    def release(self):
        if getattr(self, 'holistic', None):
            self.holistic.close()
            self.holistic = None
        if getattr(self, '_body_fallback', None):
            self._body_fallback.release()
            self._body_fallback = None

    def __del__(self):
        self.release()


class _LandmarkListWrapper:
    """Wraps a list of landmarks to look like MediaPipe's NormalizedLandmarkList."""

    def __init__(self, landmarks):
        self.landmark = landmarks


class HolisticResult:
    """Container for combined holistic detection results."""

    def __init__(
        self,
        pose_landmarks=None,
        pose_world_landmarks=None,
        left_hand_landmarks=None,
        right_hand_landmarks=None,
        face_landmarks=None,
        _pose_result=None,
    ):
        if _pose_result is not None:
            # Wrap PoseResult from fallback detector
            self.pose_landmarks = (
                _LandmarkListWrapper(_pose_result.landmarks)
                if _pose_result.landmarks else None
            )
            self.pose_world_landmarks = (
                _LandmarkListWrapper(_pose_result.world_landmarks)
                if _pose_result.world_landmarks else None
            )
            self.left_hand_landmarks = None
            self.right_hand_landmarks = None
            self.face_landmarks = None
        else:
            self.pose_landmarks = pose_landmarks
            self.pose_world_landmarks = pose_world_landmarks
            self.left_hand_landmarks = left_hand_landmarks
            self.right_hand_landmarks = right_hand_landmarks
            self.face_landmarks = face_landmarks

        # Smoothed data (set by detect_with_smoothing)
        self._smoothed_body = None
        self._smoothed_left_hand = None
        self._smoothed_right_hand = None

        # Face blendshapes (computed on demand)
        self._face_blendshapes = None

    # === POSE (BODY) ===

    @property
    def has_pose(self):
        return self.pose_landmarks is not None

    def get_body_positions(self, scale=1.0):
        """Get body landmarks in Blender coordinate space."""
        if self._smoothed_body:
            return [v * scale for v in self._smoothed_body]

        source = self.pose_world_landmarks or self.pose_landmarks
        if source is None:
            return []
        return [
            mediapipe_to_blender_coords(lm.x, lm.y, lm.z, scale)
            for lm in source.landmark
        ]

    def get_body_confidences(self):
        """Get visibility/confidence for each body landmark."""
        if self.pose_landmarks is None:
            return []
        return [lm.visibility for lm in self.pose_landmarks.landmark]

    # === HANDS ===

    @property
    def has_left_hand(self):
        return self.left_hand_landmarks is not None

    @property
    def has_right_hand(self):
        return self.right_hand_landmarks is not None

    @property
    def has_hands(self):
        return self.has_left_hand or self.has_right_hand

    def get_left_hand_positions(self, scale=1.0):
        """Get left hand landmarks in Blender coordinate space."""
        if self._smoothed_left_hand:
            return [v * scale for v in self._smoothed_left_hand]
        if self.left_hand_landmarks is None:
            return []
        return [
            mediapipe_to_blender_coords(lm.x, lm.y, lm.z, scale)
            for lm in self.left_hand_landmarks.landmark
        ]

    def get_right_hand_positions(self, scale=1.0):
        """Get right hand landmarks in Blender coordinate space."""
        if self._smoothed_right_hand:
            return [v * scale for v in self._smoothed_right_hand]
        if self.right_hand_landmarks is None:
            return []
        return [
            mediapipe_to_blender_coords(lm.x, lm.y, lm.z, scale)
            for lm in self.right_hand_landmarks.landmark
        ]

    def get_finger_curl(self, hand_side, finger_name):
        """
        Get curl amount for a finger.
        hand_side: 'left' or 'right'
        finger_name: 'thumb', 'index', 'middle', 'ring', 'pinky'
        """
        import math
        from .hands import FINGER_LANDMARKS

        if hand_side == "left":
            hand_lm = self.left_hand_landmarks
        else:
            hand_lm = self.right_hand_landmarks

        if hand_lm is None:
            return 0.0

        finger_indices = FINGER_LANDMARKS.get(finger_name)
        if finger_indices is None:
            return 0.0

        positions = []
        for idx in finger_indices:
            if idx < len(hand_lm.landmark):
                lm = hand_lm.landmark[idx]
                positions.append(mediapipe_to_blender_coords(lm.x, lm.y, lm.z))

        if len(positions) < 3:
            return 0.0

        total_angle = 0.0
        for i in range(len(positions) - 2):
            v1 = positions[i + 1] - positions[i]
            v2 = positions[i + 2] - positions[i + 1]
            if v1.length > 0.0001 and v2.length > 0.0001:
                total_angle += v1.angle(v2)

        max_curl = math.pi * (len(positions) - 2)
        return min(total_angle / max_curl, 1.0) if max_curl > 0 else 0.0

    # === FACE ===

    @property
    def has_face(self):
        return self.face_landmarks is not None

    def get_face_positions(self, scale=1.0):
        """Get face landmarks in Blender coordinate space."""
        if self.face_landmarks is None:
            return []
        return [
            mediapipe_to_blender_coords(lm.x, lm.y, lm.z, scale)
            for lm in self.face_landmarks.landmark
        ]

    def get_face_blendshapes(self):
        """
        Compute ARKit blendshapes from face landmarks.
        Returns dict of blendshape_name -> value (0.0-1.0).
        """
        if self._face_blendshapes is not None:
            return self._face_blendshapes

        if self.face_landmarks is None:
            return {}

        from .face import FaceResult
        face_result = FaceResult(landmarks=self.face_landmarks.landmark)
        face_result.compute_blendshapes()
        self._face_blendshapes = face_result.blendshapes
        return self._face_blendshapes

    def get_head_rotation(self):
        """Get head rotation (pitch, yaw, roll) from face landmarks."""
        if self.face_landmarks is None:
            return (0, 0, 0)

        from .face import FaceResult
        face_result = FaceResult(landmarks=self.face_landmarks.landmark)
        return face_result.get_head_rotation()

    # === SUMMARY ===

    @property
    def detected_components(self):
        """Return list of detected components."""
        components = []
        if self.has_pose:
            components.append("body")
        if self.has_left_hand:
            components.append("left_hand")
        if self.has_right_hand:
            components.append("right_hand")
        if self.has_face:
            components.append("face")
        return components

    @property
    def is_empty(self):
        return not self.has_pose and not self.has_hands and not self.has_face
