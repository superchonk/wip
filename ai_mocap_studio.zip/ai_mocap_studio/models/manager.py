"""
AI Mocap Studio - Model manager: download, cache, load, and switch between AI models.
"""

import os
import sys
import json
import hashlib
import platform
import shutil
from pathlib import Path
from typing import Optional, Dict, List, Tuple

from .base import BasePoseModel


# ============================================================
# Model registry — all available models and their metadata
# ============================================================

MODEL_REGISTRY = {
    "mediapipe": {
        "name": "MediaPipe Pose",
        "description": "Google MediaPipe — fast, CPU-friendly, 33 keypoints",
        "class": "models.mediapipe_model.MediaPipePoseModel",
        "supports_gpu": False,
        "supports_multi_person": False,
        "supports_3d": True,
        "num_keypoints": 33,
        "speed": "fast",
        "accuracy": "medium",
        "requires_download": False,
        "dependencies": ["mediapipe"],
    },
    "yolo_pose": {
        "name": "YOLO-Pose",
        "description": "Ultralytics YOLO — fast multi-person, 17 COCO keypoints",
        "class": "models.yolo_model.YoloPoseModel",
        "supports_gpu": True,
        "supports_multi_person": True,
        "supports_3d": False,
        "num_keypoints": 17,
        "speed": "very_fast",
        "accuracy": "high",
        "requires_download": True,
        "model_variants": {
            "yolo11n-pose": {
                "description": "Nano — fastest, lower accuracy",
                "url": "",  # Downloaded via ultralytics package
                "size_mb": 6,
            },
            "yolo11s-pose": {
                "description": "Small — balanced speed/accuracy",
                "url": "",
                "size_mb": 23,
            },
            "yolo11m-pose": {
                "description": "Medium — higher accuracy",
                "url": "",
                "size_mb": 51,
            },
            "yolo11l-pose": {
                "description": "Large — best accuracy",
                "url": "",
                "size_mb": 87,
            },
        },
        "default_variant": "yolo11s-pose",
        "dependencies": ["ultralytics"],
    },
    "motionbert": {
        "name": "MotionBERT",
        "description": "2D→3D pose lifting — SOTA 3D accuracy, temporal consistency",
        "class": "models.motionbert_model.MotionBERTModel",
        "supports_gpu": True,
        "supports_multi_person": False,
        "supports_3d": True,
        "num_keypoints": 17,
        "speed": "medium",
        "accuracy": "very_high",
        "requires_download": True,
        "onnx_model": {
            "filename": "motionbert_lite.onnx",
            "size_mb": 60,
        },
        "dependencies": ["onnxruntime"],
    },
}


# ============================================================
# GPU detection
# ============================================================

def detect_gpu() -> Dict:
    """Detect available GPU and compute capabilities."""
    info = {
        "cuda_available": False,
        "metal_available": False,
        "gpu_name": "None",
        "vram_mb": 0,
        "recommended_device": "cpu",
        "onnx_providers": ["CPUExecutionProvider"],
    }

    # Check CUDA
    try:
        import torch
        if torch.cuda.is_available():
            info["cuda_available"] = True
            info["gpu_name"] = torch.cuda.get_device_name(0)
            props = torch.cuda.get_device_properties(0)
            # PyTorch uses 'total_memory', not 'total_mem'
            info["vram_mb"] = props.total_memory // (1024 * 1024)
            info["recommended_device"] = "cuda"
            info["onnx_providers"] = ["CUDAExecutionProvider", "CPUExecutionProvider"]
    except ImportError:
        pass
    except Exception:
        # CUDA detected but property query failed — mark as available anyway
        info["cuda_available"] = True
        info["recommended_device"] = "cuda"
        info["onnx_providers"] = ["CUDAExecutionProvider", "CPUExecutionProvider"]

    # Check Metal (macOS)
    if platform.system() == "Darwin":
        try:
            import torch
            if hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
                info["metal_available"] = True
                info["gpu_name"] = "Apple Silicon GPU"
                info["recommended_device"] = "mps"
        except ImportError:
            pass

        # CoreML provider for ONNX
        try:
            import onnxruntime as ort
            providers = ort.get_available_providers()
            if "CoreMLExecutionProvider" in providers:
                info["onnx_providers"] = ["CoreMLExecutionProvider", "CPUExecutionProvider"]
                if not info["cuda_available"]:
                    info["recommended_device"] = "coreml"
        except ImportError:
            pass

    # Check ONNX Runtime GPU providers
    try:
        import onnxruntime as ort
        available = ort.get_available_providers()
        if "CUDAExecutionProvider" in available:
            info["onnx_providers"] = ["CUDAExecutionProvider", "CPUExecutionProvider"]
        elif "CoreMLExecutionProvider" in available:
            info["onnx_providers"] = ["CoreMLExecutionProvider", "CPUExecutionProvider"]
        elif "DmlExecutionProvider" in available:  # DirectML (Windows)
            info["onnx_providers"] = ["DmlExecutionProvider", "CPUExecutionProvider"]
            info["recommended_device"] = "directml"
    except ImportError:
        pass

    return info


# ============================================================
# Model manager
# ============================================================

class ModelManager:
    """Manages AI model lifecycle: download, cache, load, switch."""

    def __init__(self, cache_dir: Optional[str] = None):
        if cache_dir:
            self._cache_dir = Path(cache_dir)
        else:
            # Default: ~/.ai_mocap_studio/models/
            self._cache_dir = Path.home() / ".ai_mocap_studio" / "models"

        self._cache_dir.mkdir(parents=True, exist_ok=True)
        self._loaded_models: Dict[str, BasePoseModel] = {}
        self._active_model: Optional[str] = None
        self._gpu_info = None

    @property
    def cache_dir(self):
        return self._cache_dir

    @property
    def gpu_info(self):
        if self._gpu_info is None:
            self._gpu_info = detect_gpu()
        return self._gpu_info

    @property
    def active_model_name(self):
        return self._active_model

    @property
    def active_model(self) -> Optional[BasePoseModel]:
        if self._active_model:
            return self._loaded_models.get(self._active_model)
        return None

    # ---- Registry queries ----

    def get_available_models(self) -> List[Dict]:
        """Return list of all registered models with their metadata."""
        models = []
        for model_id, meta in MODEL_REGISTRY.items():
            models.append({
                "id": model_id,
                "name": meta["name"],
                "description": meta["description"],
                "supports_gpu": meta["supports_gpu"],
                "supports_multi_person": meta["supports_multi_person"],
                "supports_3d": meta["supports_3d"],
                "speed": meta.get("speed", "medium"),
                "accuracy": meta.get("accuracy", "medium"),
                "is_loaded": model_id in self._loaded_models,
                "is_active": model_id == self._active_model,
                "is_downloaded": self._is_model_downloaded(model_id),
                "requires_download": meta.get("requires_download", False),
            })
        return models

    def get_model_info(self, model_id: str) -> Optional[Dict]:
        """Get detailed info for a specific model."""
        return MODEL_REGISTRY.get(model_id)

    # ---- Download & cache ----

    def _is_model_downloaded(self, model_id: str) -> bool:
        """Check if a model's files are cached locally."""
        meta = MODEL_REGISTRY.get(model_id)
        if meta is None:
            return False

        if not meta.get("requires_download", False):
            return True  # Built-in (e.g., MediaPipe)

        # Check for ONNX model file
        if "onnx_model" in meta:
            model_path = self._cache_dir / model_id / meta["onnx_model"]["filename"]
            return model_path.exists()

        # For ultralytics models, check if package is installed
        if model_id == "yolo_pose":
            try:
                import ultralytics
                return True
            except ImportError:
                return False

        return False

    def get_model_path(self, model_id: str, variant: Optional[str] = None) -> Path:
        """Get the local path for a model's files."""
        model_dir = self._cache_dir / model_id
        model_dir.mkdir(parents=True, exist_ok=True)

        meta = MODEL_REGISTRY.get(model_id, {})

        if "onnx_model" in meta:
            return model_dir / meta["onnx_model"]["filename"]

        if variant:
            return model_dir / f"{variant}.pt"

        default_variant = meta.get("default_variant", "")
        if default_variant:
            return model_dir / f"{default_variant}.pt"

        return model_dir

    def download_model(self, model_id: str, variant: Optional[str] = None,
                       progress_callback=None) -> Tuple[bool, str]:
        """
        Download model files if needed.
        progress_callback: callable(downloaded_bytes, total_bytes)
        Returns (success, message).
        """
        meta = MODEL_REGISTRY.get(model_id)
        if meta is None:
            return False, f"Unknown model: {model_id}"

        if not meta.get("requires_download", False):
            return True, "Model does not require download"

        if self._is_model_downloaded(model_id):
            return True, "Model already downloaded"

        # For YOLO — just ensure ultralytics is installed, it downloads on first use
        if model_id == "yolo_pose":
            try:
                import ultralytics
                return True, "Ultralytics package found; model downloads on first use"
            except ImportError:
                return False, "Install ultralytics package first: pip install ultralytics"

        # For ONNX models — download from URL
        if "onnx_model" in meta:
            url = meta["onnx_model"].get("url", "")
            if not url:
                model_path = self.get_model_path(model_id)
                model_path.parent.mkdir(parents=True, exist_ok=True)
                return False, (
                    f"MotionBERT ONNX model not found.\n"
                    f"This model requires manual download:\n"
                    f"1. Download motionbert_lite.onnx from the MotionBERT repository\n"
                    f"2. Place it at: {model_path}\n\n"
                    f"Alternatively, use MediaPipe (built-in, no download needed) "
                    f"which already provides good 3D pose estimation."
                )

            return self._download_file(url, self.get_model_path(model_id), progress_callback)

        return False, "Download not implemented for this model"

    def _download_file(self, url: str, dest: Path,
                       progress_callback=None) -> Tuple[bool, str]:
        """Download a file from URL to local path."""
        import urllib.request

        dest.parent.mkdir(parents=True, exist_ok=True)
        tmp_path = dest.with_suffix(".tmp")

        try:
            def reporthook(block_num, block_size, total_size):
                if progress_callback and total_size > 0:
                    downloaded = block_num * block_size
                    progress_callback(downloaded, total_size)

            urllib.request.urlretrieve(url, str(tmp_path), reporthook=reporthook)
            shutil.move(str(tmp_path), str(dest))
            return True, f"Downloaded to {dest}"

        except Exception as e:
            if tmp_path.exists():
                tmp_path.unlink()
            return False, f"Download failed: {e}"

    # ---- Loading ----

    def load_model(self, model_id: str, use_gpu: bool = True,
                   variant: Optional[str] = None) -> Tuple[bool, str]:
        """
        Load a model into memory.
        Returns (success, message).
        """
        if model_id in self._loaded_models:
            self._active_model = model_id
            return True, f"{model_id} already loaded, set as active"

        meta = MODEL_REGISTRY.get(model_id)
        if meta is None:
            return False, f"Unknown model: {model_id}"

        # Check dependencies
        for dep in meta.get("dependencies", []):
            try:
                __import__(dep)
            except ImportError:
                return False, f"Missing dependency: {dep}. Install it first."

        # Instantiate model
        model = self._create_model_instance(model_id, variant)
        if model is None:
            return False, f"Failed to create model instance for {model_id}"

        # Determine GPU usage
        should_use_gpu = use_gpu and meta.get("supports_gpu", False)
        if should_use_gpu:
            gpu = self.gpu_info
            if not (gpu["cuda_available"] or gpu["metal_available"]
                    or "CoreMLExecutionProvider" in gpu.get("onnx_providers", [])
                    or "DmlExecutionProvider" in gpu.get("onnx_providers", [])):
                should_use_gpu = False

        # Ensure model is downloaded before loading
        if meta.get("requires_download", False) and not self._is_model_downloaded(model_id):
            dl_ok, dl_msg = self.download_model(model_id, variant)
            if not dl_ok:
                return False, dl_msg

        # Load
        model_path = str(self.get_model_path(model_id, variant))
        try:
            success = model.load(model_path=model_path, use_gpu=should_use_gpu)
        except Exception as e:
            return False, f"Failed to load {model_id}: {e}"

        if not success:
            return False, f"Model {model_id} failed to initialize"

        self._loaded_models[model_id] = model
        self._active_model = model_id

        device_str = model.device if hasattr(model, 'device') else "cpu"
        return True, f"Loaded {meta['name']} on {device_str}"

    def _create_model_instance(self, model_id: str, variant=None) -> Optional[BasePoseModel]:
        """Create model instance from registry class path."""
        if model_id == "mediapipe":
            from .mediapipe_model import MediaPipePoseModel
            return MediaPipePoseModel()

        elif model_id == "yolo_pose":
            from .yolo_model import YoloPoseModel
            v = variant or MODEL_REGISTRY["yolo_pose"].get("default_variant", "yolo11s-pose")
            return YoloPoseModel(variant=v)

        elif model_id == "motionbert":
            from .motionbert_model import MotionBERTModel
            return MotionBERTModel()

        return None

    def unload_model(self, model_id: str):
        """Unload a model from memory."""
        model = self._loaded_models.pop(model_id, None)
        if model:
            model.release()
        if self._active_model == model_id:
            self._active_model = None

    def set_active(self, model_id: str) -> bool:
        """Set the active model (must already be loaded)."""
        if model_id in self._loaded_models:
            self._active_model = model_id
            return True
        return False

    def detect(self, frame):
        """Run detection using the active model."""
        model = self.active_model
        if model is None:
            return None
        return model.detect(frame)

    def release_all(self):
        """Release all loaded models."""
        for model in self._loaded_models.values():
            model.release()
        self._loaded_models.clear()
        self._active_model = None

    # ---- Disk usage ----

    def get_cache_size_mb(self) -> float:
        """Return total size of cached models in MB."""
        total = 0
        for f in self._cache_dir.rglob("*"):
            if f.is_file():
                total += f.stat().st_size
        return total / (1024 * 1024)

    def clear_cache(self, model_id: Optional[str] = None):
        """Clear cached model files."""
        if model_id:
            model_dir = self._cache_dir / model_id
            if model_dir.exists():
                shutil.rmtree(model_dir)
        else:
            if self._cache_dir.exists():
                shutil.rmtree(self._cache_dir)
                self._cache_dir.mkdir(parents=True, exist_ok=True)


# Singleton instance
_manager_instance = None


def get_model_manager() -> ModelManager:
    """Get the global ModelManager singleton."""
    global _manager_instance
    if _manager_instance is None:
        _manager_instance = ModelManager()
    return _manager_instance
