"""
AI Mocap Studio - MediaPipe pose model wrapped in the unified BasePoseModel interface.
Supports both the legacy mp.solutions.pose API and the new mp.tasks API (0.10.14+).
"""

import os
from typing import Optional
from pathlib import Path

from .base import BasePoseModel, DetectionResult, PersonPose, Keypoint

# Lazy-loaded module references
_mp = None
_mp_pose = None          # Legacy: mp.solutions.pose (or None if unavailable)
_use_tasks_api = False   # True when using the new Tasks-based API


def _ensure_mediapipe():
    """Import mediapipe and determine which API is available."""
    global _mp, _mp_pose, _use_tasks_api
    if _mp is not None:
        return

    import mediapipe as mp
    _mp = mp

    # Try legacy API first (mp.solutions.pose)
    try:
        if hasattr(mp, 'solutions') and hasattr(mp.solutions, 'pose'):
            _mp_pose = mp.solutions.pose
            _use_tasks_api = False
            return
    except Exception:
        pass

    # Fall back to new Tasks API (mediapipe >= 0.10.14)
    try:
        from mediapipe.tasks.python import vision as _vision
        _use_tasks_api = True
    except ImportError:
        raise ImportError(
            "MediaPipe is installed but neither the legacy (mp.solutions.pose) "
            "nor the new Tasks API (mediapipe.tasks) is available. "
            "Try: pip install --upgrade mediapipe"
        )


def _get_task_model_path() -> str:
    """Locate or download the pose_landmarker.task model file for the Tasks API."""
    cache_dir = Path.home() / ".ai_mocap_studio" / "models" / "mediapipe"
    cache_dir.mkdir(parents=True, exist_ok=True)
    model_path = cache_dir / "pose_landmarker_lite.task"

    if model_path.exists():
        return str(model_path)

    # Download from Google's model repository
    url = (
        "https://storage.googleapis.com/mediapipe-models/"
        "pose_landmarker/pose_landmarker_lite/float16/latest/"
        "pose_landmarker_lite.task"
    )
    import urllib.request
    try:
        urllib.request.urlretrieve(url, str(model_path))
    except Exception as e:
        raise RuntimeError(
            f"Failed to download MediaPipe pose model from {url}: {e}\n"
            f"Download it manually and place at: {model_path}"
        )

    return str(model_path)


class MediaPipePoseModel(BasePoseModel):
    """MediaPipe Pose wrapped in the unified model interface."""

    MODEL_NAME = "mediapipe"
    MODEL_DESCRIPTION = "Google MediaPipe Pose — fast, CPU-friendly, 33 keypoints"
    SUPPORTS_GPU = False
    SUPPORTS_MULTI_PERSON = False
    SUPPORTS_3D = True
    NUM_KEYPOINTS = 33

    def __init__(self, model_complexity=1, smooth=True):
        super().__init__()
        self._model_complexity = model_complexity
        self._smooth = smooth
        self._pose = None           # Legacy Pose object
        self._landmarker = None     # Tasks API PoseLandmarker
        self._min_detection_confidence = 0.5
        self._min_tracking_confidence = 0.5
        self._frame_timestamp_ms = 0

    def load(self, model_path: Optional[str] = None, use_gpu: bool = False):
        _ensure_mediapipe()

        if not _use_tasks_api:
            # Legacy API
            self._pose = _mp_pose.Pose(
                static_image_mode=False,
                model_complexity=self._model_complexity,
                smooth_landmarks=self._smooth,
                min_detection_confidence=self._min_detection_confidence,
                min_tracking_confidence=self._min_tracking_confidence,
            )
        else:
            # New Tasks API
            from mediapipe.tasks.python import BaseOptions
            from mediapipe.tasks.python.vision import (
                PoseLandmarker,
                PoseLandmarkerOptions,
                RunningMode,
            )

            task_model = _get_task_model_path()
            options = PoseLandmarkerOptions(
                base_options=BaseOptions(model_asset_path=task_model),
                running_mode=RunningMode.VIDEO,
                num_poses=1,
                min_pose_detection_confidence=self._min_detection_confidence,
                min_tracking_confidence=self._min_tracking_confidence,
                min_pose_presence_confidence=self._min_detection_confidence,
            )
            self._landmarker = PoseLandmarker.create_from_options(options)
            self._frame_timestamp_ms = 0

        self._is_loaded = True
        self._device = "cpu"
        return True

    def set_confidence(self, detection=0.5, tracking=0.5):
        """Set confidence thresholds. Must be called before load()."""
        self._min_detection_confidence = detection
        self._min_tracking_confidence = tracking

    def detect(self, frame) -> DetectionResult:
        if not self._is_loaded:
            return DetectionResult()

        import time
        import cv2

        t0 = time.perf_counter()
        h, w = frame.shape[:2]
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

        if not _use_tasks_api:
            return self._detect_legacy(rgb, w, h, t0)
        else:
            return self._detect_tasks(rgb, w, h, t0)

    # ---- Legacy API (mp.solutions.pose) ----

    def _detect_legacy(self, rgb, w, h, t0) -> DetectionResult:
        import time

        rgb.flags.writeable = False
        results = self._pose.process(rgb)
        elapsed = (time.perf_counter() - t0) * 1000.0

        if results.pose_landmarks is None:
            return DetectionResult(frame_width=w, frame_height=h,
                                   inference_time_ms=elapsed)

        keypoints = []
        world = results.pose_world_landmarks
        for i, lm in enumerate(results.pose_landmarks.landmark):
            if world and i < len(world.landmark):
                wlm = world.landmark[i]
                keypoints.append(Keypoint(
                    x=wlm.x, y=wlm.y, z=wlm.z,
                    confidence=lm.visibility,
                ))
            else:
                keypoints.append(Keypoint(
                    x=lm.x, y=lm.y, z=lm.z,
                    confidence=lm.visibility,
                ))

        person = PersonPose(
            keypoints=keypoints,
            score=sum(kp.confidence for kp in keypoints) / len(keypoints),
        )
        return DetectionResult(
            persons=[person],
            frame_width=w, frame_height=h,
            inference_time_ms=elapsed,
        )

    # ---- New Tasks API (mediapipe.tasks) ----

    def _detect_tasks(self, rgb, w, h, t0) -> DetectionResult:
        import time

        mp_image = _mp.Image(image_format=_mp.ImageFormat.SRGB, data=rgb)
        self._frame_timestamp_ms += 33  # ~30 fps increment
        results = self._landmarker.detect_for_video(mp_image,
                                                     self._frame_timestamp_ms)
        elapsed = (time.perf_counter() - t0) * 1000.0

        if not results.pose_landmarks:
            return DetectionResult(frame_width=w, frame_height=h,
                                   inference_time_ms=elapsed)

        # Tasks API returns list of pose landmarks (one per person)
        landmarks = results.pose_landmarks[0]
        world_landmarks = (results.pose_world_landmarks[0]
                           if results.pose_world_landmarks else None)

        keypoints = []
        for i, lm in enumerate(landmarks):
            if world_landmarks and i < len(world_landmarks):
                wlm = world_landmarks[i]
                keypoints.append(Keypoint(
                    x=wlm.x, y=wlm.y, z=wlm.z,
                    confidence=lm.visibility if lm.visibility else 0.5,
                ))
            else:
                keypoints.append(Keypoint(
                    x=lm.x, y=lm.y, z=lm.z,
                    confidence=lm.visibility if lm.visibility else 0.5,
                ))

        person = PersonPose(
            keypoints=keypoints,
            score=sum(kp.confidence for kp in keypoints) / len(keypoints),
        )
        return DetectionResult(
            persons=[person],
            frame_width=w, frame_height=h,
            inference_time_ms=elapsed,
        )

    def release(self):
        if self._pose:
            self._pose.close()
            self._pose = None
        if self._landmarker:
            self._landmarker.close()
            self._landmarker = None
        self._is_loaded = False
