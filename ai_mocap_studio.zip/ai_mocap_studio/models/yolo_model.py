"""
AI Mocap Studio - YOLO-Pose model backend.
Uses Ultralytics YOLO for fast multi-person 2D pose estimation (17 COCO keypoints).
Supports GPU acceleration via CUDA, CoreML, and MPS.
"""

import time
from typing import Optional

from .base import (
    BasePoseModel, DetectionResult, PersonPose, Keypoint,
    COCO_KEYPOINT_NAMES, coco_to_mediapipe_landmarks,
)


class YoloPoseModel(BasePoseModel):
    """YOLO-Pose model for fast multi-person pose estimation."""

    MODEL_NAME = "yolo_pose"
    MODEL_DESCRIPTION = "Ultralytics YOLO-Pose — fast multi-person, 17 COCO keypoints, GPU"
    SUPPORTS_GPU = True
    SUPPORTS_MULTI_PERSON = True
    SUPPORTS_3D = False
    NUM_KEYPOINTS = 17

    def __init__(self, variant="yolo11s-pose", conf_threshold=0.5, iou_threshold=0.45):
        super().__init__()
        self._variant = variant
        self._conf_threshold = conf_threshold
        self._iou_threshold = iou_threshold
        self._model = None

    def load(self, model_path: Optional[str] = None, use_gpu: bool = True):
        """Load YOLO model. Downloads automatically on first use."""
        try:
            from ultralytics import YOLO
        except ImportError:
            raise ImportError(
                "ultralytics package required. Install: pip install ultralytics"
            )

        # Load model (ultralytics handles downloading)
        model_name = self._variant
        if model_path and model_path.endswith((".pt", ".onnx")):
            model_name = model_path

        self._model = YOLO(model_name)

        # Set device
        if use_gpu:
            import torch
            if torch.cuda.is_available():
                self._device = "cuda"
            elif hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
                self._device = "mps"
            else:
                self._device = "cpu"
        else:
            self._device = "cpu"

        self._is_loaded = True
        return True

    def detect(self, frame) -> DetectionResult:
        """Run YOLO-Pose on a BGR frame."""
        if not self._is_loaded or self._model is None:
            return DetectionResult()

        t0 = time.perf_counter()
        h, w = frame.shape[:2]

        # Run inference
        results = self._model.predict(
            frame,
            conf=self._conf_threshold,
            iou=self._iou_threshold,
            device=self._device,
            verbose=False,
        )

        elapsed = (time.perf_counter() - t0) * 1000.0

        if not results or len(results) == 0:
            return DetectionResult(frame_width=w, frame_height=h, inference_time_ms=elapsed)

        result = results[0]
        persons = []

        if result.keypoints is not None and result.keypoints.data is not None:
            kpts_data = result.keypoints.data.cpu().numpy()  # (N, 17, 3) — x, y, conf
            boxes = result.boxes

            for i in range(len(kpts_data)):
                keypoints = []
                for j in range(min(17, kpts_data.shape[1])):
                    kx = float(kpts_data[i, j, 0]) / w  # Normalize to 0-1
                    ky = float(kpts_data[i, j, 1]) / h
                    kc = float(kpts_data[i, j, 2]) if kpts_data.shape[2] > 2 else 1.0
                    keypoints.append(Keypoint(
                        x=kx, y=ky, z=0.0,
                        confidence=kc,
                        name=COCO_KEYPOINT_NAMES[j] if j < len(COCO_KEYPOINT_NAMES) else "",
                    ))

                # Bounding box
                bbox = None
                if boxes is not None and i < len(boxes):
                    box = boxes[i].xyxy[0].cpu().numpy()
                    bbox = (float(box[0]), float(box[1]), float(box[2]), float(box[3]))

                score = float(boxes[i].conf[0]) if boxes is not None and i < len(boxes) else 0.0

                persons.append(PersonPose(
                    keypoints=keypoints,
                    bbox=bbox,
                    person_id=i,
                    score=score,
                ))

        return DetectionResult(
            persons=persons,
            frame_width=w,
            frame_height=h,
            inference_time_ms=elapsed,
        )

    def detect_as_mediapipe(self, frame, person_index=0):
        """
        Detect and convert to MediaPipe-compatible 33 landmarks.
        Useful for feeding into existing MediaPipe-based retargeters.
        """
        result = self.detect(frame)
        if not result.has_detections:
            return None

        person = result.persons[min(person_index, len(result.persons) - 1)]
        mp_landmarks = coco_to_mediapipe_landmarks(
            person.keypoints,
            frame_width=result.frame_width,
            frame_height=result.frame_height,
        )
        return mp_landmarks

    def set_variant(self, variant: str):
        """Change the YOLO variant (requires reload)."""
        self._variant = variant
        if self._is_loaded:
            self.release()
            self.load(use_gpu=self._device != "cpu")

    @property
    def variant(self):
        return self._variant

    def release(self):
        self._model = None
        self._is_loaded = False
