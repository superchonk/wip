"""
AI Mocap Studio - AI model backends.

Available models:
- MediaPipe Pose (mediapipe) — fast, CPU, 33 keypoints
- YOLO-Pose (yolo_pose) — fast multi-person, GPU, 17 COCO keypoints
- MotionBERT (motionbert) — 2D→3D lifting, SOTA 3D, temporal consistency
"""
