"""
AI Mocap Studio - Abstract base class for all pose estimation models.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import List, Optional, Tuple
from mathutils import Vector


@dataclass
class Keypoint:
    """Single detected keypoint."""
    x: float = 0.0
    y: float = 0.0
    z: float = 0.0
    confidence: float = 0.0
    name: str = ""


@dataclass
class PersonPose:
    """Detected pose for a single person."""
    keypoints: List[Keypoint] = field(default_factory=list)
    bbox: Optional[Tuple[float, float, float, float]] = None  # x1, y1, x2, y2
    person_id: int = -1
    score: float = 0.0

    def get_blender_positions(self, scale=1.0):
        """Convert keypoints to Blender coordinate space vectors."""
        positions = []
        for kp in self.keypoints:
            # MediaPipe/COCO convention -> Blender: X right, Y forward, Z up
            positions.append(Vector((
                kp.x * scale,
                -kp.z * scale,
                -kp.y * scale,
            )))
        return positions

    def get_confidences(self):
        """Return list of confidence values."""
        return [kp.confidence for kp in self.keypoints]

    @property
    def num_keypoints(self):
        return len(self.keypoints)

    @property
    def mean_confidence(self):
        if not self.keypoints:
            return 0.0
        return sum(kp.confidence for kp in self.keypoints) / len(self.keypoints)


@dataclass
class DetectionResult:
    """Result from a pose estimation model."""
    persons: List[PersonPose] = field(default_factory=list)
    frame_width: int = 0
    frame_height: int = 0
    inference_time_ms: float = 0.0

    @property
    def num_persons(self):
        return len(self.persons)

    @property
    def has_detections(self):
        return len(self.persons) > 0

    def get_primary_person(self):
        """Return the person with highest confidence (or largest bbox)."""
        if not self.persons:
            return None
        return max(self.persons, key=lambda p: p.score)


class BasePoseModel(ABC):
    """Abstract base for all pose estimation backends."""

    # Model metadata (override in subclasses)
    MODEL_NAME = "base"
    MODEL_DESCRIPTION = "Base pose model"
    SUPPORTS_GPU = False
    SUPPORTS_MULTI_PERSON = False
    SUPPORTS_3D = False
    NUM_KEYPOINTS = 0

    def __init__(self):
        self._is_loaded = False
        self._use_gpu = False
        self._device = "cpu"

    @abstractmethod
    def load(self, model_path: Optional[str] = None, use_gpu: bool = False):
        """Load the model. Returns True on success."""
        pass

    @abstractmethod
    def detect(self, frame) -> DetectionResult:
        """Run detection on a BGR frame. Returns DetectionResult."""
        pass

    @abstractmethod
    def release(self):
        """Release model resources."""
        pass

    @property
    def is_loaded(self):
        return self._is_loaded

    @property
    def device(self):
        return self._device

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.release()
        return False

    def __del__(self):
        self.release()


# Standard COCO keypoint names (17 keypoints)
COCO_KEYPOINT_NAMES = [
    "nose",
    "left_eye", "right_eye",
    "left_ear", "right_ear",
    "left_shoulder", "right_shoulder",
    "left_elbow", "right_elbow",
    "left_wrist", "right_wrist",
    "left_hip", "right_hip",
    "left_knee", "right_knee",
    "left_ankle", "right_ankle",
]

# COCO skeleton connections
COCO_CONNECTIONS = [
    (0, 1), (0, 2), (1, 3), (2, 4),        # Head
    (5, 6),                                    # Shoulders
    (5, 7), (7, 9),                            # Left arm
    (6, 8), (8, 10),                           # Right arm
    (5, 11), (6, 12),                          # Torso
    (11, 12),                                  # Hips
    (11, 13), (13, 15),                        # Left leg
    (12, 14), (14, 16),                        # Right leg
]

# Mapping from COCO 17 keypoints to MediaPipe 33 landmark indices
# This allows models using COCO format to be used with MediaPipe-based retargeters
COCO_TO_MEDIAPIPE = {
    0: 0,     # nose -> nose
    1: 2,     # left_eye -> left_eye
    2: 5,     # right_eye -> right_eye
    3: 7,     # left_ear -> left_ear
    4: 8,     # right_ear -> right_ear
    5: 11,    # left_shoulder -> left_shoulder
    6: 12,    # right_shoulder -> right_shoulder
    7: 13,    # left_elbow -> left_elbow
    8: 14,    # right_elbow -> right_elbow
    9: 15,    # left_wrist -> left_wrist
    10: 16,   # right_wrist -> right_wrist
    11: 23,   # left_hip -> left_hip
    12: 24,   # right_hip -> right_hip
    13: 25,   # left_knee -> left_knee
    14: 26,   # right_knee -> right_knee
    15: 27,   # left_ankle -> left_ankle
    16: 28,   # right_ankle -> right_ankle
}


def coco_to_mediapipe_landmarks(coco_keypoints, frame_width=1, frame_height=1):
    """
    Convert COCO 17-keypoint format to MediaPipe-compatible 33 landmarks.
    Missing keypoints are interpolated or zeroed.
    Returns list of 33 Keypoint objects.
    """
    mp_landmarks = [Keypoint() for _ in range(33)]

    # Map available COCO keypoints
    for coco_idx, mp_idx in COCO_TO_MEDIAPIPE.items():
        if coco_idx < len(coco_keypoints):
            kp = coco_keypoints[coco_idx]
            mp_landmarks[mp_idx] = Keypoint(
                x=kp.x, y=kp.y, z=kp.z,
                confidence=kp.confidence,
            )

    # Interpolate missing MediaPipe landmarks

    # Mouth corners (avg of eye and shoulder)
    if mp_landmarks[2].confidence > 0 and mp_landmarks[11].confidence > 0:
        mp_landmarks[9] = _interpolate_kp(mp_landmarks[2], mp_landmarks[11], 0.6)  # mouth_left
    if mp_landmarks[5].confidence > 0 and mp_landmarks[12].confidence > 0:
        mp_landmarks[10] = _interpolate_kp(mp_landmarks[5], mp_landmarks[12], 0.6)  # mouth_right

    # Hand landmarks (approximate from wrist)
    for wrist_mp, pinky_mp, index_mp, thumb_mp in [
        (15, 17, 19, 21),  # left
        (16, 18, 20, 22),  # right
    ]:
        if mp_landmarks[wrist_mp].confidence > 0:
            w = mp_landmarks[wrist_mp]
            mp_landmarks[pinky_mp] = Keypoint(w.x - 0.02, w.y, w.z, w.confidence * 0.5)
            mp_landmarks[index_mp] = Keypoint(w.x + 0.02, w.y, w.z, w.confidence * 0.5)
            mp_landmarks[thumb_mp] = Keypoint(w.x, w.y - 0.02, w.z, w.confidence * 0.5)

    # Heel and foot index (approximate from ankle)
    for ankle_mp, heel_mp, foot_mp in [
        (27, 29, 31),  # left
        (28, 30, 32),  # right
    ]:
        if mp_landmarks[ankle_mp].confidence > 0:
            a = mp_landmarks[ankle_mp]
            mp_landmarks[heel_mp] = Keypoint(a.x, a.y + 0.02, a.z, a.confidence * 0.5)
            mp_landmarks[foot_mp] = Keypoint(a.x, a.y + 0.04, a.z - 0.02, a.confidence * 0.5)

    return mp_landmarks


def _interpolate_kp(kp1, kp2, t=0.5):
    """Linearly interpolate between two keypoints."""
    return Keypoint(
        x=kp1.x * (1 - t) + kp2.x * t,
        y=kp1.y * (1 - t) + kp2.y * t,
        z=kp1.z * (1 - t) + kp2.z * t,
        confidence=min(kp1.confidence, kp2.confidence) * 0.5,
    )
