"""
AI Mocap Studio - MotionBERT model backend.
2D-to-3D pose lifting using ONNX Runtime.
Takes 2D keypoints (from any detector) and lifts them to 3D with temporal consistency.
"""

import time
from typing import Optional, List
from collections import deque

from .base import (
    BasePoseModel, DetectionResult, PersonPose, Keypoint,
    COCO_KEYPOINT_NAMES, coco_to_mediapipe_landmarks,
)


class MotionBERTModel(BasePoseModel):
    """
    MotionBERT 2D→3D lifting model.

    This model does NOT detect poses from images. Instead, it takes 2D keypoints
    (from MediaPipe, YOLO, etc.) and lifts them to accurate 3D coordinates
    using temporal transformer architecture.

    Pipeline: Frame → 2D Detector → MotionBERT → 3D Pose
    """

    MODEL_NAME = "motionbert"
    MODEL_DESCRIPTION = "MotionBERT — SOTA 2D→3D lifting with temporal consistency"
    SUPPORTS_GPU = True
    SUPPORTS_MULTI_PERSON = False
    SUPPORTS_3D = True
    NUM_KEYPOINTS = 17

    # Temporal window size for the transformer
    WINDOW_SIZE = 243  # MotionBERT default clip length

    def __init__(self, window_size=243):
        super().__init__()
        self._session = None
        self._window_size = window_size
        self._input_buffer = deque(maxlen=window_size)
        self._onnx_providers = ["CPUExecutionProvider"]

    def load(self, model_path: Optional[str] = None, use_gpu: bool = True):
        """Load ONNX model for 2D→3D lifting."""
        try:
            import onnxruntime as ort
        except ImportError:
            raise ImportError(
                "onnxruntime required. Install: pip install onnxruntime\n"
                "For GPU: pip install onnxruntime-gpu"
            )

        if model_path is None or not model_path.endswith(".onnx"):
            self._is_loaded = False
            return False

        import os
        if not os.path.isfile(model_path):
            print(f"[AI Mocap] MotionBERT model not found at: {model_path}")
            self._is_loaded = False
            return False

        # Select providers
        available_providers = ort.get_available_providers()

        if use_gpu:
            if "CUDAExecutionProvider" in available_providers:
                self._onnx_providers = ["CUDAExecutionProvider", "CPUExecutionProvider"]
                self._device = "cuda"
            elif "CoreMLExecutionProvider" in available_providers:
                self._onnx_providers = ["CoreMLExecutionProvider", "CPUExecutionProvider"]
                self._device = "coreml"
            elif "DmlExecutionProvider" in available_providers:
                self._onnx_providers = ["DmlExecutionProvider", "CPUExecutionProvider"]
                self._device = "directml"
            else:
                self._onnx_providers = ["CPUExecutionProvider"]
                self._device = "cpu"
        else:
            self._onnx_providers = ["CPUExecutionProvider"]
            self._device = "cpu"

        try:
            sess_options = ort.SessionOptions()
            sess_options.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL

            self._session = ort.InferenceSession(
                model_path,
                sess_options=sess_options,
                providers=self._onnx_providers,
            )
            self._is_loaded = True
            return True

        except Exception as e:
            self._is_loaded = False
            raise RuntimeError(f"Failed to load ONNX model: {e}")

    def lift_2d_to_3d(self, keypoints_2d: List[Keypoint]) -> List[Keypoint]:
        """
        Lift a single frame of 2D keypoints to 3D.
        Accumulates frames in a buffer for temporal consistency.

        keypoints_2d: List of 17 COCO Keypoints with x, y in normalized coords.
        Returns: List of 17 Keypoints with x, y, z in 3D space.
        """
        if not self._is_loaded or self._session is None:
            return keypoints_2d

        import numpy as np
        # Convert keypoints to numpy array [17, 2]
        kp_array = np.array(
            [[kp.x, kp.y] for kp in keypoints_2d[:17]],
            dtype=np.float32,
        )

        # Add to temporal buffer
        self._input_buffer.append(kp_array)

        # Pad buffer if not full yet (repeat first frame)
        buffer_list = list(self._input_buffer)
        while len(buffer_list) < self._window_size:
            buffer_list.insert(0, buffer_list[0])

        # Stack into (1, T, 17, 2)
        input_tensor = np.stack(buffer_list, axis=0)
        input_tensor = input_tensor[np.newaxis, ...]  # batch dim

        # Run inference
        t0 = time.perf_counter()

        input_name = self._session.get_inputs()[0].name
        output_name = self._session.get_outputs()[0].name

        output = self._session.run(
            [output_name],
            {input_name: input_tensor},
        )[0]  # (1, T, 17, 3)

        elapsed = (time.perf_counter() - t0) * 1000.0

        # Get the last frame's 3D pose
        pose_3d = output[0, -1, :, :]  # (17, 3)

        # Convert back to Keypoint list
        keypoints_3d = []
        for j in range(min(17, pose_3d.shape[0])):
            conf = keypoints_2d[j].confidence if j < len(keypoints_2d) else 0.0
            keypoints_3d.append(Keypoint(
                x=float(pose_3d[j, 0]),
                y=float(pose_3d[j, 1]),
                z=float(pose_3d[j, 2]),
                confidence=conf,
                name=COCO_KEYPOINT_NAMES[j] if j < len(COCO_KEYPOINT_NAMES) else "",
            ))

        return keypoints_3d

    def detect(self, frame) -> DetectionResult:
        """
        MotionBERT cannot detect from raw frames alone.
        This is a stub — use lift_2d_to_3d() with a 2D detector pipeline.
        """
        return DetectionResult(
            frame_width=frame.shape[1] if frame is not None else 0,
            frame_height=frame.shape[0] if frame is not None else 0,
        )

    def process_with_2d_detector(self, frame, detector_2d: BasePoseModel) -> DetectionResult:
        """
        Full pipeline: 2D detection → 3D lifting.

        detector_2d: A loaded 2D pose detector (YOLO, MediaPipe, etc.)
        Returns DetectionResult with 3D keypoints.
        """
        t0 = time.perf_counter()
        h, w = frame.shape[:2]

        # Step 1: 2D detection
        result_2d = detector_2d.detect(frame)
        if not result_2d.has_detections:
            return DetectionResult(frame_width=w, frame_height=h)

        primary = result_2d.get_primary_person()
        if primary is None:
            return DetectionResult(frame_width=w, frame_height=h)

        # Step 2: 3D lifting
        keypoints_3d = self.lift_2d_to_3d(primary.keypoints)

        elapsed = (time.perf_counter() - t0) * 1000.0

        person = PersonPose(
            keypoints=keypoints_3d,
            bbox=primary.bbox,
            person_id=0,
            score=primary.score,
        )

        return DetectionResult(
            persons=[person],
            frame_width=w,
            frame_height=h,
            inference_time_ms=elapsed,
        )

    def as_mediapipe_landmarks(self, keypoints_3d):
        """Convert 3D COCO keypoints to MediaPipe-compatible 33 landmarks."""
        return coco_to_mediapipe_landmarks(keypoints_3d)

    def reset_buffer(self):
        """Clear the temporal buffer (e.g., when switching clips)."""
        self._input_buffer.clear()

    @property
    def buffer_fill(self):
        """How full the temporal buffer is (0.0 to 1.0)."""
        return len(self._input_buffer) / self._window_size

    def release(self):
        self._session = None
        self._input_buffer.clear()
        self._is_loaded = False
