"""
AI Mocap Studio - Constants and bone mapping definitions.
"""

ADDON_NAME = "ai_mocap_studio"

# MediaPipe Pose landmark indices
# https://developers.google.com/mediapipe/solutions/vision/pose_landmarker
MP_LANDMARK = {
    "NOSE": 0,
    "LEFT_EYE_INNER": 1,
    "LEFT_EYE": 2,
    "LEFT_EYE_OUTER": 3,
    "RIGHT_EYE_INNER": 4,
    "RIGHT_EYE": 5,
    "RIGHT_EYE_OUTER": 6,
    "LEFT_EAR": 7,
    "RIGHT_EAR": 8,
    "MOUTH_LEFT": 9,
    "MOUTH_RIGHT": 10,
    "LEFT_SHOULDER": 11,
    "RIGHT_SHOULDER": 12,
    "LEFT_ELBOW": 13,
    "RIGHT_ELBOW": 14,
    "LEFT_WRIST": 15,
    "RIGHT_WRIST": 16,
    "LEFT_PINKY": 17,
    "RIGHT_PINKY": 18,
    "LEFT_INDEX": 19,
    "RIGHT_INDEX": 20,
    "LEFT_THUMB": 21,
    "RIGHT_THUMB": 22,
    "LEFT_HIP": 23,
    "RIGHT_HIP": 24,
    "LEFT_KNEE": 25,
    "RIGHT_KNEE": 26,
    "LEFT_ANKLE": 27,
    "RIGHT_ANKLE": 28,
    "LEFT_HEEL": 29,
    "RIGHT_HEEL": 30,
    "LEFT_FOOT_INDEX": 31,
    "RIGHT_FOOT_INDEX": 32,
}

# Skeleton connections for viewport drawing (pairs of landmark indices)
POSE_CONNECTIONS = [
    # Torso
    (11, 12),  # shoulders
    (11, 23),  # left shoulder -> left hip
    (12, 24),  # right shoulder -> right hip
    (23, 24),  # hips
    # Left arm
    (11, 13),  # left shoulder -> left elbow
    (13, 15),  # left elbow -> left wrist
    # Right arm
    (12, 14),  # right shoulder -> right elbow
    (14, 16),  # right elbow -> right wrist
    # Left leg
    (23, 25),  # left hip -> left knee
    (25, 27),  # left knee -> left ankle
    (27, 29),  # left ankle -> left heel
    (27, 31),  # left ankle -> left foot index
    (29, 31),  # left heel -> left foot index
    # Right leg
    (24, 26),  # right hip -> right knee
    (26, 28),  # right knee -> right ankle
    (28, 30),  # right ankle -> right heel
    (28, 32),  # right ankle -> right foot index
    (30, 32),  # right heel -> right foot index
    # Head
    (0, 11),   # nose -> left shoulder (approximate neck)
    (0, 12),   # nose -> right shoulder
]

# Default mapping: MediaPipe landmark name -> Rigify bone name
DEFAULT_BONE_MAPPING = {
    "hips": {"landmarks": ["LEFT_HIP", "RIGHT_HIP"], "type": "midpoint"},
    "spine": {"landmarks": ["LEFT_HIP", "RIGHT_HIP", "LEFT_SHOULDER", "RIGHT_SHOULDER"], "type": "spine"},
    "chest": {"landmarks": ["LEFT_SHOULDER", "RIGHT_SHOULDER"], "type": "midpoint"},
    "neck": {"landmarks": ["NOSE", "LEFT_SHOULDER", "RIGHT_SHOULDER"], "type": "neck"},
    "head": {"landmarks": ["NOSE", "LEFT_EAR", "RIGHT_EAR"], "type": "head"},

    "shoulder.L": {"landmarks": ["LEFT_SHOULDER"], "type": "single"},
    "upper_arm.L": {"landmarks": ["LEFT_SHOULDER", "LEFT_ELBOW"], "type": "chain"},
    "forearm.L": {"landmarks": ["LEFT_ELBOW", "LEFT_WRIST"], "type": "chain"},
    "hand.L": {"landmarks": ["LEFT_WRIST", "LEFT_INDEX", "LEFT_PINKY"], "type": "hand"},

    "shoulder.R": {"landmarks": ["RIGHT_SHOULDER"], "type": "single"},
    "upper_arm.R": {"landmarks": ["RIGHT_SHOULDER", "RIGHT_ELBOW"], "type": "chain"},
    "forearm.R": {"landmarks": ["RIGHT_ELBOW", "RIGHT_WRIST"], "type": "chain"},
    "hand.R": {"landmarks": ["RIGHT_WRIST", "RIGHT_INDEX", "RIGHT_PINKY"], "type": "hand"},

    "thigh.L": {"landmarks": ["LEFT_HIP", "LEFT_KNEE"], "type": "chain"},
    "shin.L": {"landmarks": ["LEFT_KNEE", "LEFT_ANKLE"], "type": "chain"},
    "foot.L": {"landmarks": ["LEFT_ANKLE", "LEFT_FOOT_INDEX"], "type": "chain"},

    "thigh.R": {"landmarks": ["RIGHT_HIP", "RIGHT_KNEE"], "type": "chain"},
    "shin.R": {"landmarks": ["RIGHT_KNEE", "RIGHT_ANKLE"], "type": "chain"},
    "foot.R": {"landmarks": ["RIGHT_ANKLE", "RIGHT_FOOT_INDEX"], "type": "chain"},
}

# Capture settings defaults
DEFAULT_CAPTURE_FPS = 30
DEFAULT_CAPTURE_WIDTH = 1280
DEFAULT_CAPTURE_HEIGHT = 720
MIN_DETECTION_CONFIDENCE = 0.5
MIN_TRACKING_CONFIDENCE = 0.5

# Viewport drawing colors (RGBA)
COLOR_BONE = (0.0, 1.0, 0.4, 1.0)
COLOR_JOINT = (1.0, 0.8, 0.0, 1.0)
COLOR_CONFIDENCE_LOW = (1.0, 0.2, 0.2, 0.5)
COLOR_HAND_BONE = (0.2, 0.6, 1.0, 1.0)
COLOR_HAND_JOINT = (0.4, 0.8, 1.0, 1.0)
COLOR_FACE_POINT = (1.0, 0.4, 0.8, 0.6)
COLOR_FACE_MESH = (1.0, 0.4, 0.8, 0.3)

# ============================================================
# MediaPipe Hand landmark indices (21 per hand)
# ============================================================
MP_HAND_LANDMARK = {
    "WRIST": 0,
    "THUMB_CMC": 1,
    "THUMB_MCP": 2,
    "THUMB_IP": 3,
    "THUMB_TIP": 4,
    "INDEX_FINGER_MCP": 5,
    "INDEX_FINGER_PIP": 6,
    "INDEX_FINGER_DIP": 7,
    "INDEX_FINGER_TIP": 8,
    "MIDDLE_FINGER_MCP": 9,
    "MIDDLE_FINGER_PIP": 10,
    "MIDDLE_FINGER_DIP": 11,
    "MIDDLE_FINGER_TIP": 12,
    "RING_FINGER_MCP": 13,
    "RING_FINGER_PIP": 14,
    "RING_FINGER_DIP": 15,
    "RING_FINGER_TIP": 16,
    "PINKY_MCP": 17,
    "PINKY_PIP": 18,
    "PINKY_DIP": 19,
    "PINKY_TIP": 20,
}

# Hand skeleton connections for viewport drawing
HAND_CONNECTIONS = [
    # Thumb
    (0, 1), (1, 2), (2, 3), (3, 4),
    # Index
    (0, 5), (5, 6), (6, 7), (7, 8),
    # Middle
    (0, 9), (9, 10), (10, 11), (11, 12),
    # Ring
    (0, 13), (13, 14), (14, 15), (15, 16),
    # Pinky
    (0, 17), (17, 18), (18, 19), (19, 20),
    # Palm
    (5, 9), (9, 13), (13, 17),
]

# ============================================================
# MediaPipe Face Mesh key landmark indices (468 total)
# ============================================================
MP_FACE_LANDMARK = {
    "NOSE_TIP": 1,
    "FOREHEAD": 10,
    "CHIN": 152,
    "LEFT_CHEEK": 234,
    "RIGHT_CHEEK": 454,
    "LEFT_EYE_INNER": 133,
    "LEFT_EYE_OUTER": 33,
    "LEFT_EYE_TOP": 159,
    "LEFT_EYE_BOTTOM": 145,
    "RIGHT_EYE_INNER": 362,
    "RIGHT_EYE_OUTER": 263,
    "RIGHT_EYE_TOP": 386,
    "RIGHT_EYE_BOTTOM": 374,
    "UPPER_LIP": 13,
    "LOWER_LIP": 14,
    "MOUTH_LEFT": 61,
    "MOUTH_RIGHT": 291,
    "LEFT_EYEBROW_INNER": 107,
    "LEFT_EYEBROW_OUTER": 70,
    "RIGHT_EYEBROW_INNER": 336,
    "RIGHT_EYEBROW_OUTER": 300,
    # Iris landmarks (available when refine_landmarks=True)
    "LEFT_IRIS_CENTER": 468,
    "RIGHT_IRIS_CENTER": 473,
}

# Face oval outline indices for viewport drawing
FACE_OVAL_INDICES = [
    10, 338, 297, 332, 284, 251, 389, 356, 454, 323, 361, 288,
    397, 365, 379, 378, 400, 377, 152, 148, 176, 149, 150, 136,
    172, 58, 132, 93, 234, 127, 162, 21, 54, 103, 67, 109, 10,
]

# Left eye contour
LEFT_EYE_INDICES = [33, 7, 163, 144, 145, 153, 154, 155, 133, 173, 157, 158, 159, 160, 161, 246, 33]

# Right eye contour
RIGHT_EYE_INDICES = [362, 382, 381, 380, 374, 373, 390, 249, 263, 466, 388, 387, 386, 385, 384, 398, 362]

# Outer lips contour
LIPS_OUTER_INDICES = [61, 146, 91, 181, 84, 17, 314, 405, 321, 375, 291, 409, 270, 269, 267, 0, 37, 39, 40, 185, 61]

# Inner lips contour
LIPS_INNER_INDICES = [78, 95, 88, 178, 87, 14, 317, 402, 318, 324, 308, 415, 310, 311, 312, 13, 82, 81, 80, 191, 78]

# ============================================================
# ARKit Blendshape names (52 total - Apple standard)
# ============================================================
ARKIT_BLENDSHAPES = [
    # Eyes
    "eyeBlinkLeft",
    "eyeBlinkRight",
    "eyeLookDownLeft",
    "eyeLookDownRight",
    "eyeLookInLeft",
    "eyeLookInRight",
    "eyeLookOutLeft",
    "eyeLookOutRight",
    "eyeLookUpLeft",
    "eyeLookUpRight",
    "eyeSquintLeft",
    "eyeSquintRight",
    "eyeWideLeft",
    "eyeWideRight",
    # Brows
    "browDownLeft",
    "browDownRight",
    "browInnerUp",
    "browOuterUpLeft",
    "browOuterUpRight",
    # Jaw
    "jawForward",
    "jawLeft",
    "jawOpen",
    "jawRight",
    # Mouth
    "mouthClose",
    "mouthDimpleLeft",
    "mouthDimpleRight",
    "mouthFrownLeft",
    "mouthFrownRight",
    "mouthFunnel",
    "mouthLeft",
    "mouthLowerDownLeft",
    "mouthLowerDownRight",
    "mouthPressLeft",
    "mouthPressRight",
    "mouthPucker",
    "mouthRight",
    "mouthRollLower",
    "mouthRollUpper",
    "mouthShrugLower",
    "mouthShrugUpper",
    "mouthSmileLeft",
    "mouthSmileRight",
    "mouthStretchLeft",
    "mouthStretchRight",
    "mouthUpperUpLeft",
    "mouthUpperUpRight",
    # Nose
    "noseSneerLeft",
    "noseSneerRight",
    # Cheeks
    "cheekPuff",
    "cheekSquintLeft",
    "cheekSquintRight",
    # Tongue
    "tongueOut",
]

# ============================================================
# Capture mode enum
# ============================================================
CAPTURE_MODES = [
    ("BODY", "Body Only", "Track body pose only (33 landmarks)"),
    ("HANDS", "Hands Only", "Track hands only (21 landmarks per hand)"),
    ("FACE", "Face Only", "Track face only (468 landmarks + blendshapes)"),
    ("HOLISTIC", "Holistic", "Track body + hands + face simultaneously"),
]
