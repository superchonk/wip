"""
AI Mocap Studio - Dependency management.
Handles installation of required Python packages into Blender's Python.
"""

import subprocess
import sys
import os
import importlib
import platform
from pathlib import Path

REQUIRED_PACKAGES = {
    "cv2": "opencv-python",
    "mediapipe": "mediapipe",
    "numpy": "numpy",
}

# Optional packages for advanced models
OPTIONAL_PACKAGES = {
    "onnxruntime": "onnxruntime",
    "ultralytics": "ultralytics",
    "pythonosc": "python-osc",
    "ezc3d": "ezc3d",
}

# GPU-specific packages
GPU_PACKAGES = {
    "onnxruntime_gpu": "onnxruntime-gpu",
}


def get_python_executable():
    """Get the path to Blender's bundled Python executable.

    In Blender, sys.executable points to the Blender binary, not Python.
    We need to locate the actual Python interpreter bundled with Blender.
    """
    # Method 1: bpy.app.binary_path_python (Blender 2.92-2.93)
    try:
        import bpy
        if hasattr(bpy.app, "binary_path_python"):
            p = bpy.app.binary_path_python
            if p and os.path.isfile(p):
                return p
    except ImportError:
        pass

    # Method 2: Construct from sys.prefix (works for Blender 3.x / 4.x)
    # sys.prefix points to Blender's bundled Python root, e.g.:
    #   macOS:   .../Blender.app/Contents/Resources/4.0/python
    #   Windows: .../Blender Foundation/Blender 4.0/4.0/python
    #   Linux:   .../blender/4.0/python
    ver = f"{sys.version_info.major}.{sys.version_info.minor}"

    if sys.platform == "win32":
        candidates = [
            Path(sys.prefix) / "bin" / "python.exe",
            Path(sys.prefix) / "python.exe",
            Path(sys.prefix) / "bin" / f"python{ver}.exe",
        ]
    else:
        candidates = [
            Path(sys.prefix) / "bin" / f"python{ver}",
            Path(sys.prefix) / "bin" / "python3",
            Path(sys.prefix) / "bin" / "python",
        ]

    for candidate in candidates:
        if candidate.is_file():
            return str(candidate)

    # Method 3: Search near the Blender binary
    blender_bin = Path(sys.executable)
    if sys.platform == "darwin":
        # macOS: /Applications/Blender.app/Contents/MacOS/Blender
        #   -> ../Resources/<version>/python/bin/python3.x
        resources = blender_bin.parent.parent / "Resources"
        if resources.is_dir():
            for version_dir in sorted(resources.iterdir(), reverse=True):
                py_bin = version_dir / "python" / "bin" / f"python{ver}"
                if py_bin.is_file():
                    return str(py_bin)
                py_bin = version_dir / "python" / "bin" / "python3"
                if py_bin.is_file():
                    return str(py_bin)
    elif sys.platform == "win32":
        # Windows: .../blender.exe -> ../<version>/python/bin/python.exe
        parent = blender_bin.parent
        for version_dir in sorted(parent.iterdir(), reverse=True):
            py_bin = version_dir / "python" / "bin" / "python.exe"
            if py_bin.is_file():
                return str(py_bin)
    else:
        # Linux: .../blender -> ../<version>/python/bin/python3.x
        parent = blender_bin.parent
        for version_dir in sorted(parent.iterdir(), reverse=True):
            py_bin = version_dir / "python" / "bin" / f"python{ver}"
            if py_bin.is_file():
                return str(py_bin)
            py_bin = version_dir / "python" / "bin" / "python3"
            if py_bin.is_file():
                return str(py_bin)

    # Last resort — may not work but nothing else to try
    return sys.executable


def is_package_installed(import_name):
    """Check if a Python package is available for import."""
    try:
        importlib.import_module(import_name)
        return True
    except ImportError:
        return False


def get_missing_packages():
    """Return a list of (import_name, pip_name) tuples for missing packages."""
    missing = []
    for import_name, pip_name in REQUIRED_PACKAGES.items():
        if not is_package_installed(import_name):
            missing.append((import_name, pip_name))
    return missing


def _get_target_dir():
    """Get Blender's site-packages directory for installing packages."""
    import site

    # First: check if any existing site-packages path is inside sys.prefix
    # (this reliably identifies Blender's own site-packages)
    prefix = os.path.normcase(os.path.normpath(sys.prefix))
    try:
        for sp in site.getsitepackages():
            sp_norm = os.path.normcase(os.path.normpath(sp))
            if sp_norm.startswith(prefix):
                _ensure_on_sys_path(sp)
                return sp
    except AttributeError:
        pass  # getsitepackages() not available in some virtualenvs

    # Second: check for "site-packages" in any getsitepackages entry
    try:
        for sp in site.getsitepackages():
            if "site-packages" in sp:
                _ensure_on_sys_path(sp)
                return sp
    except AttributeError:
        pass

    # Fallback: construct from sys.prefix
    if sys.platform == "win32":
        target = str(Path(sys.prefix) / "lib" / "site-packages")
    else:
        ver = f"python{sys.version_info.major}.{sys.version_info.minor}"
        target = str(Path(sys.prefix) / "lib" / ver / "site-packages")

    _ensure_on_sys_path(target)
    return target


def _ensure_on_sys_path(directory):
    """Make sure a directory is on sys.path so installed packages can be imported."""
    norm = os.path.normcase(os.path.normpath(directory))
    for p in sys.path:
        if os.path.normcase(os.path.normpath(p)) == norm:
            return
    sys.path.append(directory)


def _ensure_pip(python):
    """Ensure pip is available for Blender's Python. Returns True if pip is ready."""
    # First check if pip already works
    try:
        subprocess.check_call(
            [python, "-m", "pip", "--version"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        return True
    except (subprocess.CalledProcessError, FileNotFoundError, OSError):
        pass

    # Try ensurepip
    try:
        subprocess.check_call(
            [python, "-m", "ensurepip", "--upgrade"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        return True
    except (subprocess.CalledProcessError, FileNotFoundError, OSError):
        pass

    # Try get-pip.py as last resort
    try:
        import urllib.request
        get_pip_path = Path(sys.prefix) / "get-pip.py"
        urllib.request.urlretrieve("https://bootstrap.pypa.io/get-pip.py", str(get_pip_path))
        subprocess.check_call(
            [python, str(get_pip_path)],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        get_pip_path.unlink(missing_ok=True)
        return True
    except Exception:
        pass

    return False


def install_package(pip_name):
    """Install a single package using pip into Blender's site-packages."""
    python = get_python_executable()
    target = _get_target_dir()

    try:
        result = subprocess.run(
            [python, "-m", "pip", "install", "--target", target,
             "--no-warn-script-location", pip_name],
            capture_output=True,
            text=True,
            timeout=300,
        )
        if result.returncode == 0:
            return True, ""
        # Return the actual error output from pip
        error_msg = result.stderr.strip() or result.stdout.strip()
        return False, error_msg
    except subprocess.TimeoutExpired:
        return False, f"Installation of {pip_name} timed out (5 min)"
    except FileNotFoundError:
        return False, f"Python executable not found: {python}"
    except Exception as e:
        return False, str(e)


def install_all_missing():
    """Install all missing packages. Returns (success, messages)."""
    missing = get_missing_packages()
    if not missing:
        return True, "All dependencies are already installed."

    python = get_python_executable()

    # Verify we found a real Python executable (not the Blender binary)
    py_path = Path(python)
    if py_path.stem.lower() in ("blender", "blender.exe"):
        return False, (
            f"Could not find Blender's bundled Python interpreter. "
            f"sys.executable={sys.executable}, sys.prefix={sys.prefix}. "
            f"Please install packages manually via Blender's Python console."
        )

    # Ensure pip is available
    if not _ensure_pip(python):
        return False, (
            f"pip is not available in Blender's Python ({python}). "
            f"Try running in Blender's Python console: "
            f"import ensurepip; ensurepip.bootstrap()"
        )

    messages = []
    all_success = True

    for import_name, pip_name in missing:
        success, error = install_package(pip_name)
        if success:
            messages.append(f"Installed {pip_name}")
        else:
            messages.append(f"Failed to install {pip_name}: {error}")
            all_success = False

    # Refresh importlib cache so newly installed packages can be found
    importlib.invalidate_caches()

    return all_success, "\n".join(messages)


def check_dependencies():
    """Check if all dependencies are satisfied. Returns (ok, missing_list)."""
    missing = get_missing_packages()
    return len(missing) == 0, [pip_name for _, pip_name in missing]


def check_optional_dependency(import_name):
    """Check if an optional package is available."""
    return is_package_installed(import_name)


def install_optional_package(package_key):
    """Install an optional package by key. Returns (success, message)."""
    pip_name = OPTIONAL_PACKAGES.get(package_key) or GPU_PACKAGES.get(package_key)
    if pip_name is None:
        return False, f"Unknown package: {package_key}"

    python = get_python_executable()

    # Verify we have real Python, not Blender binary
    py_path = Path(python)
    if py_path.stem.lower() in ("blender", "blender.exe"):
        return False, (
            f"Could not find Blender's bundled Python. "
            f"Install manually: Blender Python console -> "
            f"import subprocess, sys; "
            f"subprocess.check_call([sys.executable, '-m', 'pip', 'install', '{pip_name}'])"
        )

    if not _ensure_pip(python):
        return False, f"pip is not available in Blender's Python ({python})"

    success, error = install_package(pip_name)
    importlib.invalidate_caches()
    if success:
        return True, f"Installed {pip_name}"
    return False, f"Failed to install {pip_name}: {error}"


def get_optional_status():
    """Return status dict of all optional packages."""
    status = {}
    for import_name, pip_name in OPTIONAL_PACKAGES.items():
        status[import_name] = {
            "pip_name": pip_name,
            "installed": is_package_installed(import_name),
        }
    return status
