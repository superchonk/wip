"""
AI Mocap Studio - Frame interpolation for motion data.

Handles:
- Upsampling (e.g., 30fps capture → 60fps scene)
- Downsampling with anti-aliasing
- Missing frame reconstruction
- Quaternion interpolation (SLERP)
"""

import numpy as np
import math


# ============================================================
# Frame rate conversion
# ============================================================

def resample_motion(data, source_fps, target_fps, method="linear"):
    """
    Resample motion data from one frame rate to another.

    data: np.array (N,) or (N, C)
    source_fps: original frame rate
    target_fps: desired frame rate
    method: "linear", "cubic", "nearest"

    Returns: resampled data
    """
    n_source = len(data)
    if n_source < 2:
        return data.copy()

    duration = (n_source - 1) / source_fps
    n_target = int(math.ceil(duration * target_fps)) + 1

    source_times = np.linspace(0, duration, n_source)
    target_times = np.linspace(0, duration, n_target)

    if data.ndim == 1:
        return _interpolate_1d(source_times, data, target_times, method)
    else:
        result = np.empty((n_target, data.shape[1]))
        for c in range(data.shape[1]):
            result[:, c] = _interpolate_1d(
                source_times, data[:, c], target_times, method
            )
        return result


def _interpolate_1d(x_source, y_source, x_target, method="linear"):
    """Interpolate 1D data."""
    if method == "linear":
        return np.interp(x_target, x_source, y_source)

    elif method == "cubic":
        try:
            from scipy.interpolate import CubicSpline
            cs = CubicSpline(x_source, y_source)
            return cs(x_target)
        except ImportError:
            return np.interp(x_target, x_source, y_source)

    elif method == "nearest":
        indices = np.searchsorted(x_source, x_target, side='right') - 1
        indices = np.clip(indices, 0, len(y_source) - 1)
        return y_source[indices]

    return np.interp(x_target, x_source, y_source)


# ============================================================
# Quaternion SLERP interpolation
# ============================================================

def slerp(q1, q2, t):
    """
    Spherical Linear Interpolation between two quaternions.
    q1, q2: np.array (4,) — [w, x, y, z]
    t: float 0-1
    Returns: interpolated quaternion
    """
    q1 = np.asarray(q1, dtype=np.float64)
    q2 = np.asarray(q2, dtype=np.float64)

    # Normalize
    q1 = q1 / np.linalg.norm(q1)
    q2 = q2 / np.linalg.norm(q2)

    dot = np.dot(q1, q2)

    # If negative dot, negate one quaternion (shortest path)
    if dot < 0:
        q2 = -q2
        dot = -dot

    # If very close, linear interpolation
    if dot > 0.9995:
        result = q1 + t * (q2 - q1)
        return result / np.linalg.norm(result)

    theta = math.acos(min(dot, 1.0))
    sin_theta = math.sin(theta)

    if abs(sin_theta) < 1e-6:
        return q1.copy()

    w1 = math.sin((1 - t) * theta) / sin_theta
    w2 = math.sin(t * theta) / sin_theta

    return w1 * q1 + w2 * q2


def resample_quaternions(quats, source_fps, target_fps):
    """
    Resample quaternion data using SLERP.

    quats: np.array (N, 4) — quaternions [w, x, y, z]
    source_fps, target_fps: frame rates

    Returns: resampled np.array (M, 4)
    """
    n_source = len(quats)
    if n_source < 2:
        return quats.copy()

    duration = (n_source - 1) / source_fps
    n_target = int(math.ceil(duration * target_fps)) + 1

    result = np.empty((n_target, 4))

    for i in range(n_target):
        t_target = i / target_fps
        # Find surrounding source frames
        src_idx = t_target * source_fps
        idx_a = int(math.floor(src_idx))
        idx_b = min(idx_a + 1, n_source - 1)
        frac = src_idx - idx_a

        idx_a = min(idx_a, n_source - 1)
        result[i] = slerp(quats[idx_a], quats[idx_b], frac)

    return result


# ============================================================
# Keyframe reduction (simplification)
# ============================================================

def reduce_keyframes(times, values, tolerance=0.001):
    """
    Remove redundant keyframes that can be reconstructed by interpolation.
    Uses the Ramer-Douglas-Peucker algorithm adapted for animation curves.

    times: np.array (N,)
    values: np.array (N,) or (N, C)
    tolerance: maximum allowed error

    Returns: (reduced_times, reduced_values) — arrays with fewer frames
    """
    if len(times) <= 2:
        return times.copy(), values.copy()

    if values.ndim == 1:
        keep = _rdp_1d(times, values, tolerance)
    else:
        # Keep a frame if ANY channel exceeds tolerance
        keep = np.zeros(len(times), dtype=bool)
        keep[0] = True
        keep[-1] = True
        for c in range(values.shape[1]):
            channel_keep = _rdp_1d(times, values[:, c], tolerance)
            keep |= channel_keep

    return times[keep], values[keep]


def _rdp_1d(times, values, tolerance):
    """Ramer-Douglas-Peucker on 1D animation curve."""
    n = len(times)
    keep = np.zeros(n, dtype=bool)
    keep[0] = True
    keep[-1] = True

    _rdp_recursive(times, values, 0, n - 1, tolerance, keep)
    return keep


def _rdp_recursive(times, values, start, end, tolerance, keep):
    """Recursive RDP step."""
    if end - start <= 1:
        return

    # Linear interpolation from start to end
    t_range = times[end] - times[start]
    if t_range == 0:
        return

    max_dist = 0
    max_idx = start

    for i in range(start + 1, end):
        t = (times[i] - times[start]) / t_range
        interpolated = values[start] * (1 - t) + values[end] * t
        dist = abs(values[i] - interpolated)
        if dist > max_dist:
            max_dist = dist
            max_idx = i

    if max_dist > tolerance:
        keep[max_idx] = True
        _rdp_recursive(times, values, start, max_idx, tolerance, keep)
        _rdp_recursive(times, values, max_idx, end, tolerance, keep)
