"""
AI Mocap Studio - Smoothing filters for motion capture data.

Filters operate on fcurve keyframe data (post-capture) or on live streams.
All filters accept numpy arrays of shape (N,) for single channels
or (N, 3)/(N, 4) for vector/quaternion channels.
"""

import math
import numpy as np


# ============================================================
# Moving Average
# ============================================================

def moving_average(data, window_size=5):
    """
    Simple moving average filter.
    data: np.array of shape (N,) or (N, C)
    window_size: number of frames to average (odd recommended)
    """
    if len(data) < window_size:
        return data.copy()

    if data.ndim == 1:
        kernel = np.ones(window_size) / window_size
        # Pad edges to preserve length
        pad = window_size // 2
        padded = np.pad(data, pad, mode='edge')
        return np.convolve(padded, kernel, mode='valid')
    else:
        result = np.empty_like(data)
        for c in range(data.shape[1]):
            result[:, c] = moving_average(data[:, c], window_size)
        return result


# ============================================================
# Gaussian Smoothing
# ============================================================

def gaussian_smooth(data, sigma=2.0):
    """
    Gaussian smoothing filter.
    data: np.array of shape (N,) or (N, C)
    sigma: standard deviation of the gaussian kernel
    """
    if len(data) < 3:
        return data.copy()

    # Build kernel
    radius = int(math.ceil(sigma * 3))
    size = 2 * radius + 1
    x = np.arange(size) - radius
    kernel = np.exp(-0.5 * (x / sigma) ** 2)
    kernel /= kernel.sum()

    if data.ndim == 1:
        padded = np.pad(data, radius, mode='edge')
        return np.convolve(padded, kernel, mode='valid')
    else:
        result = np.empty_like(data)
        for c in range(data.shape[1]):
            padded = np.pad(data[:, c], radius, mode='edge')
            result[:, c] = np.convolve(padded, kernel, mode='valid')
        return result


# ============================================================
# Butterworth Low-Pass Filter
# ============================================================

def butterworth_lowpass(data, cutoff_freq=6.0, sample_rate=30.0, order=2):
    """
    Butterworth low-pass filter (zero-phase via forward-backward filtering).
    data: np.array of shape (N,) or (N, C)
    cutoff_freq: cutoff frequency in Hz
    sample_rate: sample rate in Hz (= capture FPS)
    order: filter order (2 recommended for mocap)
    """
    try:
        from scipy.signal import butter, filtfilt
    except ImportError:
        # Fallback to gaussian if scipy not available
        sigma = sample_rate / (2.0 * math.pi * cutoff_freq)
        return gaussian_smooth(data, sigma=sigma)

    nyquist = sample_rate / 2.0
    if cutoff_freq >= nyquist:
        return data.copy()

    normalized_cutoff = cutoff_freq / nyquist
    b, a = butter(order, normalized_cutoff, btype='low')

    if len(data) <= 3 * max(len(b), len(a)):
        return data.copy()

    if data.ndim == 1:
        return filtfilt(b, a, data)
    else:
        result = np.empty_like(data)
        for c in range(data.shape[1]):
            result[:, c] = filtfilt(b, a, data[:, c])
        return result


# ============================================================
# One Euro Filter (real-time optimized)
# ============================================================

class OneEuroFilter:
    """
    One Euro Filter — adaptive low-pass for real-time use.
    Balances smoothness (low jitter) and responsiveness (low lag).

    Use for live capture: smooths slow movements, passes fast movements.
    """

    def __init__(self, freq=30.0, min_cutoff=1.0, beta=0.007, d_cutoff=1.0):
        """
        freq: data frequency in Hz
        min_cutoff: minimum cutoff for slow signal (lower = smoother)
        beta: speed coefficient (higher = more responsive to fast motion)
        d_cutoff: cutoff for derivative computation
        """
        self.freq = freq
        self.min_cutoff = min_cutoff
        self.beta = beta
        self.d_cutoff = d_cutoff

        self._x_prev = None
        self._dx_prev = None
        self._t_prev = None

    def _alpha(self, cutoff):
        tau = 1.0 / (2.0 * math.pi * cutoff)
        te = 1.0 / self.freq
        return 1.0 / (1.0 + tau / te)

    def filter(self, x, timestamp=None):
        """
        Filter a single value or numpy array.
        x: float or np.array
        Returns filtered value.
        """
        if self._x_prev is None:
            self._x_prev = x
            self._dx_prev = 0.0 if np.isscalar(x) else np.zeros_like(x)
            self._t_prev = timestamp or 0.0
            return x

        if timestamp is not None and self._t_prev is not None:
            dt = timestamp - self._t_prev
            if dt > 0:
                self.freq = 1.0 / dt
            self._t_prev = timestamp

        # Derivative
        dx = (x - self._x_prev) * self.freq
        alpha_d = self._alpha(self.d_cutoff)
        dx_hat = alpha_d * dx + (1.0 - alpha_d) * self._dx_prev

        # Adaptive cutoff
        if np.isscalar(dx_hat):
            speed = abs(dx_hat)
        else:
            speed = np.linalg.norm(dx_hat)
        cutoff = self.min_cutoff + self.beta * speed

        # Filter
        alpha = self._alpha(cutoff)
        x_hat = alpha * x + (1.0 - alpha) * self._x_prev

        self._x_prev = x_hat
        self._dx_prev = dx_hat

        return x_hat

    def reset(self):
        """Reset filter state."""
        self._x_prev = None
        self._dx_prev = None
        self._t_prev = None


# ============================================================
# Kalman Filter (1D)
# ============================================================

class KalmanFilter1D:
    """
    Simple 1D Kalman filter for single-channel smoothing.
    Good for noisy mocap data with known process/measurement noise.
    """

    def __init__(self, process_noise=0.01, measurement_noise=0.1, initial_value=0.0):
        self.q = process_noise       # Process noise covariance
        self.r = measurement_noise   # Measurement noise covariance
        self.x = initial_value       # State estimate
        self.p = 1.0                 # Error covariance
        self._initialized = False

    def update(self, measurement):
        """Process a new measurement. Returns filtered value."""
        if not self._initialized:
            self.x = measurement
            self._initialized = True
            return self.x

        # Predict
        self.p += self.q

        # Update
        k = self.p / (self.p + self.r)  # Kalman gain
        self.x += k * (measurement - self.x)
        self.p *= (1.0 - k)

        return self.x

    def reset(self):
        self.x = 0.0
        self.p = 1.0
        self._initialized = False


class KalmanFilterND:
    """
    N-dimensional Kalman filter. Wraps multiple 1D Kalman filters.
    Suitable for filtering Vector (3D) or Quaternion (4D) data channels.
    """

    def __init__(self, ndim=3, process_noise=0.01, measurement_noise=0.1):
        self.filters = [
            KalmanFilter1D(process_noise, measurement_noise)
            for _ in range(ndim)
        ]

    def update(self, measurement):
        """
        measurement: list/tuple/array of length ndim
        Returns filtered array.
        """
        return np.array([
            f.update(float(v)) for f, v in zip(self.filters, measurement)
        ])

    def reset(self):
        for f in self.filters:
            f.reset()


# ============================================================
# Batch filter application on fcurve data
# ============================================================

def apply_filter_to_array(data, filter_type="butterworth", **kwargs):
    """
    Apply a filter to a numpy array of keyframe values.

    data: np.array of shape (N,) or (N, C)
    filter_type: one of "moving_average", "gaussian", "butterworth", "one_euro", "kalman"
    kwargs: filter-specific parameters

    Returns: filtered np.array of same shape.
    """
    if data is None or len(data) == 0:
        return data

    data = np.asarray(data, dtype=np.float64)

    if filter_type == "moving_average":
        return moving_average(data, window_size=kwargs.get("window_size", 5))

    elif filter_type == "gaussian":
        return gaussian_smooth(data, sigma=kwargs.get("sigma", 2.0))

    elif filter_type == "butterworth":
        return butterworth_lowpass(
            data,
            cutoff_freq=kwargs.get("cutoff_freq", 6.0),
            sample_rate=kwargs.get("sample_rate", 30.0),
            order=kwargs.get("order", 2),
        )

    elif filter_type == "one_euro":
        freq = kwargs.get("freq", 30.0)
        min_cutoff = kwargs.get("min_cutoff", 1.0)
        beta = kwargs.get("beta", 0.007)

        if data.ndim == 1:
            filt = OneEuroFilter(freq=freq, min_cutoff=min_cutoff, beta=beta)
            return np.array([filt.filter(v) for v in data])
        else:
            result = np.empty_like(data)
            for c in range(data.shape[1]):
                filt = OneEuroFilter(freq=freq, min_cutoff=min_cutoff, beta=beta)
                result[:, c] = np.array([filt.filter(v) for v in data[:, c]])
            return result

    elif filter_type == "kalman":
        q = kwargs.get("process_noise", 0.01)
        r = kwargs.get("measurement_noise", 0.1)

        if data.ndim == 1:
            kf = KalmanFilter1D(process_noise=q, measurement_noise=r)
            return np.array([kf.update(v) for v in data])
        else:
            result = np.empty_like(data)
            for c in range(data.shape[1]):
                kf = KalmanFilter1D(process_noise=q, measurement_noise=r)
                result[:, c] = np.array([kf.update(v) for v in data[:, c]])
            return result

    return data.copy()
