"""
AI Mocap Studio - Motion data cleanup: jitter removal, spike detection, gap filling.

Operates on keyframed animation data (post-capture) to remove common
AI mocap artifacts before final animation use.
"""

import numpy as np


# ============================================================
# Jitter removal
# ============================================================

def remove_jitter(data, threshold=0.002, window=3):
    """
    Remove small high-frequency jitter from motion data.
    If frame-to-frame change is below threshold, snap to previous value.

    data: np.array (N,) or (N, C)
    threshold: minimum meaningful change per frame
    window: look-ahead window for averaging tiny movements

    Returns: cleaned data
    """
    result = data.copy()
    n = len(data)

    if n < 2:
        return result

    if data.ndim == 1:
        for i in range(1, n):
            delta = abs(result[i] - result[i - 1])
            if delta < threshold:
                # Average with neighbors in window
                start = max(0, i - window)
                end = min(n, i + window + 1)
                result[i] = np.mean(result[start:end])
    else:
        for i in range(1, n):
            delta = np.linalg.norm(result[i] - result[i - 1])
            if delta < threshold:
                start = max(0, i - window)
                end = min(n, i + window + 1)
                result[i] = np.mean(result[start:end], axis=0)

    return result


# ============================================================
# Spike detection and removal
# ============================================================

def detect_spikes(data, sigma_threshold=3.0):
    """
    Detect statistical outliers (spikes) in motion data.
    Uses z-score: values > sigma_threshold standard deviations from local mean.

    data: np.array (N,) or (N, C)
    sigma_threshold: number of standard deviations to flag as spike

    Returns: np.array of bool (N,) — True = spike detected
    """
    n = len(data)
    if n < 5:
        return np.zeros(n, dtype=bool)

    if data.ndim > 1:
        # Compute velocity magnitude
        velocities = np.zeros(n)
        for i in range(1, n):
            velocities[i] = np.linalg.norm(data[i] - data[i - 1])
    else:
        velocities = np.abs(np.diff(data, prepend=data[0]))

    # Local statistics (rolling window)
    window = min(15, n // 3)
    spikes = np.zeros(n, dtype=bool)

    for i in range(n):
        start = max(0, i - window)
        end = min(n, i + window + 1)
        local_mean = np.mean(velocities[start:end])
        local_std = np.std(velocities[start:end])

        if local_std > 0 and velocities[i] > local_mean + sigma_threshold * local_std:
            spikes[i] = True

    return spikes


def remove_spikes(data, sigma_threshold=3.0, method="interpolate"):
    """
    Remove detected spikes from motion data.

    data: np.array (N,) or (N, C)
    sigma_threshold: detection threshold
    method: "interpolate" (linear interp) or "previous" (hold previous value)

    Returns: cleaned data
    """
    spikes = detect_spikes(data, sigma_threshold)
    result = data.copy()
    n = len(data)

    if not np.any(spikes):
        return result

    if method == "interpolate":
        result = interpolate_frames(result, spikes)
    elif method == "previous":
        for i in range(n):
            if spikes[i] and i > 0:
                result[i] = result[i - 1]

    return result


# ============================================================
# Gap filling (missing frames / low confidence)
# ============================================================

def detect_gaps(confidences, min_confidence=0.3):
    """
    Detect frames with low confidence (likely bad tracking).

    confidences: np.array (N,) — confidence per frame (0-1)
    min_confidence: threshold below which frame is a "gap"

    Returns: np.array of bool (N,) — True = gap/bad frame
    """
    return np.asarray(confidences) < min_confidence


def fill_gaps(data, gaps, method="linear"):
    """
    Fill gap frames with interpolated data.

    data: np.array (N,) or (N, C)
    gaps: np.array of bool (N,) — True = gap to fill
    method: "linear", "cubic", or "hold"

    Returns: gap-filled data
    """
    return interpolate_frames(data, gaps, method=method)


# ============================================================
# Interpolation
# ============================================================

def interpolate_frames(data, mask, method="linear"):
    """
    Interpolate masked frames using surrounding good frames.

    data: np.array (N,) or (N, C)
    mask: np.array of bool (N,) — True = frame needs interpolation
    method: "linear", "cubic", "hold"

    Returns: interpolated data
    """
    result = data.copy()
    n = len(data)

    if not np.any(mask):
        return result

    good_indices = np.where(~mask)[0]
    bad_indices = np.where(mask)[0]

    if len(good_indices) < 2:
        return result

    if data.ndim == 1:
        if method == "linear":
            result[bad_indices] = np.interp(
                bad_indices,
                good_indices,
                data[good_indices],
            )
        elif method == "cubic":
            try:
                from scipy.interpolate import CubicSpline
                cs = CubicSpline(good_indices, data[good_indices])
                result[bad_indices] = cs(bad_indices)
            except ImportError:
                # Fallback to linear
                result[bad_indices] = np.interp(
                    bad_indices, good_indices, data[good_indices]
                )
        elif method == "hold":
            for idx in bad_indices:
                prev_good = good_indices[good_indices < idx]
                if len(prev_good) > 0:
                    result[idx] = data[prev_good[-1]]
    else:
        for c in range(data.shape[1]):
            col = data[:, c].copy()
            if method == "linear":
                col[bad_indices] = np.interp(
                    bad_indices, good_indices, col[good_indices]
                )
            elif method == "cubic":
                try:
                    from scipy.interpolate import CubicSpline
                    cs = CubicSpline(good_indices, col[good_indices])
                    col[bad_indices] = cs(bad_indices)
                except ImportError:
                    col[bad_indices] = np.interp(
                        bad_indices, good_indices, col[good_indices]
                    )
            elif method == "hold":
                for idx in bad_indices:
                    prev_good = good_indices[good_indices < idx]
                    if len(prev_good) > 0:
                        col[idx] = col[prev_good[-1]]
            result[:, c] = col

    return result


# ============================================================
# Full cleanup pipeline
# ============================================================

def cleanup_motion_data(
    data,
    confidences=None,
    remove_jitter_enabled=True,
    jitter_threshold=0.002,
    remove_spikes_enabled=True,
    spike_sigma=3.0,
    fill_gaps_enabled=True,
    gap_confidence_threshold=0.3,
    interpolation_method="linear",
):
    """
    Full cleanup pipeline for a single channel of motion data.

    data: np.array (N,) or (N, C)
    confidences: np.array (N,) — per-frame confidence (optional)

    Returns: cleaned data
    """
    result = data.copy()

    # Step 1: Fill gaps from low-confidence frames
    if fill_gaps_enabled and confidences is not None:
        gaps = detect_gaps(confidences, gap_confidence_threshold)
        if np.any(gaps):
            result = fill_gaps(result, gaps, method=interpolation_method)

    # Step 2: Remove spikes
    if remove_spikes_enabled:
        result = remove_spikes(result, sigma_threshold=spike_sigma)

    # Step 3: Remove jitter
    if remove_jitter_enabled:
        result = remove_jitter(result, threshold=jitter_threshold)

    return result
