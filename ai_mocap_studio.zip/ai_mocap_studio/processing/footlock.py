"""
AI Mocap Studio - Foot locking and ground contact processing.

Fixes common AI mocap artifacts:
- Foot sliding during stationary poses
- Floating/sinking feet
- Incorrect ground plane contact
"""

import numpy as np


# ============================================================
# Ground contact detection
# ============================================================

def detect_ground_contacts(foot_positions, velocity_threshold=0.005, height_threshold=0.05):
    """
    Detect frames where feet are in contact with the ground.

    foot_positions: np.array of shape (N, 3) — foot position per frame
    velocity_threshold: max velocity (units/frame) to count as stationary
    height_threshold: max height above ground to count as contact

    Returns: np.array of bool, shape (N,) — True = foot on ground
    """
    n = len(foot_positions)
    if n < 2:
        return np.ones(n, dtype=bool)

    contacts = np.zeros(n, dtype=bool)

    # Height-based: foot near ground (Z near minimum)
    heights = foot_positions[:, 2]  # Z = up in Blender
    ground_level = np.percentile(heights, 5)  # Estimate ground from lowest 5%
    height_contact = heights < (ground_level + height_threshold)

    # Velocity-based: foot barely moving
    velocities = np.zeros(n)
    for i in range(1, n):
        delta = foot_positions[i] - foot_positions[i - 1]
        velocities[i] = np.linalg.norm(delta)

    velocity_contact = velocities < velocity_threshold

    # Both conditions must be true
    contacts = height_contact & velocity_contact

    # Expand contacts slightly (feet don't instantly lift)
    contacts = _dilate_contacts(contacts, radius=2)

    return contacts


def _dilate_contacts(contacts, radius=2):
    """Expand contact regions by a few frames for smoother transitions."""
    result = contacts.copy()
    n = len(contacts)
    for i in range(n):
        if contacts[i]:
            for j in range(max(0, i - radius), min(n, i + radius + 1)):
                result[j] = True
    return result


# ============================================================
# Foot locking
# ============================================================

def apply_foot_lock(positions, contacts, blend_frames=3):
    """
    Lock foot position during ground contact frames.

    positions: np.array of shape (N, 3)
    contacts: np.array of bool, shape (N,) from detect_ground_contacts()
    blend_frames: number of frames to blend between locked/unlocked

    Returns: np.array of shape (N, 3) — corrected positions
    """
    result = positions.copy()
    n = len(positions)

    if n < 2:
        return result

    # Find contact segments (start, end)
    segments = _find_contact_segments(contacts)

    for seg_start, seg_end in segments:
        # Lock position = average position during contact segment
        locked_pos = np.mean(positions[seg_start:seg_end + 1], axis=0)

        # Fix Z to ground level
        ground_z = np.min(positions[seg_start:seg_end + 1, 2])
        locked_pos[2] = ground_z

        # Apply locked position
        for i in range(seg_start, seg_end + 1):
            result[i] = locked_pos

        # Blend in transition
        _blend_transition(result, positions, seg_start, blend_frames, direction='in')
        _blend_transition(result, positions, seg_end, blend_frames, direction='out')

    return result


def _find_contact_segments(contacts):
    """Find contiguous segments of True in contacts array."""
    segments = []
    n = len(contacts)
    i = 0
    while i < n:
        if contacts[i]:
            start = i
            while i < n and contacts[i]:
                i += 1
            segments.append((start, i - 1))
        else:
            i += 1
    return segments


def _blend_transition(result, original, boundary, blend_frames, direction='in'):
    """Smooth transition between locked and unlocked states."""
    n = len(result)
    if direction == 'in':
        for j in range(blend_frames):
            idx = boundary - blend_frames + j
            if 0 <= idx < n:
                t = (j + 1) / (blend_frames + 1)
                result[idx] = original[idx] * (1 - t) + result[boundary] * t
    else:  # 'out'
        for j in range(blend_frames):
            idx = boundary + 1 + j
            if 0 <= idx < n:
                t = (j + 1) / (blend_frames + 1)
                result[idx] = result[boundary] * (1 - t) + original[idx] * t


# ============================================================
# Anti-sliding correction
# ============================================================

def fix_foot_sliding(positions, contacts, max_slide_distance=0.01):
    """
    Fix foot sliding during contact by clamping horizontal displacement.

    positions: np.array (N, 3)
    contacts: np.array bool (N,)
    max_slide_distance: maximum allowed XY movement per frame during contact

    Returns: corrected positions np.array (N, 3)
    """
    result = positions.copy()
    n = len(positions)

    anchor = None
    for i in range(n):
        if contacts[i]:
            if anchor is None:
                anchor = result[i].copy()

            # Clamp XY displacement from anchor
            dx = result[i, 0] - anchor[0]
            dy = result[i, 1] - anchor[1]
            dist_xy = np.sqrt(dx * dx + dy * dy)

            if dist_xy > max_slide_distance:
                scale = max_slide_distance / dist_xy
                result[i, 0] = anchor[0] + dx * scale
                result[i, 1] = anchor[1] + dy * scale
        else:
            anchor = None

    return result


# ============================================================
# Ground plane alignment
# ============================================================

def align_to_ground(positions, ground_z=0.0, foot_indices=None):
    """
    Shift entire pose so feet touch the ground plane.

    positions: np.array (N, K, 3) — N frames, K keypoints, 3 coords
    ground_z: target ground Z height
    foot_indices: list of keypoint indices for feet (default: last 4)

    Returns: shifted positions
    """
    result = positions.copy()

    if foot_indices is None:
        # Default: assume last 4 points are foot-related
        k = positions.shape[1]
        foot_indices = list(range(max(0, k - 4), k))

    for i in range(len(result)):
        foot_heights = result[i, foot_indices, 2]
        lowest = np.min(foot_heights)
        offset = ground_z - lowest
        result[i, :, 2] += offset

    return result


def compute_ground_plane(foot_positions_left, foot_positions_right):
    """
    Estimate ground plane Z from foot trajectory data.
    Returns the estimated ground Z level.
    """
    all_heights = np.concatenate([
        foot_positions_left[:, 2],
        foot_positions_right[:, 2],
    ])
    # Ground = 5th percentile of all foot heights
    return np.percentile(all_heights, 5)


# ============================================================
# Full foot processing pipeline
# ============================================================

def process_feet(
    left_foot_positions,
    right_foot_positions,
    fps=30.0,
    velocity_threshold=0.005,
    height_threshold=0.05,
    lock_blend_frames=3,
    fix_sliding=True,
):
    """
    Full foot post-processing pipeline:
    1. Detect ground contacts
    2. Apply foot locking
    3. Fix sliding

    left/right_foot_positions: np.array (N, 3)
    Returns: (left_corrected, right_corrected, left_contacts, right_contacts)
    """
    # Detect contacts
    left_contacts = detect_ground_contacts(
        left_foot_positions,
        velocity_threshold=velocity_threshold,
        height_threshold=height_threshold,
    )
    right_contacts = detect_ground_contacts(
        right_foot_positions,
        velocity_threshold=velocity_threshold,
        height_threshold=height_threshold,
    )

    # Apply foot locking
    left_locked = apply_foot_lock(
        left_foot_positions, left_contacts,
        blend_frames=lock_blend_frames,
    )
    right_locked = apply_foot_lock(
        right_foot_positions, right_contacts,
        blend_frames=lock_blend_frames,
    )

    # Fix sliding
    if fix_sliding:
        left_locked = fix_foot_sliding(left_locked, left_contacts)
        right_locked = fix_foot_sliding(right_locked, right_contacts)

    return left_locked, right_locked, left_contacts, right_contacts
