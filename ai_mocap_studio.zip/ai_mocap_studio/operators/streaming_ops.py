"""
AI Mocap Studio - Streaming operators.
5 operators: start/stop LiveLink, start/stop VMC, stop all.
"""

import bpy
from bpy.types import Operator

from ..streaming.bridge import (
    start_livelink, stop_livelink, get_livelink_stream,
    start_vmc, stop_vmc, get_vmc_stream,
    stop_all, is_any_streaming,
)


class AIMOCAP_OT_start_livelink(Operator):
    """Start Live Link streaming to Unreal Engine"""
    bl_idname = "aimocap.start_livelink"
    bl_label = "Start Live Link"
    bl_description = "Start streaming bone transforms to Unreal Engine via Live Link UDP"
    bl_options = {'REGISTER'}

    def execute(self, context):
        stream = get_livelink_stream()
        if stream is not None and stream.is_running:
            self.report({'WARNING'}, "Live Link is already running")
            return {'CANCELLED'}

        scene = context.scene
        ip = scene.aimocap_livelink_ip
        port = scene.aimocap_livelink_port
        subject = scene.aimocap_livelink_subject

        start_livelink(ip=ip, port=port, subject=subject)
        self.report({'INFO'}, f"Live Link started → {ip}:{port} ({subject})")
        return {'FINISHED'}


class AIMOCAP_OT_stop_livelink(Operator):
    """Stop Live Link streaming"""
    bl_idname = "aimocap.stop_livelink"
    bl_label = "Stop Live Link"
    bl_description = "Stop the Live Link UDP stream"
    bl_options = {'REGISTER'}

    def execute(self, context):
        stream = get_livelink_stream()
        if stream is None or not stream.is_running:
            self.report({'INFO'}, "Live Link is not running")
            return {'CANCELLED'}

        stop_livelink()
        self.report({'INFO'}, "Live Link stopped")
        return {'FINISHED'}


class AIMOCAP_OT_start_vmc(Operator):
    """Start VMC streaming for VTubing"""
    bl_idname = "aimocap.start_vmc"
    bl_label = "Start VMC"
    bl_description = "Start streaming via VMC protocol (OSC over UDP) for VSeeFace/VMagicMirror"
    bl_options = {'REGISTER'}

    def execute(self, context):
        stream = get_vmc_stream()
        if stream is not None and stream.is_running:
            self.report({'WARNING'}, "VMC is already running")
            return {'CANCELLED'}

        scene = context.scene
        ip = scene.aimocap_vmc_ip
        port = scene.aimocap_vmc_port
        send_bs = scene.aimocap_vmc_blendshapes

        start_vmc(ip=ip, port=port, send_blendshapes=send_bs)
        self.report({'INFO'}, f"VMC started → {ip}:{port}")
        return {'FINISHED'}


class AIMOCAP_OT_stop_vmc(Operator):
    """Stop VMC streaming"""
    bl_idname = "aimocap.stop_vmc"
    bl_label = "Stop VMC"
    bl_description = "Stop the VMC protocol stream"
    bl_options = {'REGISTER'}

    def execute(self, context):
        stream = get_vmc_stream()
        if stream is None or not stream.is_running:
            self.report({'INFO'}, "VMC is not running")
            return {'CANCELLED'}

        stop_vmc()
        self.report({'INFO'}, "VMC stopped")
        return {'FINISHED'}


class AIMOCAP_OT_stop_all_streaming(Operator):
    """Stop all active streaming"""
    bl_idname = "aimocap.stop_all_streaming"
    bl_label = "Stop All Streaming"
    bl_description = "Stop all active Live Link and VMC streams"
    bl_options = {'REGISTER'}

    def execute(self, context):
        if not is_any_streaming():
            self.report({'INFO'}, "No streams running")
            return {'CANCELLED'}

        stop_all()
        self.report({'INFO'}, "All streams stopped")
        return {'FINISHED'}


classes = [
    AIMOCAP_OT_start_livelink,
    AIMOCAP_OT_stop_livelink,
    AIMOCAP_OT_start_vmc,
    AIMOCAP_OT_stop_vmc,
    AIMOCAP_OT_stop_all_streaming,
]
