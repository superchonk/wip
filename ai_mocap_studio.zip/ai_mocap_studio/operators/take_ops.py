"""
AI Mocap Studio - Take management operators.
"""

import bpy
from bpy.types import Operator
from bpy.props import StringProperty, IntProperty

from ..capture.takes import get_take_manager


class AIMOCAP_OT_activate_take(Operator):
    """Activate a take (set its Action on the armature)"""
    bl_idname = "aimocap.activate_take"
    bl_label = "Activate Take"
    bl_options = {'REGISTER'}

    take_name: StringProperty(name="Take Name")

    def execute(self, context):
        mgr = get_take_manager()
        mgr.load_from_scene(context.scene)

        if mgr.activate_take(self.take_name, context):
            self.report({'INFO'}, f"Activated take: {self.take_name}")
            return {'FINISHED'}
        else:
            self.report({'ERROR'}, f"Take not found: {self.take_name}")
            return {'CANCELLED'}


class AIMOCAP_OT_delete_take(Operator):
    """Delete a take and its Action"""
    bl_idname = "aimocap.delete_take"
    bl_label = "Delete Take"
    bl_options = {'REGISTER', 'UNDO'}

    take_name: StringProperty(name="Take Name")

    def execute(self, context):
        mgr = get_take_manager()
        mgr.load_from_scene(context.scene)

        if mgr.delete_take(context.scene, self.take_name):
            self.report({'INFO'}, f"Deleted take: {self.take_name}")
            return {'FINISHED'}
        else:
            self.report({'ERROR'}, f"Take not found: {self.take_name}")
            return {'CANCELLED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)


class AIMOCAP_OT_rename_take(Operator):
    """Rename a take"""
    bl_idname = "aimocap.rename_take"
    bl_label = "Rename Take"
    bl_options = {'REGISTER'}

    take_name: StringProperty(name="Current Name")
    new_name: StringProperty(name="New Name")

    def invoke(self, context, event):
        self.new_name = self.take_name
        return context.window_manager.invoke_props_dialog(self, width=300)

    def execute(self, context):
        if not self.new_name or self.new_name == self.take_name:
            return {'CANCELLED'}

        mgr = get_take_manager()
        mgr.load_from_scene(context.scene)

        if mgr.rename_take(context.scene, self.take_name, self.new_name):
            self.report({'INFO'}, f"Renamed: {self.take_name} → {self.new_name}")
            return {'FINISHED'}
        else:
            self.report({'ERROR'}, "Rename failed (name conflict or take not found)")
            return {'CANCELLED'}


class AIMOCAP_OT_duplicate_take(Operator):
    """Duplicate a take (copies the Action)"""
    bl_idname = "aimocap.duplicate_take"
    bl_label = "Duplicate Take"
    bl_options = {'REGISTER', 'UNDO'}

    take_name: StringProperty(name="Take Name")

    def execute(self, context):
        mgr = get_take_manager()
        mgr.load_from_scene(context.scene)

        new_take = mgr.duplicate_take(context.scene, self.take_name)
        if new_take:
            self.report({'INFO'}, f"Duplicated: {self.take_name} → {new_take.name}")
            return {'FINISHED'}
        else:
            self.report({'ERROR'}, f"Cannot duplicate: {self.take_name}")
            return {'CANCELLED'}


class AIMOCAP_OT_add_take_note(Operator):
    """Add a note to a take"""
    bl_idname = "aimocap.add_take_note"
    bl_label = "Take Notes"
    bl_options = {'REGISTER'}

    take_name: StringProperty(name="Take Name")
    notes: StringProperty(name="Notes")

    def invoke(self, context, event):
        mgr = get_take_manager()
        mgr.load_from_scene(context.scene)
        take = mgr.get_take(self.take_name)
        if take:
            self.notes = take.notes
        return context.window_manager.invoke_props_dialog(self, width=400)

    def execute(self, context):
        mgr = get_take_manager()
        mgr.load_from_scene(context.scene)

        take = mgr.get_take(self.take_name)
        if take:
            take.notes = self.notes
            mgr.save_to_scene(context.scene)
            self.report({'INFO'}, "Notes updated")
            return {'FINISHED'}
        return {'CANCELLED'}


class AIMOCAP_OT_refresh_takes(Operator):
    """Refresh the takes list from scene data"""
    bl_idname = "aimocap.refresh_takes"
    bl_label = "Refresh Takes"
    bl_options = {'REGISTER'}

    def execute(self, context):
        mgr = get_take_manager()
        mgr.load_from_scene(context.scene)
        self.report({'INFO'}, f"Loaded {mgr.count} takes")
        return {'FINISHED'}


classes = [
    AIMOCAP_OT_activate_take,
    AIMOCAP_OT_delete_take,
    AIMOCAP_OT_rename_take,
    AIMOCAP_OT_duplicate_take,
    AIMOCAP_OT_add_take_note,
    AIMOCAP_OT_refresh_takes,
]
