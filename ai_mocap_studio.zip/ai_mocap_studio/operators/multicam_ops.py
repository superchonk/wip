"""
AI Mocap Studio - Multi-camera operators.

Handles calibration workflow, multi-cam capture, and video multi-sync.
"""

import os
import bpy
from bpy.types import Operator
from bpy.props import (
    StringProperty, IntProperty, FloatProperty,
    EnumProperty, BoolProperty,
)

from ..core.constants import ADDON_NAME


# Global state for multi-camera session
_multicam_state = {
    "calibration": None,        # CalibrationSession
    "sync": None,               # MultiCameraSync
    "running": False,
    "recording": False,
    "frame_counter": 0,
    "timer": None,
    "calibrating": False,       # True during calibration mode
    "calib_cam_index": 0,       # Current camera being calibrated
    "calib_frames_target": 15,  # Frames to collect per camera
}


def _get_prefs():
    return bpy.context.preferences.addons[ADDON_NAME].preferences


def _get_multicam_indices(context):
    """Parse camera indices from scene property."""
    raw = context.scene.aimocap_multicam_indices
    indices = []
    for part in raw.split(","):
        part = part.strip()
        if part.isdigit():
            indices.append(int(part))
    return indices


# ============================================================
# Calibration operators
# ============================================================

class AIMOCAP_OT_start_calibration(Operator):
    """Start multi-camera calibration using a checkerboard pattern"""
    bl_idname = "aimocap.start_calibration"
    bl_label = "Start Calibration"
    bl_description = "Calibrate cameras using a checkerboard pattern"
    bl_options = {'REGISTER'}

    board_cols: IntProperty(
        name="Board Columns",
        description="Number of inner corners (columns) on the checkerboard",
        default=9, min=3, max=20,
    )
    board_rows: IntProperty(
        name="Board Rows",
        description="Number of inner corners (rows) on the checkerboard",
        default=6, min=3, max=20,
    )
    square_size: FloatProperty(
        name="Square Size (m)",
        description="Physical size of one checkerboard square in meters",
        default=0.025, min=0.001, max=1.0,
        precision=3,
    )
    frames_per_camera: IntProperty(
        name="Frames per Camera",
        description="Number of checkerboard frames to collect per camera",
        default=15, min=5, max=50,
    )

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=300)

    def execute(self, context):
        cam_indices = _get_multicam_indices(context)
        if len(cam_indices) < 2:
            self.report({'ERROR'}, "Set at least 2 camera indices (comma-separated)")
            return {'CANCELLED'}

        prefs = _get_prefs()

        from ..multicam.calibration import CalibrationSession
        from ..multicam.sync import MultiCameraSync
        session = CalibrationSession(
            board_size=(self.board_cols, self.board_rows),
            square_size=self.square_size,
        )

        sync = MultiCameraSync(
            cam_indices,
            width=prefs.capture_width,
            height=prefs.capture_height,
        )
        try:
            sync.open_all()
        except RuntimeError as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}

        _multicam_state["calibration"] = session
        _multicam_state["sync"] = sync
        _multicam_state["calibrating"] = True
        _multicam_state["calib_cam_index"] = 0
        _multicam_state["calib_frames_target"] = self.frames_per_camera
        _multicam_state["running"] = True

        # Start modal timer
        wm = context.window_manager
        _multicam_state["timer"] = wm.event_timer_add(
            1.0 / prefs.capture_fps, window=context.window
        )
        wm.modal_handler_add(self)

        self.report({'INFO'}, f"Calibration started — show checkerboard to all cameras. "
                    f"Collecting {self.frames_per_camera} frames.")
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if not _multicam_state["running"]:
            self.cancel(context)
            return {'CANCELLED'}

        if event.type == 'ESC':
            _multicam_state["running"] = False
            self.cancel(context)
            self.report({'INFO'}, "Calibration cancelled")
            return {'CANCELLED'}

        if event.type == 'TIMER':
            self._collect_frame(context)

        return {'PASS_THROUGH'}

    def _collect_frame(self, context):
        sync = _multicam_state["sync"]
        session = _multicam_state["calibration"]
        target = _multicam_state["calib_frames_target"]

        frames = sync.read_synchronized()
        if not frames:
            return

        # Try to find checkerboard in all cameras simultaneously
        all_found = True
        corners_per_cam = {}

        for cam_idx, frame in frames.items():
            found, corners, annotated = session.find_checkerboard(frame, cam_idx)
            if found:
                corners_per_cam[cam_idx] = (corners, frame.shape[:2])
            else:
                all_found = False

        # Only add frames if checkerboard is visible in ALL cameras
        if all_found and len(corners_per_cam) == len(frames):
            for cam_idx, (corners, shape) in corners_per_cam.items():
                session.add_frame(corners, cam_idx, shape)

            # Check if we have enough frames
            min_frames = min(
                session.get_frame_count(idx) for idx in frames.keys()
            )

            # Report progress
            for area in context.screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()

            if min_frames >= target:
                self._finish_calibration(context)

    def _finish_calibration(self, context):
        session = _multicam_state["calibration"]
        sync = _multicam_state["sync"]
        cam_indices = list(sync.streams.keys())

        # Compute intrinsics for each camera
        for cam_idx in cam_indices:
            try:
                intr = session.calibrate_intrinsics(cam_idx)
                print(f"Camera {cam_idx}: reproj error = {intr.reprojection_error:.4f}")
            except (ValueError, RuntimeError) as e:
                self.report({'ERROR'}, f"Camera {cam_idx} calibration failed: {e}")
                _multicam_state["running"] = False
                return

        # Compute stereo pairs
        for i in range(len(cam_indices)):
            for j in range(i + 1, len(cam_indices)):
                try:
                    pair = session.calibrate_stereo(cam_indices[i], cam_indices[j])
                    print(f"Stereo {cam_indices[i]}-{cam_indices[j]}: "
                          f"reproj error = {pair.reprojection_error:.4f}")
                except (ValueError, RuntimeError) as e:
                    self.report({'WARNING'}, f"Stereo {cam_indices[i]}-{cam_indices[j]} failed: {e}")

        # Save calibration
        calib_dir = os.path.join(os.path.expanduser("~"), ".ai_mocap_studio")
        calib_path = os.path.join(calib_dir, "calibration.json")
        session.save(calib_path)

        _multicam_state["running"] = False
        _multicam_state["calibrating"] = False

        # Release sync — cameras will be reopened for capture
        if _multicam_state["sync"]:
            _multicam_state["sync"].release_all()
            _multicam_state["sync"] = None

        self.report({'INFO'}, f"Calibration complete! Saved to {calib_path}")

    def cancel(self, context):
        if _multicam_state["timer"]:
            context.window_manager.event_timer_remove(_multicam_state["timer"])
            _multicam_state["timer"] = None
        if _multicam_state["sync"]:
            _multicam_state["sync"].release_all()
            _multicam_state["sync"] = None
        _multicam_state["calibrating"] = False
        _multicam_state["running"] = False


class AIMOCAP_OT_load_calibration(Operator):
    """Load a saved calibration file"""
    bl_idname = "aimocap.load_calibration"
    bl_label = "Load Calibration"
    bl_description = "Load camera calibration from file"
    bl_options = {'REGISTER'}

    filepath: StringProperty(subtype='FILE_PATH')

    def invoke(self, context, event):
        # Default path
        default_path = os.path.join(
            os.path.expanduser("~"), ".ai_mocap_studio", "calibration.json"
        )
        if os.path.exists(default_path):
            self.filepath = default_path

        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        if not self.filepath or not os.path.exists(self.filepath):
            self.report({'ERROR'}, "Calibration file not found")
            return {'CANCELLED'}

        try:
            from ..multicam.calibration import CalibrationSession
            session = CalibrationSession.load(self.filepath)
            _multicam_state["calibration"] = session

            n_cams = len(session.intrinsics)
            n_pairs = len(session.stereo_pairs)
            self.report({'INFO'}, f"Loaded calibration: {n_cams} cameras, {n_pairs} stereo pairs")
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Failed to load: {e}")
            return {'CANCELLED'}


# ============================================================
# Multi-camera capture operators
# ============================================================

class AIMOCAP_OT_start_multicam(Operator):
    """Start multi-camera capture with triangulation"""
    bl_idname = "aimocap.start_multicam"
    bl_label = "Start Multi-Camera Capture"
    bl_description = "Start synchronized capture from multiple cameras with 3D triangulation"
    bl_options = {'REGISTER'}

    def execute(self, context):
        if _multicam_state["running"]:
            self.report({'WARNING'}, "Multi-cam capture is already running")
            return {'CANCELLED'}

        session = _multicam_state["calibration"]
        if session is None or not session.stereo_pairs:
            self.report({'ERROR'}, "Calibrate cameras first or load a calibration file")
            return {'CANCELLED'}

        obj = context.active_object
        if not obj or obj.type != 'ARMATURE':
            self.report({'ERROR'}, "Select an armature to retarget to")
            return {'CANCELLED'}

        prefs = _get_prefs()
        cam_indices = _get_multicam_indices(context)

        if len(cam_indices) < 2:
            self.report({'ERROR'}, "Set at least 2 camera indices")
            return {'CANCELLED'}

        from ..multicam.sync import MultiCameraSync
        # Open cameras
        sync = MultiCameraSync(
            cam_indices,
            width=prefs.capture_width,
            height=prefs.capture_height,
            sync_tolerance=context.scene.aimocap_multicam_sync_tolerance,
        )
        try:
            sync.open_all()
        except RuntimeError as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}

        _multicam_state["sync"] = sync
        _multicam_state["running"] = True
        _multicam_state["recording"] = False
        _multicam_state["frame_counter"] = -1

        # Setup detector for each view
        from ..detection.body import PoseDetector
        det_conf = prefs.min_detection_confidence
        trk_conf = prefs.min_tracking_confidence
        _multicam_state["detectors"] = {
            idx: PoseDetector(
                min_detection_confidence=det_conf,
                min_tracking_confidence=trk_conf,
            )
            for idx in cam_indices
        }

        # Setup retargeter
        from ..retarget.mapper import PoseRetargeter
        _multicam_state["retargeter"] = PoseRetargeter(
            obj,
            rig_type=context.scene.aimocap_rig_type,
            scale=context.scene.aimocap_scale,
        )

        # Enable viewport drawing
        from ..ui.viewport_draw import enable_viewport_draw
        if prefs.show_landmarks:
            enable_viewport_draw()

        # Start timer
        wm = context.window_manager
        _multicam_state["timer"] = wm.event_timer_add(
            1.0 / prefs.capture_fps, window=context.window
        )
        wm.modal_handler_add(self)

        self.report({'INFO'}, f"Multi-cam capture started ({sync.camera_count} cameras)")
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if not _multicam_state["running"]:
            self.cancel(context)
            return {'CANCELLED'}

        if event.type == 'ESC':
            _multicam_state["running"] = False
            self.cancel(context)
            self.report({'INFO'}, "Multi-cam capture stopped")
            return {'CANCELLED'}

        if event.type == 'TIMER':
            self._process_multicam_frame(context)

        return {'PASS_THROUGH'}

    def _process_multicam_frame(self, context):
        import numpy as np
        from ..multicam.calibration import undistort_frame, undistort_points
        from ..multicam.triangulation import (
            triangulate_landmarks, resolve_occlusions, triangulated_to_blender,
        )
        sync = _multicam_state["sync"]
        session = _multicam_state["calibration"]
        detectors = _multicam_state.get("detectors", {})

        frames = sync.read_synchronized()
        if not frames or len(frames) < 2:
            return

        prefs = _get_prefs()
        smoothing = prefs.smoothing_factor if prefs.use_smoothing else 0.0

        # Detect pose in each view
        landmarks_per_view = {}
        confidences_per_view = {}

        for cam_idx, frame in frames.items():
            detector = detectors.get(cam_idx)
            if detector is None:
                continue

            # Undistort frame if calibrated
            intr = session.intrinsics.get(cam_idx)
            if intr and intr.calibrated:
                frame = undistort_frame(frame, intr)

            if smoothing > 0:
                result = detector.detect_with_smoothing(frame, smoothing)
            else:
                result = detector.detect(frame)

            if result is None:
                continue

            # Extract 2D pixel positions
            h, w = frame.shape[:2]
            pts = np.zeros((result.num_landmarks, 2))
            confs = np.zeros(result.num_landmarks)

            for i in range(result.num_landmarks):
                lm = result.landmarks[i]
                pts[i] = [lm.x * w, lm.y * h]
                confs[i] = lm.visibility if hasattr(lm, 'visibility') else 1.0

            # Undistort points
            if intr and intr.calibrated:
                pts = undistort_points(pts, intr)

            landmarks_per_view[cam_idx] = pts
            confidences_per_view[cam_idx] = confs

        if len(landmarks_per_view) < 2:
            return

        # Build projection matrices
        projection_matrices = {}
        cam_list = sorted(landmarks_per_view.keys())
        ref_cam = cam_list[0]

        for cam_idx in cam_list:
            if cam_idx == ref_cam:
                # Reference camera at origin
                intr = session.intrinsics.get(cam_idx)
                if intr and intr.calibrated:
                    projection_matrices[cam_idx] = intr.camera_matrix @ np.hstack(
                        [np.eye(3), np.zeros((3, 1))]
                    )
            else:
                pair_key = (ref_cam, cam_idx)
                alt_key = (cam_idx, ref_cam)
                pair = session.stereo_pairs.get(pair_key) or session.stereo_pairs.get(alt_key)
                intr = session.intrinsics.get(cam_idx)

                if pair and pair.calibrated and intr and intr.calibrated:
                    if pair_key in session.stereo_pairs:
                        projection_matrices[cam_idx] = intr.camera_matrix @ np.hstack(
                            [pair.rotation, pair.translation]
                        )
                    else:
                        # Invert the pair
                        R_inv = pair.rotation.T
                        T_inv = -R_inv @ pair.translation
                        projection_matrices[cam_idx] = intr.camera_matrix @ np.hstack(
                            [R_inv, T_inv]
                        )

        if len(projection_matrices) < 2:
            return

        # Triangulate with occlusion resolution
        use_occlusion = context.scene.aimocap_multicam_occlusion_resolve
        if use_occlusion:
            points_3d, errors = resolve_occlusions(
                projection_matrices, landmarks_per_view, confidences_per_view,
            )
        else:
            points_3d = triangulate_landmarks(
                projection_matrices, landmarks_per_view, confidences_per_view,
            )

        # Convert to Blender coordinates
        points_blender = triangulated_to_blender(points_3d)
        scale = context.scene.aimocap_scale

        # Update viewport
        from ..ui.viewport_draw import update_draw_data
        positions = [(p[0] * scale, p[1] * scale, p[2] * scale) for p in points_blender]

        avg_conf = np.mean(list(confidences_per_view.values()), axis=0)
        update_draw_data(positions, avg_conf.tolist(), prefs.landmark_scale)

        # Record keyframes
        if _multicam_state["recording"]:
            retargeter = _multicam_state.get("retargeter")
            if retargeter:
                _multicam_state["frame_counter"] += 1
                frame_num = context.scene.frame_start + _multicam_state["frame_counter"]
                retargeter.apply_triangulated_pose(
                    points_blender, scale=scale, frame=frame_num
                )
                context.scene.frame_set(frame_num)

        # Force viewport redraw
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()

    def cancel(self, context):
        _cleanup_multicam(context)


class AIMOCAP_OT_stop_multicam(Operator):
    """Stop multi-camera capture"""
    bl_idname = "aimocap.stop_multicam"
    bl_label = "Stop Multi-Camera"
    bl_description = "Stop the multi-camera capture session"
    bl_options = {'REGISTER'}

    def execute(self, context):
        if not _multicam_state["running"]:
            self.report({'INFO'}, "No multi-cam capture running")
            return {'CANCELLED'}

        _multicam_state["running"] = False
        _cleanup_multicam(context)
        self.report({'INFO'}, "Multi-cam capture stopped")
        return {'FINISHED'}


class AIMOCAP_OT_toggle_multicam_recording(Operator):
    """Toggle recording for multi-camera capture"""
    bl_idname = "aimocap.toggle_multicam_recording"
    bl_label = "Toggle Multi-Cam Recording"
    bl_description = "Start/stop recording keyframes from multi-camera capture"
    bl_options = {'REGISTER'}

    def execute(self, context):
        if not _multicam_state["running"]:
            self.report({'WARNING'}, "Start multi-cam capture first")
            return {'CANCELLED'}

        _multicam_state["recording"] = not _multicam_state["recording"]
        if _multicam_state["recording"]:
            _multicam_state["frame_counter"] = -1
            self.report({'INFO'}, "Multi-cam recording started")
        else:
            self.report({'INFO'}, f"Multi-cam recording stopped ({_multicam_state['frame_counter']} frames)")
        return {'FINISHED'}


# ============================================================
# Multi-video sync operator
# ============================================================

class AIMOCAP_OT_capture_from_multi_video(Operator):
    """Process synchronized video files from multiple cameras"""
    bl_idname = "aimocap.capture_from_multi_video"
    bl_label = "Capture from Multi-Video"
    bl_description = "Process synchronized video files from multiple cameras"
    bl_options = {'REGISTER', 'UNDO'}

    directory: StringProperty(subtype='DIR_PATH')

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'ARMATURE':
            self.report({'ERROR'}, "Select an armature first")
            return {'CANCELLED'}

        session = _multicam_state["calibration"]
        if session is None or not session.stereo_pairs:
            self.report({'ERROR'}, "Load calibration data first")
            return {'CANCELLED'}

        if not self.directory:
            self.report({'ERROR'}, "No directory selected")
            return {'CANCELLED'}

        # Find video files in directory
        video_exts = {'.mp4', '.avi', '.mov', '.mkv', '.webm'}
        video_files = sorted([
            f for f in os.listdir(self.directory)
            if os.path.splitext(f)[1].lower() in video_exts
        ])

        cam_indices = sorted(session.intrinsics.keys())
        if len(video_files) < len(cam_indices):
            self.report({'ERROR'}, f"Found {len(video_files)} videos but have {len(cam_indices)} calibrated cameras")
            return {'CANCELLED'}

        # Map videos to cameras by order
        video_paths = {}
        for i, cam_idx in enumerate(cam_indices):
            if i < len(video_files):
                video_paths[cam_idx] = os.path.join(self.directory, video_files[i])

        import numpy as np
        from ..detection.body import PoseDetector
        from ..retarget.mapper import PoseRetargeter
        from ..multicam.calibration import undistort_frame, undistort_points
        from ..multicam.sync import VideoMultiSync
        from ..multicam.triangulation import resolve_occlusions, triangulated_to_blender

        prefs = _get_prefs()
        smoothing = prefs.smoothing_factor if prefs.use_smoothing else 0.0
        scale = context.scene.aimocap_scale

        multi_sync = VideoMultiSync(video_paths)
        try:
            multi_sync.open_all()
        except RuntimeError as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}

        detectors = {
            idx: PoseDetector(
                min_detection_confidence=prefs.min_detection_confidence,
                min_tracking_confidence=prefs.min_tracking_confidence,
            )
            for idx in cam_indices
        }
        retargeter = PoseRetargeter(
            obj,
            rig_type=context.scene.aimocap_rig_type,
            scale=scale,
        )

        # Build projection matrices
        projection_matrices = {}
        ref_cam = cam_indices[0]
        for cam_idx in cam_indices:
            intr = session.intrinsics.get(cam_idx)
            if not intr or not intr.calibrated:
                continue
            if cam_idx == ref_cam:
                projection_matrices[cam_idx] = intr.camera_matrix @ np.hstack(
                    [np.eye(3), np.zeros((3, 1))]
                )
            else:
                pair_key = (ref_cam, cam_idx)
                alt_key = (cam_idx, ref_cam)
                pair = session.stereo_pairs.get(pair_key) or session.stereo_pairs.get(alt_key)
                if pair and pair.calibrated:
                    if pair_key in session.stereo_pairs:
                        projection_matrices[cam_idx] = intr.camera_matrix @ np.hstack(
                            [pair.rotation, pair.translation]
                        )
                    else:
                        R_inv = pair.rotation.T
                        T_inv = -R_inv @ pair.translation
                        projection_matrices[cam_idx] = intr.camera_matrix @ np.hstack(
                            [R_inv, T_inv]
                        )

        frame_num = context.scene.frame_start
        processed = 0

        while True:
            frames = multi_sync.read_frame()
            if not frames:
                break

            landmarks_per_view = {}
            confidences_per_view = {}

            for cam_idx, frame in frames.items():
                detector = detectors.get(cam_idx)
                if detector is None:
                    continue

                intr = session.intrinsics.get(cam_idx)
                if intr and intr.calibrated:
                    frame = undistort_frame(frame, intr)

                result = (detector.detect_with_smoothing(frame, smoothing)
                          if smoothing > 0 else detector.detect(frame))
                if result is None:
                    continue

                h, w = frame.shape[:2]
                pts = np.zeros((result.num_landmarks, 2))
                confs = np.zeros(result.num_landmarks)
                for i in range(result.num_landmarks):
                    lm = result.landmarks[i]
                    pts[i] = [lm.x * w, lm.y * h]
                    confs[i] = lm.visibility if hasattr(lm, 'visibility') else 1.0
                if intr and intr.calibrated:
                    pts = undistort_points(pts, intr)
                landmarks_per_view[cam_idx] = pts
                confidences_per_view[cam_idx] = confs

            if len(landmarks_per_view) >= 2:
                points_3d, _ = resolve_occlusions(
                    projection_matrices, landmarks_per_view, confidences_per_view,
                )
                points_blender = triangulated_to_blender(points_3d)
                retargeter.apply_triangulated_pose(
                    points_blender, scale=scale, frame=frame_num
                )
                processed += 1

            frame_num += 1

        context.scene.frame_end = max(context.scene.frame_end, frame_num - 1)
        multi_sync.release_all()
        for det in detectors.values():
            det.release()

        context.scene.frame_set(context.scene.frame_start)
        self.report({'INFO'}, f"Processed {processed} frames from {len(video_paths)} videos")
        return {'FINISHED'}


# ============================================================
# Helpers
# ============================================================

def _cleanup_multicam(context):
    """Release multi-camera resources."""
    if _multicam_state["timer"]:
        context.window_manager.event_timer_remove(_multicam_state["timer"])
        _multicam_state["timer"] = None

    if _multicam_state["sync"]:
        _multicam_state["sync"].release_all()
        _multicam_state["sync"] = None

    # Release detectors
    detectors = _multicam_state.get("detectors", {})
    for det in detectors.values():
        det.release()
    _multicam_state["detectors"] = {}

    _multicam_state["running"] = False
    _multicam_state["recording"] = False
    _multicam_state["calibrating"] = False
    _multicam_state["retargeter"] = None
    _multicam_state["frame_counter"] = -1

    from ..ui.viewport_draw import disable_viewport_draw
    disable_viewport_draw()


classes = [
    AIMOCAP_OT_start_calibration,
    AIMOCAP_OT_load_calibration,
    AIMOCAP_OT_start_multicam,
    AIMOCAP_OT_stop_multicam,
    AIMOCAP_OT_toggle_multicam_recording,
    AIMOCAP_OT_capture_from_multi_video,
]
