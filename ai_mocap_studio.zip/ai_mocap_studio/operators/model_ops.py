"""
AI Mocap Studio - Model management operators.
"""

import bpy
from bpy.types import Operator
from bpy.props import StringProperty, EnumProperty

from ..core.constants import ADDON_NAME
from ..models.manager import get_model_manager, detect_gpu


def _get_prefs():
    return bpy.context.preferences.addons[ADDON_NAME].preferences


class AIMOCAP_OT_load_model(Operator):
    """Load the selected AI model"""
    bl_idname = "aimocap.load_model"
    bl_label = "Load Model"
    bl_description = "Load the selected detection model into memory"
    bl_options = {'REGISTER'}

    def execute(self, context):
        prefs = _get_prefs()
        manager = get_model_manager()

        model_map = {
            "MEDIAPIPE": "mediapipe",
            "YOLO_POSE": "yolo_pose",
            "MOTIONBERT": "motionbert",
        }
        model_id = model_map.get(prefs.detection_model, "mediapipe")
        variant = prefs.yolo_variant if model_id == "yolo_pose" else None

        success, message = manager.load_model(
            model_id,
            use_gpu=prefs.use_gpu,
            variant=variant,
        )

        if success:
            self.report({'INFO'}, message)
        else:
            self.report({'ERROR'}, message)

        return {'FINISHED'}


class AIMOCAP_OT_unload_model(Operator):
    """Unload the current AI model from memory"""
    bl_idname = "aimocap.unload_model"
    bl_label = "Unload Model"
    bl_description = "Release the current model from memory"
    bl_options = {'REGISTER'}

    def execute(self, context):
        manager = get_model_manager()

        if manager.active_model_name is None:
            self.report({'INFO'}, "No model loaded")
            return {'CANCELLED'}

        name = manager.active_model_name
        manager.unload_model(name)
        self.report({'INFO'}, f"Unloaded {name}")
        return {'FINISHED'}


class AIMOCAP_OT_detect_gpu(Operator):
    """Detect available GPU and compute capabilities"""
    bl_idname = "aimocap.detect_gpu"
    bl_label = "Detect GPU"
    bl_description = "Detect GPU hardware and available acceleration"
    bl_options = {'REGISTER'}

    def execute(self, context):
        gpu_info = detect_gpu()

        lines = [
            f"GPU: {gpu_info['gpu_name']}",
            f"CUDA: {'Yes' if gpu_info['cuda_available'] else 'No'}",
            f"Metal: {'Yes' if gpu_info['metal_available'] else 'No'}",
            f"VRAM: {gpu_info['vram_mb']} MB" if gpu_info['vram_mb'] > 0 else "",
            f"Recommended: {gpu_info['recommended_device']}",
            f"ONNX providers: {', '.join(gpu_info['onnx_providers'])}",
        ]

        message = " | ".join(l for l in lines if l)
        self.report({'INFO'}, message)
        return {'FINISHED'}


class AIMOCAP_OT_model_info(Operator):
    """Show info about loaded models"""
    bl_idname = "aimocap.model_info"
    bl_label = "Model Info"
    bl_description = "Display information about available and loaded models"
    bl_options = {'REGISTER'}

    def execute(self, context):
        manager = get_model_manager()
        models = manager.get_available_models()

        lines = []
        for m in models:
            status = ""
            if m["is_active"]:
                status = " [ACTIVE]"
            elif m["is_loaded"]:
                status = " [loaded]"

            downloaded = "ready" if m["is_downloaded"] else "needs download"
            lines.append(
                f"{m['name']}{status}: {m['speed']}/{m['accuracy']} "
                f"({'GPU' if m['supports_gpu'] else 'CPU'}, "
                f"{'multi-person' if m['supports_multi_person'] else 'single'}, "
                f"{'3D' if m['supports_3d'] else '2D'}) [{downloaded}]"
            )

        cache_mb = manager.get_cache_size_mb()
        lines.append(f"Cache: {cache_mb:.1f} MB at {manager.cache_dir}")

        self.report({'INFO'}, " | ".join(lines))
        return {'FINISHED'}


class AIMOCAP_OT_install_model_deps(Operator):
    """Install dependencies for the selected model"""
    bl_idname = "aimocap.install_model_deps"
    bl_label = "Install Model Dependencies"
    bl_description = "Install packages needed for the selected AI model"
    bl_options = {'REGISTER'}

    def execute(self, context):
        prefs = _get_prefs()
        from ..core.dependencies import install_optional_package

        deps_map = {
            "MEDIAPIPE": [],
            "YOLO_POSE": ["ultralytics"],
            "MOTIONBERT": ["onnxruntime"],
        }

        packages = deps_map.get(prefs.detection_model, [])
        if not packages:
            self.report({'INFO'}, "No additional dependencies needed")
            return {'FINISHED'}

        messages = []
        all_ok = True
        for pkg in packages:
            success, msg = install_optional_package(pkg)
            messages.append(msg)
            if not success:
                all_ok = False

        result = "; ".join(messages)
        if all_ok:
            self.report({'INFO'}, result)
        else:
            self.report({'ERROR'}, result)

        return {'FINISHED'}


class AIMOCAP_OT_download_model(Operator):
    """Download model files"""
    bl_idname = "aimocap.download_model"
    bl_label = "Download Model"
    bl_description = "Download the model files to local cache"
    bl_options = {'REGISTER'}

    def execute(self, context):
        prefs = _get_prefs()
        manager = get_model_manager()

        model_map = {
            "MEDIAPIPE": "mediapipe",
            "YOLO_POSE": "yolo_pose",
            "MOTIONBERT": "motionbert",
        }
        model_id = model_map.get(prefs.detection_model, "mediapipe")
        variant = prefs.yolo_variant if model_id == "yolo_pose" else None

        success, message = manager.download_model(model_id, variant=variant)

        if success:
            self.report({'INFO'}, message)
        else:
            self.report({'WARNING'}, message)

        return {'FINISHED'}


classes = [
    AIMOCAP_OT_load_model,
    AIMOCAP_OT_unload_model,
    AIMOCAP_OT_detect_gpu,
    AIMOCAP_OT_model_info,
    AIMOCAP_OT_install_model_deps,
    AIMOCAP_OT_download_model,
]
