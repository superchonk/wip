"""
AI Mocap Studio - Post-processing operators.
Apply filters, foot lock, cleanup to keyframed animation data.
"""

import bpy
from bpy.types import Operator
from bpy.props import (
    EnumProperty, FloatProperty, IntProperty, BoolProperty, StringProperty,
)

from ..core.constants import ADDON_NAME


def _get_prefs():
    return bpy.context.preferences.addons[ADDON_NAME].preferences


def _get_fcurve_data(action, data_path, index=0):
    """Extract keyframe times and values from an fcurve."""
    import numpy as np
    for fc in action.fcurves:
        if fc.data_path == data_path and fc.array_index == index:
            times = np.array([kp.co[0] for kp in fc.keyframe_points])
            values = np.array([kp.co[1] for kp in fc.keyframe_points])
            return fc, times, values
    return None, None, None


def _set_fcurve_data(fcurve, times, values):
    """Write filtered values back to fcurve keyframes."""
    n = min(len(fcurve.keyframe_points), len(values))
    for i in range(n):
        fcurve.keyframe_points[i].co[1] = float(values[i])
    fcurve.update()


# ============================================================
# Smooth Animation
# ============================================================

class AIMOCAP_OT_smooth_animation(Operator):
    """Smooth keyframed animation on the selected armature"""
    bl_idname = "aimocap.smooth_animation"
    bl_label = "Smooth Animation"
    bl_description = "Apply smoothing filter to keyframed bone animations"
    bl_options = {'REGISTER', 'UNDO'}

    filter_type: EnumProperty(
        name="Filter",
        items=[
            ("butterworth", "Butterworth", "Low-pass filter (best for periodic motion)"),
            ("gaussian", "Gaussian", "Gaussian smoothing (general purpose)"),
            ("moving_average", "Moving Average", "Simple averaging (fast)"),
            ("one_euro", "One Euro", "Adaptive filter (preserves sharp movements)"),
            ("kalman", "Kalman", "Statistical noise reduction"),
        ],
        default="butterworth",
    )

    strength: FloatProperty(
        name="Strength",
        description="Filter strength (higher = smoother)",
        default=0.5,
        min=0.0,
        max=1.0,
    )

    selected_bones_only: BoolProperty(
        name="Selected Bones Only",
        description="Only process selected pose bones",
        default=False,
    )

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'ARMATURE':
            self.report({'ERROR'}, "Select an armature")
            return {'CANCELLED'}

        action = obj.animation_data.action if obj.animation_data else None
        if action is None:
            self.report({'ERROR'}, "No animation data")
            return {'CANCELLED'}

        import numpy as np
        from ..processing.filters import apply_filter_to_array

        fps = context.scene.render.fps
        processed = 0

        # Map strength to filter parameters
        params = self._strength_to_params(self.filter_type, self.strength, fps)

        # Get bones to process
        bone_names = self._get_target_bones(obj)

        for fc in action.fcurves:
            # Check if this fcurve belongs to a target bone
            if self.selected_bones_only:
                bone_match = False
                for bname in bone_names:
                    if bname in fc.data_path:
                        bone_match = True
                        break
                if not bone_match:
                    continue

            if len(fc.keyframe_points) < 3:
                continue

            values = np.array([kp.co[1] for kp in fc.keyframe_points])
            filtered = apply_filter_to_array(values, self.filter_type, **params)
            _set_fcurve_data(fc, None, filtered)
            processed += 1

        self.report({'INFO'}, f"Smoothed {processed} channels ({self.filter_type})")
        return {'FINISHED'}

    def _strength_to_params(self, filter_type, strength, fps):
        """Convert 0-1 strength to filter-specific parameters."""
        if filter_type == "butterworth":
            # strength 0=12Hz, 1=1Hz cutoff
            cutoff = 12.0 - strength * 11.0
            return {"cutoff_freq": cutoff, "sample_rate": float(fps), "order": 2}
        elif filter_type == "gaussian":
            sigma = 0.5 + strength * 4.5
            return {"sigma": sigma}
        elif filter_type == "moving_average":
            window = max(3, int(3 + strength * 12))
            if window % 2 == 0:
                window += 1
            return {"window_size": window}
        elif filter_type == "one_euro":
            min_cutoff = 3.0 - strength * 2.5
            beta = 0.001 + strength * 0.02
            return {"freq": float(fps), "min_cutoff": min_cutoff, "beta": beta}
        elif filter_type == "kalman":
            q = 0.1 - strength * 0.09
            r = 0.05 + strength * 0.45
            return {"process_noise": q, "measurement_noise": r}
        return {}

    def _get_target_bones(self, obj):
        """Get list of bone names to process."""
        if self.selected_bones_only and obj.mode == 'POSE':
            return [b.name for b in obj.pose.bones if b.bone.select]
        return [b.name for b in obj.pose.bones]

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)


# ============================================================
# Foot Lock
# ============================================================

class AIMOCAP_OT_apply_foot_lock(Operator):
    """Apply foot locking to fix sliding feet"""
    bl_idname = "aimocap.apply_foot_lock"
    bl_label = "Apply Foot Lock"
    bl_description = "Fix foot sliding by locking feet during ground contact"
    bl_options = {'REGISTER', 'UNDO'}

    velocity_threshold: FloatProperty(
        name="Velocity Threshold",
        description="Max velocity to detect as stationary (lower = stricter)",
        default=0.005,
        min=0.001,
        max=0.05,
    )

    height_threshold: FloatProperty(
        name="Height Threshold",
        description="Max height above ground to detect as contact",
        default=0.05,
        min=0.01,
        max=0.2,
    )

    blend_frames: IntProperty(
        name="Blend Frames",
        description="Transition frames between locked/unlocked",
        default=3,
        min=1,
        max=10,
    )

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'ARMATURE':
            self.report({'ERROR'}, "Select an armature")
            return {'CANCELLED'}

        action = obj.animation_data.action if obj.animation_data else None
        if action is None:
            self.report({'ERROR'}, "No animation data")
            return {'CANCELLED'}

        from ..processing.footlock import process_feet

        # Find foot bone fcurves
        foot_bones = self._find_foot_bones(obj)
        if not foot_bones:
            self.report({'ERROR'}, "No foot bones found")
            return {'CANCELLED'}

        for side_label, bone_name in foot_bones.items():
            positions = self._extract_bone_positions(action, bone_name)
            if positions is None or len(positions) < 5:
                continue

            from ..processing.footlock import detect_ground_contacts, apply_foot_lock, fix_foot_sliding

            contacts = detect_ground_contacts(
                positions,
                velocity_threshold=self.velocity_threshold,
                height_threshold=self.height_threshold,
            )
            locked = apply_foot_lock(positions, contacts, blend_frames=self.blend_frames)
            locked = fix_foot_sliding(locked, contacts)

            self._write_bone_positions(action, bone_name, locked)

        self.report({'INFO'}, f"Foot lock applied to {len(foot_bones)} bones")
        return {'FINISHED'}

    def _find_foot_bones(self, obj):
        """Find left and right foot bones by common naming patterns."""
        bones = {}
        patterns = {
            "left": ["foot.L", "LeftFoot", "mixamorig:LeftFoot", "DEF-foot.L"],
            "right": ["foot.R", "RightFoot", "mixamorig:RightFoot", "DEF-foot.R"],
        }
        for side, names in patterns.items():
            for name in names:
                if name in obj.data.bones:
                    bones[side] = name
                    break
        return bones

    def _extract_bone_positions(self, action, bone_name):
        """Extract XYZ location from bone fcurves into (N, 3) array."""
        import numpy as np
        data_path = f'pose.bones["{bone_name}"].location'
        channels = []
        for idx in range(3):
            fc, times, values = _get_fcurve_data(action, data_path, idx)
            if values is not None:
                channels.append(values)

        if len(channels) == 3 and all(len(c) == len(channels[0]) for c in channels):
            return np.column_stack(channels)
        return None

    def _write_bone_positions(self, action, bone_name, positions):
        """Write corrected positions back to fcurves."""
        data_path = f'pose.bones["{bone_name}"].location'
        for idx in range(3):
            fc, times, values = _get_fcurve_data(action, data_path, idx)
            if fc is not None:
                _set_fcurve_data(fc, times, positions[:, idx])

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)


# ============================================================
# Cleanup (spikes + jitter + gaps)
# ============================================================

class AIMOCAP_OT_cleanup_animation(Operator):
    """Remove noise, spikes, and fill gaps in animation"""
    bl_idname = "aimocap.cleanup_animation"
    bl_label = "Cleanup Animation"
    bl_description = "Remove jitter, spikes, and fill tracking gaps"
    bl_options = {'REGISTER', 'UNDO'}

    remove_jitter: BoolProperty(name="Remove Jitter", default=True)
    jitter_threshold: FloatProperty(
        name="Jitter Threshold", default=0.002, min=0.0001, max=0.01,
    )

    remove_spikes: BoolProperty(name="Remove Spikes", default=True)
    spike_sigma: FloatProperty(
        name="Spike Sigma", default=3.0, min=1.5, max=6.0,
        description="Standard deviations to flag as spike",
    )

    fill_gaps: BoolProperty(name="Fill Gaps", default=True)
    interpolation_method: EnumProperty(
        name="Interpolation",
        items=[
            ("linear", "Linear", "Linear interpolation"),
            ("cubic", "Cubic", "Cubic spline (smoother, requires scipy)"),
            ("hold", "Hold", "Hold previous value"),
        ],
        default="linear",
    )

    selected_bones_only: BoolProperty(
        name="Selected Bones Only", default=False,
    )

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'ARMATURE':
            self.report({'ERROR'}, "Select an armature")
            return {'CANCELLED'}

        action = obj.animation_data.action if obj.animation_data else None
        if action is None:
            self.report({'ERROR'}, "No animation data")
            return {'CANCELLED'}

        import numpy as np
        from ..processing.cleanup import cleanup_motion_data

        processed = 0
        bone_names = self._get_target_bones(obj)

        for fc in action.fcurves:
            if self.selected_bones_only:
                bone_match = any(bname in fc.data_path for bname in bone_names)
                if not bone_match:
                    continue

            if len(fc.keyframe_points) < 3:
                continue

            values = np.array([kp.co[1] for kp in fc.keyframe_points])

            cleaned = cleanup_motion_data(
                values,
                remove_jitter_enabled=self.remove_jitter,
                jitter_threshold=self.jitter_threshold,
                remove_spikes_enabled=self.remove_spikes,
                spike_sigma=self.spike_sigma,
                fill_gaps_enabled=False,  # No confidence data for fcurves
                interpolation_method=self.interpolation_method,
            )

            _set_fcurve_data(fc, None, cleaned)
            processed += 1

        self.report({'INFO'}, f"Cleaned up {processed} channels")
        return {'FINISHED'}

    def _get_target_bones(self, obj):
        if self.selected_bones_only and obj.mode == 'POSE':
            return [b.name for b in obj.pose.bones if b.bone.select]
        return [b.name for b in obj.pose.bones]

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)


# ============================================================
# Reduce Keyframes
# ============================================================

class AIMOCAP_OT_reduce_keyframes(Operator):
    """Remove redundant keyframes to simplify animation curves"""
    bl_idname = "aimocap.reduce_keyframes"
    bl_label = "Reduce Keyframes"
    bl_description = "Remove keyframes that can be reconstructed by interpolation"
    bl_options = {'REGISTER', 'UNDO'}

    tolerance: FloatProperty(
        name="Tolerance",
        description="Max error allowed (lower = more keyframes kept)",
        default=0.001,
        min=0.0001,
        max=0.1,
    )

    selected_bones_only: BoolProperty(
        name="Selected Bones Only", default=False,
    )

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'ARMATURE':
            self.report({'ERROR'}, "Select an armature")
            return {'CANCELLED'}

        action = obj.animation_data.action if obj.animation_data else None
        if action is None:
            self.report({'ERROR'}, "No animation data")
            return {'CANCELLED'}

        import numpy as np
        from ..processing.interpolation import reduce_keyframes

        total_before = 0
        total_after = 0
        bone_names = [b.name for b in obj.pose.bones]

        for fc in action.fcurves:
            if self.selected_bones_only:
                if not any(bname in fc.data_path for bname in bone_names):
                    continue

            n = len(fc.keyframe_points)
            if n < 3:
                continue

            times = np.array([kp.co[0] for kp in fc.keyframe_points])
            values = np.array([kp.co[1] for kp in fc.keyframe_points])

            reduced_times, reduced_values = reduce_keyframes(
                times, values, tolerance=self.tolerance
            )

            total_before += n
            total_after += len(reduced_times)

            if len(reduced_times) < n:
                # Rebuild keyframes
                while len(fc.keyframe_points) > 0:
                    fc.keyframe_points.remove(fc.keyframe_points[0])

                for t, v in zip(reduced_times, reduced_values):
                    fc.keyframe_points.insert(float(t), float(v))

                fc.update()

        removed = total_before - total_after
        self.report({'INFO'},
            f"Reduced: {total_before} → {total_after} keyframes ({removed} removed)"
        )
        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)


# ============================================================
# Resample Animation
# ============================================================

class AIMOCAP_OT_resample_animation(Operator):
    """Resample animation to a different frame rate"""
    bl_idname = "aimocap.resample_animation"
    bl_label = "Resample Animation"
    bl_description = "Change animation frame rate (e.g., 30fps → 60fps)"
    bl_options = {'REGISTER', 'UNDO'}

    target_fps: IntProperty(
        name="Target FPS",
        description="Target frame rate",
        default=60,
        min=1,
        max=240,
    )

    method: EnumProperty(
        name="Method",
        items=[
            ("linear", "Linear", "Linear interpolation"),
            ("cubic", "Cubic", "Cubic spline (smoother)"),
        ],
        default="linear",
    )

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'ARMATURE':
            self.report({'ERROR'}, "Select an armature")
            return {'CANCELLED'}

        action = obj.animation_data.action if obj.animation_data else None
        if action is None:
            self.report({'ERROR'}, "No animation data")
            return {'CANCELLED'}

        import numpy as np
        from ..processing.interpolation import resample_motion

        source_fps = context.scene.render.fps
        if self.target_fps == source_fps:
            self.report({'INFO'}, "Already at target FPS")
            return {'CANCELLED'}

        processed = 0
        for fc in action.fcurves:
            n = len(fc.keyframe_points)
            if n < 2:
                continue

            times = np.array([kp.co[0] for kp in fc.keyframe_points])
            values = np.array([kp.co[1] for kp in fc.keyframe_points])

            resampled = resample_motion(
                values, float(source_fps), float(self.target_fps),
                method=self.method,
            )

            # Rebuild keyframes
            while len(fc.keyframe_points) > 0:
                fc.keyframe_points.remove(fc.keyframe_points[0])

            start_frame = times[0]
            for i, v in enumerate(resampled):
                frame = start_frame + i
                fc.keyframe_points.insert(float(frame), float(v))

            fc.update()
            processed += 1

        self.report({'INFO'}, f"Resampled {processed} channels: {source_fps}fps → {self.target_fps}fps")
        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)


classes = [
    AIMOCAP_OT_smooth_animation,
    AIMOCAP_OT_apply_foot_lock,
    AIMOCAP_OT_cleanup_animation,
    AIMOCAP_OT_reduce_keyframes,
    AIMOCAP_OT_resample_animation,
]
