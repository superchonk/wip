"""
AI Mocap Studio - Capture operators (body, hands, face, holistic).
"""

import bpy
from bpy.types import Operator
from bpy.props import StringProperty, BoolProperty, EnumProperty

from ..core.constants import ADDON_NAME


# Global state for the running capture session
_capture_state = {
    "running": False,
    "recording": False,
    "stream": None,
    "detector": None,
    "hand_detector": None,
    "face_detector": None,
    "holistic_detector": None,
    "retargeter": None,
    "hand_retargeter": None,
    "face_retargeter": None,
    "frame_counter": -1,
    "timer": None,
    "capture_mode": "BODY",
}


def _get_prefs():
    return bpy.context.preferences.addons[ADDON_NAME].preferences


class AIMOCAP_OT_start_webcam(Operator):
    """Start webcam capture and pose detection"""
    bl_idname = "aimocap.start_webcam"
    bl_label = "Start Webcam Capture"
    bl_description = "Start capturing pose from webcam"
    bl_options = {'REGISTER'}

    def execute(self, context):
        if _capture_state["running"]:
            self.report({'WARNING'}, "Capture is already running")
            return {'CANCELLED'}

        prefs = _get_prefs()
        capture_mode = context.scene.aimocap_capture_mode

        try:
            from ..capture.webcam import WebcamCapture
        except ImportError:
            self.report({'ERROR'}, "Dependencies not installed. Go to Preferences > Add-ons > AI Mocap Studio > Install Core")
            return {'CANCELLED'}
        # Open webcam
        stream = WebcamCapture(
            camera_index=prefs.camera_index,
            width=prefs.capture_width,
            height=prefs.capture_height,
            fps=prefs.capture_fps,
        )
        try:
            opened = stream.open()
        except ImportError:
            self.report({'ERROR'}, "OpenCV (cv2) not installed. Go to Preferences > Add-ons > AI Mocap Studio > Install Core")
            return {'CANCELLED'}
        if not opened:
            self.report({'ERROR'}, f"Cannot open camera {prefs.camera_index}")
            return {'CANCELLED'}

        # Store stream first so cleanup can release it on error
        _capture_state["stream"] = stream

        # Create detectors based on capture mode
        try:
            _capture_state["capture_mode"] = capture_mode
            _create_detectors(context, capture_mode, prefs)
            _setup_retargeters(context, capture_mode)
        except Exception as e:
            stream.release()
            _capture_state["stream"] = None
            self.report({'ERROR'}, f"Setup failed: {e}")
            return {'CANCELLED'}
        _capture_state["running"] = True
        _capture_state["frame_counter"] = -1

        from ..ui.viewport_draw import enable_viewport_draw
        # Enable viewport drawing
        if prefs.show_landmarks:
            enable_viewport_draw()

        # Start timer
        wm = context.window_manager
        _capture_state["timer"] = wm.event_timer_add(
            1.0 / prefs.capture_fps, window=context.window
        )
        wm.modal_handler_add(self)

        self.report({'INFO'}, f"Webcam capture started ({capture_mode})")
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if not _capture_state["running"]:
            self.cancel(context)
            return {'CANCELLED'}

        if event.type == 'ESC':
            _capture_state["running"] = False
            self.cancel(context)
            self.report({'INFO'}, "Capture stopped")
            return {'CANCELLED'}

        if event.type == 'TIMER':
            self._process_frame(context)

        return {'PASS_THROUGH'}

    def _process_frame(self, context):
        stream = _capture_state["stream"]
        if stream is None or not stream.is_open:
            _capture_state["running"] = False
            return

        success, frame = stream.read()
        if not success or frame is None:
            return

        prefs = _get_prefs()
        mode = _capture_state["capture_mode"]
        smoothing = prefs.smoothing_factor if prefs.use_smoothing else 0.0
        scale = context.scene.aimocap_scale

        if mode == "HOLISTIC":
            self._process_holistic(context, frame, prefs, smoothing, scale)
        elif mode == "BODY":
            self._process_body(context, frame, prefs, smoothing, scale)
        elif mode == "HANDS":
            self._process_hands(context, frame, prefs, smoothing, scale)
        elif mode == "FACE":
            self._process_face(context, frame, prefs, smoothing, scale)

        # Force viewport redraw
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()

    def _process_body(self, context, frame, prefs, smoothing, scale):
        detector = _capture_state["detector"]
        if detector is None:
            return

        if smoothing > 0:
            result = detector.detect_with_smoothing(frame, smoothing)
        else:
            result = detector.detect(frame)

        if result is None:
            return

        from ..ui.viewport_draw import update_draw_data
        positions = result.get_all_blender_positions(scale=scale)
        confidences = [result.get_confidence(i) for i in range(result.num_landmarks)]
        update_draw_data(positions, confidences, prefs.landmark_scale)

        retargeter = _capture_state["retargeter"]

        if _capture_state["recording"] and retargeter:
            _capture_state["frame_counter"] += 1
            frame_num = context.scene.frame_start + _capture_state["frame_counter"]
            retargeter.apply_pose(result, frame=frame_num, smoothing=smoothing)
            context.scene.frame_set(frame_num)
            _feed_streaming(context)
        elif _is_streaming() and retargeter:
            # Streaming without recording: apply pose without keyframes
            retargeter.apply_pose(result, frame=None, smoothing=smoothing)
            _feed_streaming(context)

    def _process_hands(self, context, frame, prefs, smoothing, scale):
        detector = _capture_state["hand_detector"]
        if detector is None:
            return

        if smoothing > 0:
            results = detector.detect_with_smoothing(frame, smoothing)
        else:
            results = detector.detect(frame)

        left_positions = []
        right_positions = []
        for hand_result in results:
            positions = hand_result.get_all_blender_positions(scale=scale)
            if hand_result.is_left:
                left_positions = positions
            else:
                right_positions = positions

        from ..ui.viewport_draw import update_holistic_draw_data
        update_holistic_draw_data(
            left_hand_positions=left_positions,
            right_hand_positions=right_positions,
            scale=prefs.landmark_scale,
        )

        if _capture_state["recording"] and _capture_state["hand_retargeter"]:
            _capture_state["frame_counter"] += 1
            frame_num = context.scene.frame_start + _capture_state["frame_counter"]
            for hand_result in results:
                side = "L" if hand_result.is_left else "R"
                _capture_state["hand_retargeter"].apply_hand(
                    hand_result.landmarks, side, frame=frame_num, smoothing=smoothing
                )
            context.scene.frame_set(frame_num)

    def _process_face(self, context, frame, prefs, smoothing, scale):
        detector = _capture_state["face_detector"]
        if detector is None:
            return

        if smoothing > 0:
            results = detector.detect_with_smoothing(frame, smoothing)
        else:
            results = detector.detect(frame)

        if not results:
            return

        face_result = results[0]
        face_positions = [
            face_result.get_blender_position(i, scale=scale)
            for i in range(face_result.num_landmarks)
        ]
        face_positions = [p for p in face_positions if p is not None]

        from ..ui.viewport_draw import update_holistic_draw_data
        update_holistic_draw_data(
            face_positions=face_positions,
            scale=prefs.landmark_scale,
        )

        face_retargeter = _capture_state["face_retargeter"]
        blendshapes = getattr(face_result, 'blendshapes', None)

        if _capture_state["recording"] and face_retargeter:
            _capture_state["frame_counter"] += 1
            frame_num = context.scene.frame_start + _capture_state["frame_counter"]
            face_retargeter.apply_blendshapes(
                blendshapes, frame=frame_num, smoothing=smoothing
            )
            pitch, yaw, roll = face_result.get_head_rotation()
            face_retargeter.apply_head_rotation(
                pitch, yaw, roll, frame=frame_num, smoothing=smoothing
            )
            context.scene.frame_set(frame_num)
            _feed_streaming(context, blendshapes=blendshapes)
        elif _is_streaming() and face_retargeter:
            face_retargeter.apply_blendshapes(
                blendshapes, frame=None, smoothing=smoothing
            )
            pitch, yaw, roll = face_result.get_head_rotation()
            face_retargeter.apply_head_rotation(
                pitch, yaw, roll, frame=None, smoothing=smoothing
            )
            _feed_streaming(context, blendshapes=blendshapes)

    def _process_holistic(self, context, frame, prefs, smoothing, scale):
        detector = _capture_state["holistic_detector"]
        if detector is None:
            return

        if smoothing > 0:
            result = detector.detect_with_smoothing(frame, smoothing)
        else:
            result = detector.detect(frame)

        if result.is_empty:
            return

        # Collect all positions for viewport
        body_positions = result.get_body_positions(scale=scale)
        body_confidences = result.get_body_confidences()
        left_hand = result.get_left_hand_positions(scale=scale)
        right_hand = result.get_right_hand_positions(scale=scale)
        face_positions = result.get_face_positions(scale=scale)

        from ..ui.viewport_draw import update_holistic_draw_data
        update_holistic_draw_data(
            body_positions=body_positions,
            body_confidences=body_confidences,
            left_hand_positions=left_hand,
            right_hand_positions=right_hand,
            face_positions=face_positions,
            scale=prefs.landmark_scale,
        )

        # Record keyframes
        if _capture_state["recording"]:
            _capture_state["frame_counter"] += 1
            frame_num = context.scene.frame_start + _capture_state["frame_counter"]

            # Body retarget
            if _capture_state["retargeter"] and result.has_pose:
                from ..detection.body import PoseResult
                body_result = PoseResult(
                    landmarks=result.pose_landmarks.landmark if result.pose_landmarks else None,
                    world_landmarks=result.pose_world_landmarks.landmark if result.pose_world_landmarks else None,
                )
                if result._smoothed_body:
                    body_result._smoothed_positions = result._smoothed_body
                _capture_state["retargeter"].apply_pose(body_result, frame=frame_num, smoothing=smoothing)

            # Hand retarget
            if _capture_state["hand_retargeter"]:
                _capture_state["hand_retargeter"].apply_from_holistic(
                    result, frame=frame_num, smoothing=smoothing
                )

            # Face retarget
            blendshapes = None
            if _capture_state["face_retargeter"] and result.has_face:
                _capture_state["face_retargeter"].apply_from_holistic(
                    result, frame=frame_num, smoothing=smoothing
                )
                blendshapes = getattr(result, 'blendshapes', None)

            context.scene.frame_set(frame_num)
            _feed_streaming(context, blendshapes=blendshapes)

        elif _is_streaming():
            # Streaming without recording: apply pose without keyframes
            if _capture_state["retargeter"] and result.has_pose:
                from ..detection.body import PoseResult
                body_result = PoseResult(
                    landmarks=result.pose_landmarks.landmark if result.pose_landmarks else None,
                    world_landmarks=result.pose_world_landmarks.landmark if result.pose_world_landmarks else None,
                )
                if result._smoothed_body:
                    body_result._smoothed_positions = result._smoothed_body
                _capture_state["retargeter"].apply_pose(body_result, frame=None, smoothing=smoothing)

            if _capture_state["hand_retargeter"]:
                _capture_state["hand_retargeter"].apply_from_holistic(
                    result, frame=None, smoothing=smoothing
                )

            blendshapes = None
            if _capture_state["face_retargeter"] and result.has_face:
                _capture_state["face_retargeter"].apply_from_holistic(
                    result, frame=None, smoothing=smoothing
                )
                blendshapes = getattr(result, 'blendshapes', None)

            _feed_streaming(context, blendshapes=blendshapes)

    def cancel(self, context):
        _cleanup_capture(context)


class AIMOCAP_OT_stop_capture(Operator):
    """Stop the current capture session"""
    bl_idname = "aimocap.stop_capture"
    bl_label = "Stop Capture"
    bl_description = "Stop the current capture session"
    bl_options = {'REGISTER'}

    def execute(self, context):
        if not _capture_state["running"]:
            self.report({'INFO'}, "No capture running")
            return {'CANCELLED'}

        _capture_state["running"] = False
        _cleanup_capture(context)
        self.report({'INFO'}, "Capture stopped")
        return {'FINISHED'}


class AIMOCAP_OT_toggle_recording(Operator):
    """Toggle recording keyframes"""
    bl_idname = "aimocap.toggle_recording"
    bl_label = "Toggle Recording"
    bl_description = "Start/stop recording keyframes to the armature"
    bl_options = {'REGISTER'}

    def execute(self, context):
        if not _capture_state["running"]:
            self.report({'WARNING'}, "Start capture first")
            return {'CANCELLED'}

        mode = _capture_state["capture_mode"]

        # Ensure retargeters are set up
        if not _capture_state["retargeter"] and mode in ("BODY", "HOLISTIC"):
            obj = context.active_object
            if obj and obj.type == 'ARMATURE':
                rig_type = context.scene.aimocap_rig_type
                from ..retarget.mapper import PoseRetargeter
                _capture_state["retargeter"] = PoseRetargeter(
                    obj, rig_type=rig_type, scale=context.scene.aimocap_scale
                )
            elif mode == "BODY":
                self.report({'ERROR'}, "Select an armature to record to")
                return {'CANCELLED'}

        if not _capture_state["hand_retargeter"] and mode in ("HANDS", "HOLISTIC"):
            obj = context.active_object
            if obj and obj.type == 'ARMATURE':
                rig_type = context.scene.aimocap_rig_type
                from ..retarget.hands import HandRetargeter
                _capture_state["hand_retargeter"] = HandRetargeter(obj, rig_type=rig_type)

        if not _capture_state["face_retargeter"] and mode in ("FACE", "HOLISTIC"):
            _setup_face_retargeter(context)

        _capture_state["recording"] = not _capture_state["recording"]
        if _capture_state["recording"]:
            _capture_state["frame_counter"] = -1
            self.report({'INFO'}, "Recording started")
        else:
            self.report({'INFO'}, "Recording stopped")

        return {'FINISHED'}


class AIMOCAP_OT_capture_from_video(Operator):
    """Process a video file and apply motion capture"""
    bl_idname = "aimocap.capture_from_video"
    bl_label = "Capture from Video"
    bl_description = "Process a video file for motion capture"
    bl_options = {'REGISTER', 'UNDO'}

    filepath: StringProperty(subtype='FILE_PATH')

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'ARMATURE':
            self.report({'ERROR'}, "Select an armature first")
            return {'CANCELLED'}

        if not self.filepath:
            self.report({'ERROR'}, "No video file specified")
            return {'CANCELLED'}

        prefs = _get_prefs()
        capture_mode = context.scene.aimocap_capture_mode

        try:
            from ..capture.video import VideoCapture
        except ImportError:
            self.report({'ERROR'}, "Dependencies not installed. Go to Preferences > Add-ons > AI Mocap Studio > Install Core")
            return {'CANCELLED'}
        # Open video
        stream = VideoCapture(self.filepath)
        try:
            opened = stream.open()
        except ImportError:
            self.report({'ERROR'}, "OpenCV (cv2) not installed. Go to Preferences > Add-ons > AI Mocap Studio > Install Core")
            return {'CANCELLED'}
        if not opened:
            self.report({'ERROR'}, f"Cannot open video: {self.filepath}")
            return {'CANCELLED'}

        smoothing = prefs.smoothing_factor if prefs.use_smoothing else 0.0
        scale = context.scene.aimocap_scale
        rig_type = context.scene.aimocap_rig_type

        if capture_mode == "HOLISTIC":
            processed = self._process_holistic_video(
                context, stream, prefs, smoothing, scale, rig_type
            )
        else:
            processed = self._process_body_video(
                context, stream, prefs, smoothing, scale, rig_type
            )

        stream.release()
        context.scene.frame_set(context.scene.frame_start)
        self.report({'INFO'}, f"Processed {processed} frames from video")
        return {'FINISHED'}

    def _process_body_video(self, context, stream, prefs, smoothing, scale, rig_type):
        from ..detection.body import PoseDetector
        from ..retarget.mapper import PoseRetargeter
        detector = PoseDetector(
            min_detection_confidence=prefs.min_detection_confidence,
            min_tracking_confidence=prefs.min_tracking_confidence,
        )
        retargeter = PoseRetargeter(
            context.active_object, rig_type=rig_type, scale=scale
        )

        frame_num = context.scene.frame_start
        processed = 0

        while True:
            success, frame = stream.read()
            if not success:
                break

            result = (detector.detect_with_smoothing(frame, smoothing)
                      if smoothing > 0 else detector.detect(frame))

            if result is not None:
                retargeter.apply_pose(result, frame=frame_num, smoothing=smoothing)
                processed += 1
            frame_num += 1

        context.scene.frame_end = max(context.scene.frame_end, frame_num - 1)
        detector.release()
        return processed

    def _process_holistic_video(self, context, stream, prefs, smoothing, scale, rig_type):
        from ..detection.holistic import HolisticDetector
        from ..retarget.mapper import PoseRetargeter
        from ..retarget.hands import HandRetargeter
        from ..retarget.face import FaceRetargeter
        detector = HolisticDetector(
            min_detection_confidence=prefs.min_detection_confidence,
            min_tracking_confidence=prefs.min_tracking_confidence,
        )
        retargeter = PoseRetargeter(
            context.active_object, rig_type=rig_type, scale=scale
        )
        hand_retargeter = HandRetargeter(context.active_object, rig_type=rig_type)

        face_retargeter = None
        face_mesh = context.scene.aimocap_face_mesh
        if face_mesh:
            face_obj = bpy.data.objects.get(face_mesh)
            if face_obj:
                face_retargeter = FaceRetargeter(
                    mesh_obj=face_obj, armature_obj=context.active_object
                )

        frame_num = context.scene.frame_start
        processed = 0

        while True:
            success, frame = stream.read()
            if not success:
                break

            result = (detector.detect_with_smoothing(frame, smoothing)
                      if smoothing > 0 else detector.detect(frame))

            if not result.is_empty:
                # Body
                if result.has_pose:
                    from ..detection.body import PoseResult
                    body_result = PoseResult(
                        landmarks=result.pose_landmarks.landmark,
                        world_landmarks=(
                            result.pose_world_landmarks.landmark
                            if result.pose_world_landmarks else None
                        ),
                    )
                    if result._smoothed_body:
                        body_result._smoothed_positions = result._smoothed_body
                    retargeter.apply_pose(body_result, frame=frame_num, smoothing=smoothing)

                # Hands
                hand_retargeter.apply_from_holistic(result, frame=frame_num, smoothing=smoothing)

                # Face
                if face_retargeter and result.has_face:
                    face_retargeter.apply_from_holistic(result, frame=frame_num, smoothing=smoothing)

                processed += 1
            frame_num += 1

        context.scene.frame_end = max(context.scene.frame_end, frame_num - 1)
        detector.release()
        return processed

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}


class AIMOCAP_OT_capture_from_image(Operator):
    """Capture a static pose from a single image file"""
    bl_idname = "aimocap.capture_from_image"
    bl_label = "Capture from Image"
    bl_description = "Detect pose in an image and apply it as a static pose to the armature"
    bl_options = {'REGISTER', 'UNDO'}

    filepath: StringProperty(subtype='FILE_PATH')
    filter_glob: StringProperty(
        default="*.png;*.jpg;*.jpeg;*.bmp;*.tiff;*.tga;*.webp",
        options={'HIDDEN'},
    )

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'ARMATURE':
            self.report({'ERROR'}, "Select an armature first")
            return {'CANCELLED'}

        if not self.filepath:
            self.report({'ERROR'}, "No image file specified")
            return {'CANCELLED'}

        try:
            import cv2
        except ImportError:
            self.report({'ERROR'}, "OpenCV (cv2) not installed. Go to Preferences > Add-ons > AI Mocap Studio > Install Core")
            return {'CANCELLED'}

        # Load image
        frame = cv2.imread(self.filepath)
        if frame is None:
            self.report({'ERROR'}, f"Cannot read image: {self.filepath}")
            return {'CANCELLED'}

        prefs = _get_prefs()
        capture_mode = context.scene.aimocap_capture_mode
        smoothing = 0.0  # No smoothing needed for a single frame
        scale = context.scene.aimocap_scale
        rig_type = context.scene.aimocap_rig_type

        if capture_mode == "HOLISTIC":
            ok = self._apply_holistic(context, frame, prefs, scale, rig_type)
        elif capture_mode == "FACE":
            ok = self._apply_face(context, frame, prefs)
        elif capture_mode == "HANDS":
            ok = self._apply_hands(context, frame, prefs, rig_type)
        else:
            ok = self._apply_body(context, frame, prefs, scale, rig_type)

        if ok:
            import os
            name = os.path.basename(self.filepath)
            self.report({'INFO'}, f"Static pose applied from: {name}")
        else:
            self.report({'WARNING'}, "No pose detected in the image")
        return {'FINISHED'}

    def _apply_body(self, context, frame, prefs, scale, rig_type):
        from ..detection.body import PoseDetector
        from ..retarget.mapper import PoseRetargeter

        detector = PoseDetector(
            min_detection_confidence=prefs.min_detection_confidence,
            min_tracking_confidence=prefs.min_tracking_confidence,
            static_image_mode=True,
        )
        result = detector.detect(frame)
        detector.release()

        if result is None:
            return False

        retargeter = PoseRetargeter(
            context.active_object, rig_type=rig_type, scale=scale,
        )
        retargeter.apply_pose(result, frame=None, smoothing=0.0)
        return True

    def _apply_holistic(self, context, frame, prefs, scale, rig_type):
        from ..detection.holistic import HolisticDetector
        from ..retarget.mapper import PoseRetargeter
        from ..retarget.hands import HandRetargeter
        from ..retarget.face import FaceRetargeter

        detector = HolisticDetector(
            min_detection_confidence=prefs.min_detection_confidence,
            min_tracking_confidence=prefs.min_tracking_confidence,
            static_image_mode=True,
        )
        result = detector.detect(frame)
        detector.release()

        if result.is_empty:
            return False

        obj = context.active_object

        if result.has_pose:
            from ..detection.body import PoseResult
            body_result = PoseResult(
                landmarks=result.pose_landmarks.landmark,
                world_landmarks=(
                    result.pose_world_landmarks.landmark
                    if result.pose_world_landmarks else None
                ),
            )
            retargeter = PoseRetargeter(obj, rig_type=rig_type, scale=scale)
            retargeter.apply_pose(body_result, frame=None, smoothing=0.0)

        hand_retargeter = HandRetargeter(obj, rig_type=rig_type)
        hand_retargeter.apply_from_holistic(result, frame=None, smoothing=0.0)

        face_mesh_name = context.scene.aimocap_face_mesh
        if face_mesh_name and result.has_face:
            face_obj = bpy.data.objects.get(face_mesh_name)
            if face_obj:
                face_retargeter = FaceRetargeter(
                    mesh_obj=face_obj, armature_obj=obj,
                )
                face_retargeter.apply_from_holistic(result, frame=None, smoothing=0.0)

        return True

    def _apply_face(self, context, frame, prefs):
        from ..detection.face import FaceDetector
        from ..retarget.face import FaceRetargeter

        detector = FaceDetector(
            min_detection_confidence=prefs.min_detection_confidence,
            min_tracking_confidence=prefs.min_tracking_confidence,
            static_image_mode=True,
        )
        results = detector.detect(frame)
        detector.release()

        if not results:
            return False

        face_mesh_name = context.scene.aimocap_face_mesh
        face_obj = bpy.data.objects.get(face_mesh_name) if face_mesh_name else None
        armature_obj = context.active_object
        if armature_obj and armature_obj.type != 'ARMATURE':
            armature_obj = None

        if face_obj or armature_obj:
            face_retargeter = FaceRetargeter(
                mesh_obj=face_obj, armature_obj=armature_obj,
            )
            face_result = results[0]
            blendshapes = getattr(face_result, 'blendshapes', None)
            face_retargeter.apply_blendshapes(blendshapes, frame=None, smoothing=0.0)
            pitch, yaw, roll = face_result.get_head_rotation()
            face_retargeter.apply_head_rotation(pitch, yaw, roll, frame=None, smoothing=0.0)

        return True

    def _apply_hands(self, context, frame, prefs, rig_type):
        from ..detection.hands import HandDetector
        from ..retarget.hands import HandRetargeter

        detector = HandDetector(
            min_detection_confidence=prefs.min_detection_confidence,
            min_tracking_confidence=prefs.min_tracking_confidence,
            static_image_mode=True,
        )
        results = detector.detect(frame)
        detector.release()

        if not results:
            return False

        obj = context.active_object
        if obj and obj.type == 'ARMATURE':
            hand_retargeter = HandRetargeter(obj, rig_type=rig_type)
            for hand_result in results:
                side = "L" if hand_result.is_left else "R"
                hand_retargeter.apply_hand(
                    hand_result.landmarks, side, frame=None, smoothing=0.0,
                )

        return True

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}


class AIMOCAP_OT_create_face_shapekeys(Operator):
    """Create ARKit blendshape Shape Keys on the selected mesh"""
    bl_idname = "aimocap.create_face_shapekeys"
    bl_label = "Create ARKit Shape Keys"
    bl_description = "Create all 52 ARKit blendshape Shape Keys on the active mesh"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "Select a mesh object")
            return {'CANCELLED'}

        from ..retarget.face import FaceRetargeter
        retargeter = FaceRetargeter(mesh_obj=obj)
        created = retargeter.create_shape_keys()
        self.report({'INFO'}, f"Created {created} Shape Keys ({retargeter.mapped_count} total)")
        return {'FINISHED'}


class AIMOCAP_OT_install_dependencies(Operator):
    """Install required Python packages"""
    bl_idname = "aimocap.install_dependencies"
    bl_label = "Install Dependencies"
    bl_description = "Install OpenCV, MediaPipe and other required packages"
    bl_options = {'REGISTER'}

    def execute(self, context):
        from ..core.dependencies import install_all_missing

        success, message = install_all_missing()
        if success:
            self.report({'INFO'}, "All dependencies installed successfully")
        else:
            self.report({'ERROR'}, f"Installation issues: {message}")

        return {'FINISHED'}


# ============================================================
# Helper functions
# ============================================================

def _create_detectors(context, capture_mode, prefs):
    """Create appropriate detectors based on capture mode."""
    det_conf = prefs.min_detection_confidence
    trk_conf = prefs.min_tracking_confidence

    if capture_mode == "BODY":
        from ..detection.body import PoseDetector
        _capture_state["detector"] = PoseDetector(
            min_detection_confidence=det_conf,
            min_tracking_confidence=trk_conf,
        )
    elif capture_mode == "HANDS":
        from ..detection.hands import HandDetector
        _capture_state["hand_detector"] = HandDetector(
            min_detection_confidence=det_conf,
            min_tracking_confidence=trk_conf,
        )
    elif capture_mode == "FACE":
        from ..detection.face import FaceDetector
        _capture_state["face_detector"] = FaceDetector(
            min_detection_confidence=det_conf,
            min_tracking_confidence=trk_conf,
        )
    elif capture_mode == "HOLISTIC":
        from ..detection.holistic import HolisticDetector
        _capture_state["holistic_detector"] = HolisticDetector(
            min_detection_confidence=det_conf,
            min_tracking_confidence=trk_conf,
        )


def _setup_retargeters(context, capture_mode):
    """Setup retargeters based on capture mode and selected objects."""
    obj = context.active_object
    rig_type = context.scene.aimocap_rig_type
    scale = context.scene.aimocap_scale

    if obj and obj.type == 'ARMATURE':
        if capture_mode in ("BODY", "HOLISTIC"):
            from ..retarget.mapper import PoseRetargeter
            _capture_state["retargeter"] = PoseRetargeter(
                obj, rig_type=rig_type, scale=scale
            )
        if capture_mode in ("HANDS", "HOLISTIC"):
            from ..retarget.hands import HandRetargeter
            _capture_state["hand_retargeter"] = HandRetargeter(
                obj, rig_type=rig_type
            )

    if capture_mode in ("FACE", "HOLISTIC"):
        _setup_face_retargeter(context)


def _setup_face_retargeter(context):
    """Setup face retargeter from scene settings."""
    face_mesh_name = context.scene.aimocap_face_mesh
    face_obj = bpy.data.objects.get(face_mesh_name) if face_mesh_name else None

    armature_obj = context.active_object
    if armature_obj and armature_obj.type != 'ARMATURE':
        armature_obj = None

    if face_obj or armature_obj:
        from ..retarget.face import FaceRetargeter
        _capture_state["face_retargeter"] = FaceRetargeter(
            mesh_obj=face_obj, armature_obj=armature_obj
        )


def _is_streaming():
    """Check if any streaming output is active."""
    from ..streaming.bridge import is_any_streaming
    return is_any_streaming()


def _feed_streaming(context, blendshapes=None):
    """Send current pose to active streams."""
    from ..streaming.bridge import feed_body_frame, is_any_streaming
    if not is_any_streaming():
        return
    obj = context.active_object
    if obj and obj.type == 'ARMATURE':
        feed_body_frame(obj, blendshapes=blendshapes)
    elif _capture_state["retargeter"] and _capture_state["retargeter"].armature:
        feed_body_frame(_capture_state["retargeter"].armature, blendshapes=blendshapes)


def _cleanup_capture(context):
    """Clean up capture resources."""
    # Remove timer
    if _capture_state["timer"] is not None:
        wm = context.window_manager
        wm.event_timer_remove(_capture_state["timer"])
        _capture_state["timer"] = None

    # Release stream
    if _capture_state["stream"] is not None:
        _capture_state["stream"].release()
        _capture_state["stream"] = None

    # Release detectors
    for key in ("detector", "hand_detector", "face_detector", "holistic_detector"):
        if _capture_state[key] is not None:
            _capture_state[key].release()
            _capture_state[key] = None

    _capture_state["running"] = False
    _capture_state["recording"] = False
    _capture_state["retargeter"] = None
    _capture_state["hand_retargeter"] = None
    _capture_state["face_retargeter"] = None
    _capture_state["frame_counter"] = -1
    _capture_state["capture_mode"] = "BODY"

    from ..ui.viewport_draw import disable_viewport_draw
    disable_viewport_draw()


# List of classes to register
classes = [
    AIMOCAP_OT_start_webcam,
    AIMOCAP_OT_stop_capture,
    AIMOCAP_OT_toggle_recording,
    AIMOCAP_OT_capture_from_video,
    AIMOCAP_OT_capture_from_image,
    AIMOCAP_OT_create_face_shapekeys,
    AIMOCAP_OT_install_dependencies,
]
