"""
AI Mocap Studio - Export operators.
"""

import bpy
from bpy.types import Operator
from bpy.props import StringProperty, EnumProperty, BoolProperty, FloatProperty

from ..export.bvh import export_bvh
from ..export.fbx import export_fbx
from ..export.csv_export import export_csv
from ..export.c3d import export_c3d


class AIMOCAP_OT_export_bvh(Operator):
    """Export captured animation as BVH"""
    bl_idname = "aimocap.export_bvh"
    bl_label = "Export BVH"
    bl_description = "Export the armature animation as a BVH file"
    bl_options = {'REGISTER'}

    filepath: StringProperty(subtype='FILE_PATH', default="mocap_export.bvh")
    filter_glob: StringProperty(default="*.bvh", options={'HIDDEN'})

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'ARMATURE':
            self.report({'ERROR'}, "Select an armature")
            return {'CANCELLED'}

        success, result = export_bvh(obj, self.filepath)
        if success:
            self.report({'INFO'}, f"Exported to: {result}")
        else:
            self.report({'ERROR'}, f"Export failed: {result}")

        return {'FINISHED'}

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}


class AIMOCAP_OT_export_fbx(Operator):
    """Export captured animation as FBX"""
    bl_idname = "aimocap.export_fbx"
    bl_label = "Export FBX"
    bl_description = "Export the armature animation as an FBX file (UE-compatible)"
    bl_options = {'REGISTER'}

    filepath: StringProperty(subtype='FILE_PATH', default="mocap_export.fbx")
    filter_glob: StringProperty(default="*.fbx", options={'HIDDEN'})
    global_scale: FloatProperty(
        name="Scale",
        description="Global scale (1.0 = metres, 100.0 for UE centimetres)",
        default=1.0,
        min=0.001,
        max=1000.0,
    )
    bake_anim: BoolProperty(
        name="Bake Animation",
        description="Bake animation curves for export",
        default=True,
    )

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'ARMATURE':
            self.report({'ERROR'}, "Select an armature")
            return {'CANCELLED'}

        success, result = export_fbx(
            obj, self.filepath,
            scale=self.global_scale,
            bake_anim=self.bake_anim,
        )
        if success:
            self.report({'INFO'}, f"Exported to: {result}")
        else:
            self.report({'ERROR'}, f"Export failed: {result}")

        return {'FINISHED'}

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}


class AIMOCAP_OT_export_csv(Operator):
    """Export captured animation as CSV"""
    bl_idname = "aimocap.export_csv"
    bl_label = "Export CSV"
    bl_description = "Export bone rotations and positions to a CSV file"
    bl_options = {'REGISTER'}

    filepath: StringProperty(subtype='FILE_PATH', default="mocap_export.csv")
    filter_glob: StringProperty(default="*.csv", options={'HIDDEN'})
    csv_mode: EnumProperty(
        name="Layout",
        description="CSV layout mode",
        items=[
            ("WIDE", "Wide", "One row per frame, all bones as columns"),
            ("LONG", "Long", "One row per bone per frame"),
        ],
        default="WIDE",
    )
    include_position: BoolProperty(
        name="Positions",
        description="Include world-space bone head positions",
        default=True,
    )
    include_rotation: BoolProperty(
        name="Rotations",
        description="Include quaternion rotations",
        default=True,
    )

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'ARMATURE':
            self.report({'ERROR'}, "Select an armature")
            return {'CANCELLED'}

        success, result = export_csv(
            obj, self.filepath,
            mode=self.csv_mode,
            include_position=self.include_position,
            include_rotation=self.include_rotation,
        )
        if success:
            self.report({'INFO'}, f"Exported to: {result}")
        else:
            self.report({'ERROR'}, f"Export failed: {result}")

        return {'FINISHED'}

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}


class AIMOCAP_OT_export_c3d(Operator):
    """Export captured animation as C3D"""
    bl_idname = "aimocap.export_c3d"
    bl_label = "Export C3D"
    bl_description = "Export bone positions as 3D markers in C3D format"
    bl_options = {'REGISTER'}

    filepath: StringProperty(subtype='FILE_PATH', default="mocap_export.c3d")
    filter_glob: StringProperty(default="*.c3d", options={'HIDDEN'})
    scale_to_mm: FloatProperty(
        name="Scale to mm",
        description="Multiply Blender metres by this to convert to millimetres",
        default=1000.0,
        min=0.001,
        max=100000.0,
    )

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'ARMATURE':
            self.report({'ERROR'}, "Select an armature")
            return {'CANCELLED'}

        success, result = export_c3d(
            obj, self.filepath,
            scale_to_mm=self.scale_to_mm,
        )
        if success:
            self.report({'INFO'}, f"Exported to: {result}")
        else:
            self.report({'ERROR'}, f"Export failed: {result}")

        return {'FINISHED'}

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}


classes = [
    AIMOCAP_OT_export_bvh,
    AIMOCAP_OT_export_fbx,
    AIMOCAP_OT_export_csv,
    AIMOCAP_OT_export_c3d,
]
