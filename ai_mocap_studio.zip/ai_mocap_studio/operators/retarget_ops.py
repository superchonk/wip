"""
AI Mocap Studio - Retarget operators.
"""

import bpy
from bpy.types import Operator


class AIMOCAP_OT_reset_pose(Operator):
    """Reset armature to rest pose"""
    bl_idname = "aimocap.reset_pose"
    bl_label = "Reset Pose"
    bl_description = "Reset the armature to its rest pose"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'ARMATURE':
            self.report({'ERROR'}, "Select an armature")
            return {'CANCELLED'}

        for pose_bone in obj.pose.bones:
            pose_bone.rotation_quaternion = (1, 0, 0, 0)
            pose_bone.rotation_euler = (0, 0, 0)
            pose_bone.location = (0, 0, 0)
            pose_bone.scale = (1, 1, 1)

        self.report({'INFO'}, "Pose reset")
        return {'FINISHED'}


class AIMOCAP_OT_clear_keyframes(Operator):
    """Clear all mocap keyframes from the armature"""
    bl_idname = "aimocap.clear_keyframes"
    bl_label = "Clear Keyframes"
    bl_description = "Remove all animation keyframes from the armature"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'ARMATURE':
            self.report({'ERROR'}, "Select an armature")
            return {'CANCELLED'}

        if obj.animation_data and obj.animation_data.action:
            bpy.data.actions.remove(obj.animation_data.action)
            self.report({'INFO'}, "Keyframes cleared")
        else:
            self.report({'INFO'}, "No keyframes to clear")

        return {'FINISHED'}


class AIMOCAP_OT_auto_detect_rig(Operator):
    """Auto-detect the rig type of the selected armature"""
    bl_idname = "aimocap.auto_detect_rig"
    bl_label = "Auto Detect Rig"
    bl_description = "Automatically detect whether the armature is Rigify, Mixamo, or generic"
    bl_options = {'REGISTER'}

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'ARMATURE':
            self.report({'ERROR'}, "Select an armature")
            return {'CANCELLED'}

        bone_names = [b.name for b in obj.data.bones]

        # Check for Auto Rig Pro (c_ prefix, .l/.r/.x suffix)
        arp_bones = ["c_root_master.x", "c_spine_01.x", "c_arm_fk.l", "c_thigh_fk.l"]
        if sum(1 for b in arp_bones if b in bone_names) >= 3:
            context.scene.aimocap_rig_type = "AUTO_RIG_PRO"
            self.report({'INFO'}, "Detected: Auto Rig Pro (FK)")
            return {'FINISHED'}

        # Check for Rigify
        rigify_bones = ["spine", "spine.001", "upper_arm.L", "thigh.L"]
        if sum(1 for b in rigify_bones if b in bone_names) >= 3:
            context.scene.aimocap_rig_type = "RIGIFY"
            self.report({'INFO'}, "Detected: Rigify rig")
            return {'FINISHED'}

        # Check for Mixamo
        mixamo_bones = ["mixamorig:Hips", "mixamorig:Spine", "mixamorig:LeftArm"]
        if sum(1 for b in mixamo_bones if b in bone_names) >= 2:
            context.scene.aimocap_rig_type = "MIXAMO"
            self.report({'INFO'}, "Detected: Mixamo rig")
            return {'FINISHED'}

        # Default to simple
        context.scene.aimocap_rig_type = "SIMPLE"
        self.report({'INFO'}, "Using generic rig mapping")
        return {'FINISHED'}


classes = [
    AIMOCAP_OT_reset_pose,
    AIMOCAP_OT_clear_keyframes,
    AIMOCAP_OT_auto_detect_rig,
]
