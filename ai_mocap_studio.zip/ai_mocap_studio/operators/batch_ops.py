"""
AI Mocap Studio - Batch video processing operators.
"""

import os
import bpy
from bpy.types import Operator
from bpy.props import StringProperty, BoolProperty, EnumProperty, IntProperty

from ..core.constants import ADDON_NAME
from ..capture.batch import BatchProcessor, find_videos_in_directory
from ..capture.takes import get_take_manager
from ..capture.video import VideoCapture
from ..detection.body import PoseDetector
from ..detection.holistic import HolisticDetector
from ..retarget.mapper import PoseRetargeter
from ..retarget.hands import HandRetargeter
from ..retarget.face import FaceRetargeter
from ..models.base import coco_to_mediapipe_landmarks


def _get_prefs():
    return bpy.context.preferences.addons[ADDON_NAME].preferences


class AIMOCAP_OT_batch_process(Operator):
    """Process multiple video files for motion capture"""
    bl_idname = "aimocap.batch_process"
    bl_label = "Batch Process Videos"
    bl_description = "Process all video files in a directory"
    bl_options = {'REGISTER', 'UNDO'}

    directory: StringProperty(
        name="Video Directory",
        subtype='DIR_PATH',
    )

    recursive: BoolProperty(
        name="Include Subdirectories",
        description="Search for videos in subdirectories too",
        default=False,
    )

    capture_mode: EnumProperty(
        name="Capture Mode",
        items=[
            ("BODY", "Body Only", "Track body pose only"),
            ("HOLISTIC", "Holistic", "Track body + hands + face"),
        ],
        default="BODY",
    )

    create_takes: BoolProperty(
        name="Create Takes",
        description="Create a named take for each video",
        default=True,
    )

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'ARMATURE':
            self.report({'ERROR'}, "Select an armature first")
            return {'CANCELLED'}

        if not self.directory:
            self.report({'ERROR'}, "No directory selected")
            return {'CANCELLED'}

        # Find videos
        videos = find_videos_in_directory(self.directory, self.recursive)
        if not videos:
            self.report({'ERROR'}, "No video files found in directory")
            return {'CANCELLED'}

        prefs = _get_prefs()
        smoothing = prefs.smoothing_factor if prefs.use_smoothing else 0.0
        scale = context.scene.aimocap_scale
        rig_type = context.scene.aimocap_rig_type

        take_mgr = get_take_manager()
        take_mgr.load_from_scene(context.scene)

        total_processed = 0
        total_frames = 0
        errors = 0

        for video_path in videos:
            video_name = os.path.splitext(os.path.basename(video_path))[0]

            # Create take
            take = None
            if self.create_takes:
                take = take_mgr.create_take(
                    context.scene, obj,
                    name=video_name,
                    capture_mode=self.capture_mode,
                    source="batch",
                    source_path=video_path,
                )

            # Open video
            stream = VideoCapture(video_path)
            if not stream.open():
                if take:
                    take_mgr.delete_take(context.scene, take.name)
                errors += 1
                continue

            # Process
            try:
                if self.capture_mode == "HOLISTIC":
                    frames = self._process_holistic(
                        context, stream, obj, prefs, smoothing, scale, rig_type
                    )
                else:
                    frames = self._process_body(
                        context, stream, obj, prefs, smoothing, scale, rig_type
                    )

                if take:
                    take_mgr.finish_take(context.scene, take.name, frames)

                total_frames += frames
                total_processed += 1
            except Exception as e:
                if take:
                    take_mgr.delete_take(context.scene, take.name)
                errors += 1
                print(f"Batch error on {video_path}: {e}")
            finally:
                stream.release()

        context.scene.frame_set(context.scene.frame_start)

        msg = f"Batch: {total_processed}/{len(videos)} videos, {total_frames} frames"
        if errors > 0:
            msg += f", {errors} errors"
        self.report({'INFO'}, msg)
        return {'FINISHED'}

    def _process_body(self, context, stream, armature, prefs, smoothing, scale, rig_type):
        detector = PoseDetector(
            min_detection_confidence=prefs.min_detection_confidence,
            min_tracking_confidence=prefs.min_tracking_confidence,
        )
        retargeter = PoseRetargeter(armature, rig_type=rig_type, scale=scale)

        frame_num = context.scene.frame_start
        processed = 0

        while True:
            success, frame = stream.read()
            if not success:
                break

            result = (detector.detect_with_smoothing(frame, smoothing)
                      if smoothing > 0 else detector.detect(frame))

            if result is not None:
                retargeter.apply_pose(result, frame=frame_num, smoothing=smoothing)
                processed += 1
            frame_num += 1

        context.scene.frame_end = max(context.scene.frame_end, frame_num - 1)
        detector.release()
        return processed

    def _process_holistic(self, context, stream, armature, prefs, smoothing, scale, rig_type):
        detector = HolisticDetector(
            min_detection_confidence=prefs.min_detection_confidence,
            min_tracking_confidence=prefs.min_tracking_confidence,
        )
        retargeter = PoseRetargeter(armature, rig_type=rig_type, scale=scale)
        hand_retargeter = HandRetargeter(armature, rig_type=rig_type)

        face_retargeter = None
        face_mesh = context.scene.aimocap_face_mesh
        if face_mesh:
            face_obj = bpy.data.objects.get(face_mesh)
            if face_obj:
                face_retargeter = FaceRetargeter(
                    mesh_obj=face_obj, armature_obj=armature
                )

        frame_num = context.scene.frame_start
        processed = 0

        while True:
            success, frame = stream.read()
            if not success:
                break

            result = (detector.detect_with_smoothing(frame, smoothing)
                      if smoothing > 0 else detector.detect(frame))

            if not result.is_empty:
                if result.has_pose:
                    from ..detection.body import PoseResult
                    body_result = PoseResult(
                        landmarks=result.pose_landmarks.landmark,
                        world_landmarks=(
                            result.pose_world_landmarks.landmark
                            if result.pose_world_landmarks else None
                        ),
                    )
                    if result._smoothed_body:
                        body_result._smoothed_positions = result._smoothed_body
                    retargeter.apply_pose(body_result, frame=frame_num, smoothing=smoothing)

                hand_retargeter.apply_from_holistic(result, frame=frame_num, smoothing=smoothing)

                if face_retargeter and result.has_face:
                    face_retargeter.apply_from_holistic(result, frame=frame_num, smoothing=smoothing)

                processed += 1
            frame_num += 1

        context.scene.frame_end = max(context.scene.frame_end, frame_num - 1)
        detector.release()
        return processed


class AIMOCAP_OT_batch_multiperson(Operator):
    """Batch process videos with multi-person detection"""
    bl_idname = "aimocap.batch_multiperson"
    bl_label = "Batch Multi-Person"
    bl_description = "Process videos detecting all persons, creating separate takes"
    bl_options = {'REGISTER', 'UNDO'}

    directory: StringProperty(
        name="Video Directory",
        subtype='DIR_PATH',
    )

    max_persons: IntProperty(
        name="Max Persons",
        default=5, min=1, max=20,
    )

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        if not self.directory:
            self.report({'ERROR'}, "No directory selected")
            return {'CANCELLED'}

        # Need armatures in scene
        armatures = [obj for obj in context.scene.objects if obj.type == 'ARMATURE']
        if not armatures:
            self.report({'ERROR'}, "No armatures in scene")
            return {'CANCELLED'}

        prefs = _get_prefs()

        # Load YOLO model
        from ..models.manager import get_model_manager
        manager = get_model_manager()

        if not manager.active_model_name or manager.active_model_name != "yolo_pose":
            try:
                manager.load_model(
                    "yolo_pose",
                    use_gpu=prefs.use_gpu,
                    variant=prefs.yolo_variant,
                )
            except Exception as e:
                self.report({'ERROR'}, f"Cannot load YOLO: {e}")
                return {'CANCELLED'}

        model = manager.active_model
        videos = find_videos_in_directory(self.directory)
        if not videos:
            self.report({'ERROR'}, "No video files found")
            return {'CANCELLED'}

        from ..detection.tracker import PersonTracker

        smoothing = prefs.smoothing_factor if prefs.use_smoothing else 0.0
        scale = context.scene.aimocap_scale
        rig_type = context.scene.aimocap_rig_type

        take_mgr = get_take_manager()
        take_mgr.load_from_scene(context.scene)

        total_processed = 0
        total_persons = 0

        for video_path in videos:
            video_name = os.path.splitext(os.path.basename(video_path))[0]

            stream = VideoCapture(video_path)
            if not stream.open():
                continue

            tracker = PersonTracker(
                max_missing_frames=15,
                max_persons=self.max_persons,
            )

            # Per-person retargeters and takes
            person_retargeters = {}
            person_takes = {}
            person_frames = {}

            frame_num = context.scene.frame_start

            while True:
                success, frame = stream.read()
                if not success:
                    break

                result = model.detect(frame)
                if result is None:
                    frame_num += 1
                    continue

                active_tracks = tracker.update(result)

                for track_id, track in active_tracks.items():
                    # Create retargeter/take for new person
                    if track_id not in person_retargeters:
                        if len(person_retargeters) >= len(armatures):
                            # Skip — no free armatures
                            continue
                        arm_idx = len(person_retargeters)
                        arm = armatures[arm_idx]

                        take_name = f"{video_name}_P{track_id}"
                        take = take_mgr.create_take(
                            context.scene, arm,
                            name=take_name,
                            capture_mode="BODY",
                            person_id=track_id,
                            source="batch_multiperson",
                            source_path=video_path,
                        )
                        person_retargeters[track_id] = PoseRetargeter(
                            arm, rig_type=rig_type, scale=scale
                        )
                        person_takes[track_id] = take_name
                        person_frames[track_id] = 0
                        total_persons += 1

                    # Retarget
                    retargeter = person_retargeters[track_id]
                    landmarks = coco_to_mediapipe_landmarks(
                        track.keypoints, frame.shape[1], frame.shape[0]
                    )
                    if landmarks is not None:
                        # Convert Keypoint objects to Blender-space coordinates
                        from ..utils.math_utils import mediapipe_to_blender_coords
                        positions_3d = []
                        for kp in landmarks:
                            pos = mediapipe_to_blender_coords(kp.x, kp.y, kp.z, 1.0)
                            positions_3d.append((pos[0], pos[1], pos[2]))

                        retargeter.apply_triangulated_pose(
                            positions_3d, scale=scale, frame=frame_num, smoothing=smoothing
                        )
                        person_frames[track_id] = person_frames.get(track_id, 0) + 1

                frame_num += 1

            # Finish takes
            for track_id, take_name in person_takes.items():
                take_mgr.finish_take(
                    context.scene, take_name,
                    person_frames.get(track_id, 0)
                )

            stream.release()
            context.scene.frame_end = max(context.scene.frame_end, frame_num - 1)
            total_processed += 1

        context.scene.frame_set(context.scene.frame_start)
        self.report({'INFO'},
                    f"Batch: {total_processed} videos, {total_persons} persons tracked")
        return {'FINISHED'}


classes = [
    AIMOCAP_OT_batch_process,
    AIMOCAP_OT_batch_multiperson,
]
