"""
AI Mocap Studio - Multi-person capture operators.

Uses YOLO-Pose for multi-person detection + PersonTracker for
persistent ID tracking across frames. Each tracked person can
record to a separate armature/action.
"""

import bpy
from bpy.types import Operator
from bpy.props import IntProperty, EnumProperty, BoolProperty

from ..core.constants import ADDON_NAME
from ..capture.webcam import WebcamCapture
from ..capture.takes import get_take_manager
from ..detection.tracker import PersonTracker
from ..retarget.mapper import PoseRetargeter
from ..models.base import coco_to_mediapipe_landmarks
from ..ui.viewport_draw import enable_viewport_draw, disable_viewport_draw
from ..utils.threading_utils import ThreadSafeData


# Global state for multi-person capture
_mp_state = {
    "running": False,
    "recording": False,
    "stream": None,
    "model": None,
    "tracker": None,
    "retargeters": {},         # {track_id: PoseRetargeter}
    "armatures": {},           # {track_id: armature_obj}
    "frame_counter": 0,
    "timer": None,
    "max_persons": 5,
    "auto_assign": True,       # Auto-assign new persons to armatures
    "active_person": -1,       # -1 = all, 0+ = specific person
}


def _get_prefs():
    return bpy.context.preferences.addons[ADDON_NAME].preferences


class AIMOCAP_OT_start_multiperson(Operator):
    """Start multi-person capture using YOLO-Pose"""
    bl_idname = "aimocap.start_multiperson"
    bl_label = "Start Multi-Person Capture"
    bl_description = "Detect and track multiple persons simultaneously"
    bl_options = {'REGISTER'}

    max_persons: IntProperty(
        name="Max Persons",
        description="Maximum number of persons to track",
        default=5, min=1, max=20,
    )

    def execute(self, context):
        if _mp_state["running"]:
            self.report({'WARNING'}, "Multi-person capture already running")
            return {'CANCELLED'}

        prefs = _get_prefs()

        # Load YOLO model
        from ..models.manager import get_model_manager
        manager = get_model_manager()

        if not manager.active_model_name or manager.active_model_name != "yolo_pose":
            try:
                manager.load_model(
                    "yolo_pose",
                    use_gpu=prefs.use_gpu,
                    variant=prefs.yolo_variant,
                )
            except Exception as e:
                self.report({'ERROR'}, f"Cannot load YOLO model: {e}")
                return {'CANCELLED'}

        model = manager.active_model
        if model is None:
            self.report({'ERROR'}, "YOLO model not available")
            return {'CANCELLED'}

        # Open webcam
        stream = WebcamCapture(
            camera_index=prefs.camera_index,
            width=prefs.capture_width,
            height=prefs.capture_height,
            fps=prefs.capture_fps,
        )
        if not stream.open():
            self.report({'ERROR'}, f"Cannot open camera {prefs.camera_index}")
            return {'CANCELLED'}

        # Init tracker
        try:
            tracker = PersonTracker(
                max_missing_frames=15,
                iou_threshold=0.3,
                max_persons=self.max_persons,
            )
        except Exception as e:
            stream.release()
            self.report({'ERROR'}, f"Tracker init failed: {e}")
            return {'CANCELLED'}

        _mp_state["stream"] = stream
        _mp_state["model"] = model
        _mp_state["tracker"] = tracker
        _mp_state["running"] = True
        _mp_state["recording"] = False
        _mp_state["frame_counter"] = -1
        _mp_state["retargeters"] = {}
        _mp_state["armatures"] = {}
        _mp_state["max_persons"] = self.max_persons

        if prefs.show_landmarks:
            enable_viewport_draw()

        # Start timer
        wm = context.window_manager
        _mp_state["timer"] = wm.event_timer_add(
            1.0 / prefs.capture_fps, window=context.window
        )
        wm.modal_handler_add(self)

        self.report({'INFO'}, f"Multi-person capture started (max {self.max_persons})")
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if not _mp_state["running"]:
            self.cancel(context)
            return {'CANCELLED'}

        if event.type == 'ESC':
            _mp_state["running"] = False
            self.cancel(context)
            self.report({'INFO'}, "Multi-person capture stopped")
            return {'CANCELLED'}

        if event.type == 'TIMER':
            self._process_frame(context)

        return {'PASS_THROUGH'}

    def _process_frame(self, context):
        stream = _mp_state["stream"]
        model = _mp_state["model"]
        tracker = _mp_state["tracker"]

        if stream is None or not stream.is_open:
            _mp_state["running"] = False
            return

        success, frame = stream.read()
        if not success or frame is None:
            return

        # Detect all persons
        result = model.detect(frame)
        if result is None:
            return

        # Update tracker
        active_tracks = tracker.update(result)

        prefs = _get_prefs()
        smoothing = prefs.smoothing_factor if prefs.use_smoothing else 0.0
        scale = context.scene.aimocap_scale

        # Viewport: draw all tracked persons
        self._update_viewport(active_tracks, scale, prefs)

        # Record keyframes
        if _mp_state["recording"]:
            _mp_state["frame_counter"] += 1
            frame_num = context.scene.frame_start + _mp_state["frame_counter"]

            for track_id, track in active_tracks.items():
                # Check if we should record this person
                active = _mp_state["active_person"]
                if active >= 0 and track_id != active:
                    continue

                retargeter = _mp_state["retargeters"].get(track_id)
                if retargeter is None:
                    continue

                # Convert COCO keypoints to MediaPipe format
                landmarks = coco_to_mediapipe_landmarks(
                    track.keypoints, frame.shape[1], frame.shape[0]
                )
                if landmarks is None:
                    continue

                # Convert Keypoint objects to Blender-space coordinates
                from ..utils.math_utils import mediapipe_to_blender_coords
                positions_3d = []
                for kp in landmarks:
                    pos = mediapipe_to_blender_coords(kp.x, kp.y, kp.z, 1.0)
                    positions_3d.append((pos[0], pos[1], pos[2]))

                retargeter.apply_triangulated_pose(
                    positions_3d, scale=scale, frame=frame_num, smoothing=smoothing
                )

            context.scene.frame_set(frame_num)

        # Force viewport redraw
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()

    def _update_viewport(self, active_tracks, scale, prefs):
        """Update viewport drawing for all tracked persons."""
        from ..ui.viewport_draw import update_draw_data

        # Combine all persons' positions for viewport
        all_positions = []
        all_confidences = []

        for track_id, track in active_tracks.items():
            for kp in track.keypoints:
                # Convert to Blender coords (approximate for viewport)
                x = (kp.x - 0.5) * scale
                y = 0
                z = (0.5 - kp.y) * scale
                all_positions.append((x, y, z))
                all_confidences.append(kp.confidence)

        if all_positions:
            update_draw_data(all_positions, all_confidences, prefs.landmark_scale)

    def cancel(self, context):
        _cleanup_multiperson(context)


class AIMOCAP_OT_stop_multiperson(Operator):
    """Stop multi-person capture"""
    bl_idname = "aimocap.stop_multiperson"
    bl_label = "Stop Multi-Person"
    bl_options = {'REGISTER'}

    def execute(self, context):
        if not _mp_state["running"]:
            self.report({'INFO'}, "No multi-person capture running")
            return {'CANCELLED'}

        _mp_state["running"] = False
        _cleanup_multiperson(context)
        self.report({'INFO'}, "Multi-person capture stopped")
        return {'FINISHED'}


class AIMOCAP_OT_toggle_multiperson_recording(Operator):
    """Toggle recording for multi-person capture"""
    bl_idname = "aimocap.toggle_multiperson_recording"
    bl_label = "Toggle Multi-Person Recording"
    bl_options = {'REGISTER'}

    def execute(self, context):
        if not _mp_state["running"]:
            self.report({'WARNING'}, "Start multi-person capture first")
            return {'CANCELLED'}

        _mp_state["recording"] = not _mp_state["recording"]

        if _mp_state["recording"]:
            _mp_state["frame_counter"] = -1

            # Create takes for each assigned person
            take_mgr = get_take_manager()
            take_mgr.load_from_scene(context.scene)

            tracker = _mp_state["tracker"]
            for track_id, armature in _mp_state["armatures"].items():
                take = take_mgr.create_take(
                    context.scene, armature,
                    name=f"Person_{track_id}",
                    capture_mode="BODY",
                    person_id=track_id,
                    source="webcam_multiperson",
                )

            self.report({'INFO'}, "Multi-person recording started")
        else:
            # Finish takes
            take_mgr = get_take_manager()
            take_mgr.load_from_scene(context.scene)
            for track_id in _mp_state["armatures"]:
                take_name = f"Person_{track_id}"
                take_mgr.finish_take(
                    context.scene, take_name, _mp_state["frame_counter"]
                )

            self.report({'INFO'},
                        f"Recording stopped ({_mp_state['frame_counter']} frames)")

        return {'FINISHED'}


class AIMOCAP_OT_assign_person_armature(Operator):
    """Assign an armature to a tracked person"""
    bl_idname = "aimocap.assign_person_armature"
    bl_label = "Assign Armature to Person"
    bl_description = "Link a tracked person to an armature for retargeting"
    bl_options = {'REGISTER'}

    person_id: IntProperty(
        name="Person ID",
        description="Tracked person ID to assign",
        default=0, min=0,
    )

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'ARMATURE':
            self.report({'ERROR'}, "Select an armature first")
            return {'CANCELLED'}

        rig_type = context.scene.aimocap_rig_type
        scale = context.scene.aimocap_scale

        retargeter = PoseRetargeter(obj, rig_type=rig_type, scale=scale)
        _mp_state["retargeters"][self.person_id] = retargeter
        _mp_state["armatures"][self.person_id] = obj

        self.report({'INFO'}, f"Armature '{obj.name}' assigned to Person {self.person_id}")
        return {'FINISHED'}


class AIMOCAP_OT_auto_assign_armatures(Operator):
    """Auto-assign armatures to detected persons"""
    bl_idname = "aimocap.auto_assign_armatures"
    bl_label = "Auto-Assign Armatures"
    bl_description = "Automatically assign available armatures to tracked persons"
    bl_options = {'REGISTER'}

    def execute(self, context):
        tracker = _mp_state.get("tracker")
        if tracker is None:
            self.report({'ERROR'}, "Start multi-person capture first")
            return {'CANCELLED'}

        # Find all armatures in scene
        armatures = [obj for obj in context.scene.objects if obj.type == 'ARMATURE']
        if not armatures:
            self.report({'ERROR'}, "No armatures in scene")
            return {'CANCELLED'}

        rig_type = context.scene.aimocap_rig_type
        scale = context.scene.aimocap_scale

        active_tracks = tracker.active_tracks
        assigned = 0
        arm_idx = 0

        for track_id, track in active_tracks.items():
            if arm_idx >= len(armatures):
                break
            if track_id in _mp_state["retargeters"]:
                continue

            arm = armatures[arm_idx]
            arm_idx += 1
            retargeter = PoseRetargeter(arm, rig_type=rig_type, scale=scale)
            _mp_state["retargeters"][track_id] = retargeter
            _mp_state["armatures"][track_id] = arm
            assigned += 1

        self.report({'INFO'}, f"Assigned {assigned} armatures to persons")
        return {'FINISHED'}


class AIMOCAP_OT_select_active_person(Operator):
    """Select which person to focus on or record"""
    bl_idname = "aimocap.select_active_person"
    bl_label = "Select Active Person"
    bl_options = {'REGISTER'}

    person_id: IntProperty(
        name="Person ID",
        description="-1 = all persons, 0+ = specific person",
        default=-1, min=-1,
    )

    def execute(self, context):
        _mp_state["active_person"] = self.person_id
        if self.person_id == -1:
            self.report({'INFO'}, "Recording all persons")
        else:
            self.report({'INFO'}, f"Recording Person {self.person_id} only")
        return {'FINISHED'}


# ============================================================
# Cleanup
# ============================================================

def _cleanup_multiperson(context):
    """Release multi-person capture resources."""
    if _mp_state["timer"]:
        context.window_manager.event_timer_remove(_mp_state["timer"])
        _mp_state["timer"] = None

    if _mp_state["stream"]:
        _mp_state["stream"].release()
        _mp_state["stream"] = None

    if _mp_state["tracker"]:
        _mp_state["tracker"].reset()
        _mp_state["tracker"] = None

    _mp_state["model"] = None
    _mp_state["running"] = False
    _mp_state["recording"] = False
    _mp_state["retargeters"] = {}
    _mp_state["armatures"] = {}
    _mp_state["frame_counter"] = -1
    _mp_state["active_person"] = -1

    disable_viewport_draw()


classes = [
    AIMOCAP_OT_start_multiperson,
    AIMOCAP_OT_stop_multiperson,
    AIMOCAP_OT_toggle_multiperson_recording,
    AIMOCAP_OT_assign_person_armature,
    AIMOCAP_OT_auto_assign_armatures,
    AIMOCAP_OT_select_active_person,
]
