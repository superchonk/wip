"""
AI Mocap Studio - Threading utilities for non-blocking capture.
"""

import threading
import queue


class CaptureThread(threading.Thread):
    """Thread that runs the capture loop and puts frames into a queue."""

    def __init__(self, capture_func, frame_queue, max_queue_size=2):
        super().__init__(daemon=True)
        self.capture_func = capture_func
        self.frame_queue = frame_queue
        self._stop_event = threading.Event()
        self.max_queue_size = max_queue_size

    def run(self):
        while not self._stop_event.is_set():
            frame_data = self.capture_func()
            if frame_data is None:
                break
            # Drop old frames if queue is full (keep latest)
            if self.frame_queue.qsize() >= self.max_queue_size:
                try:
                    self.frame_queue.get_nowait()
                except queue.Empty:
                    pass
            self.frame_queue.put(frame_data)

    def stop(self):
        self._stop_event.set()

    @property
    def is_stopped(self):
        return self._stop_event.is_set()


class ThreadSafeData:
    """Thread-safe container for sharing data between capture thread and Blender."""

    def __init__(self):
        self._lock = threading.Lock()
        self._data = None
        self._new_data = False

    def set(self, data):
        with self._lock:
            self._data = data
            self._new_data = True

    def get(self):
        with self._lock:
            self._new_data = False
            return self._data

    @property
    def has_new_data(self):
        with self._lock:
            return self._new_data
