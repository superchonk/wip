"""
AI Mocap Studio - Bone mapping tables for different rig types.
"""

from ..core.constants import MP_LANDMARK

# Rigify metarig bone names mapped to MediaPipe landmark pairs
# Each entry: bone_name -> (head_landmark_idx, tail_landmark_idx)
RIGIFY_MAPPING = {
    # Spine chain
    "spine": (MP_LANDMARK["LEFT_HIP"], MP_LANDMARK["RIGHT_HIP"]),
    "spine.001": (None, None),  # computed from hips midpoint to shoulders midpoint
    "spine.002": (None, None),
    "spine.003": (MP_LANDMARK["LEFT_SHOULDER"], MP_LANDMARK["RIGHT_SHOULDER"]),

    # Head
    "spine.004": (None, MP_LANDMARK["NOSE"]),  # neck
    "spine.005": (MP_LANDMARK["NOSE"], None),   # head top (estimated)
    "spine.006": (None, None),

    # Left arm
    "shoulder.L": (None, MP_LANDMARK["LEFT_SHOULDER"]),
    "upper_arm.L": (MP_LANDMARK["LEFT_SHOULDER"], MP_LANDMARK["LEFT_ELBOW"]),
    "forearm.L": (MP_LANDMARK["LEFT_ELBOW"], MP_LANDMARK["LEFT_WRIST"]),
    "hand.L": (MP_LANDMARK["LEFT_WRIST"], MP_LANDMARK["LEFT_INDEX"]),

    # Right arm
    "shoulder.R": (None, MP_LANDMARK["RIGHT_SHOULDER"]),
    "upper_arm.R": (MP_LANDMARK["RIGHT_SHOULDER"], MP_LANDMARK["RIGHT_ELBOW"]),
    "forearm.R": (MP_LANDMARK["RIGHT_ELBOW"], MP_LANDMARK["RIGHT_WRIST"]),
    "hand.R": (MP_LANDMARK["RIGHT_WRIST"], MP_LANDMARK["RIGHT_INDEX"]),

    # Left leg
    "thigh.L": (MP_LANDMARK["LEFT_HIP"], MP_LANDMARK["LEFT_KNEE"]),
    "shin.L": (MP_LANDMARK["LEFT_KNEE"], MP_LANDMARK["LEFT_ANKLE"]),
    "foot.L": (MP_LANDMARK["LEFT_ANKLE"], MP_LANDMARK["LEFT_FOOT_INDEX"]),

    # Right leg
    "thigh.R": (MP_LANDMARK["RIGHT_HIP"], MP_LANDMARK["RIGHT_KNEE"]),
    "shin.R": (MP_LANDMARK["RIGHT_KNEE"], MP_LANDMARK["RIGHT_ANKLE"]),
    "foot.R": (MP_LANDMARK["RIGHT_ANKLE"], MP_LANDMARK["RIGHT_FOOT_INDEX"]),
}

# Simple humanoid rig mapping (generic armature)
SIMPLE_MAPPING = {
    "Hips": (MP_LANDMARK["LEFT_HIP"], MP_LANDMARK["RIGHT_HIP"]),
    "Spine": (None, None),
    "Chest": (MP_LANDMARK["LEFT_SHOULDER"], MP_LANDMARK["RIGHT_SHOULDER"]),
    "Neck": (None, MP_LANDMARK["NOSE"]),
    "Head": (MP_LANDMARK["NOSE"], None),

    "LeftUpperArm": (MP_LANDMARK["LEFT_SHOULDER"], MP_LANDMARK["LEFT_ELBOW"]),
    "LeftLowerArm": (MP_LANDMARK["LEFT_ELBOW"], MP_LANDMARK["LEFT_WRIST"]),
    "LeftHand": (MP_LANDMARK["LEFT_WRIST"], MP_LANDMARK["LEFT_INDEX"]),

    "RightUpperArm": (MP_LANDMARK["RIGHT_SHOULDER"], MP_LANDMARK["RIGHT_ELBOW"]),
    "RightLowerArm": (MP_LANDMARK["RIGHT_ELBOW"], MP_LANDMARK["RIGHT_WRIST"]),
    "RightHand": (MP_LANDMARK["RIGHT_WRIST"], MP_LANDMARK["RIGHT_INDEX"]),

    "LeftUpperLeg": (MP_LANDMARK["LEFT_HIP"], MP_LANDMARK["LEFT_KNEE"]),
    "LeftLowerLeg": (MP_LANDMARK["LEFT_KNEE"], MP_LANDMARK["LEFT_ANKLE"]),
    "LeftFoot": (MP_LANDMARK["LEFT_ANKLE"], MP_LANDMARK["LEFT_FOOT_INDEX"]),

    "RightUpperLeg": (MP_LANDMARK["RIGHT_HIP"], MP_LANDMARK["RIGHT_KNEE"]),
    "RightLowerLeg": (MP_LANDMARK["RIGHT_KNEE"], MP_LANDMARK["RIGHT_ANKLE"]),
    "RightFoot": (MP_LANDMARK["RIGHT_ANKLE"], MP_LANDMARK["RIGHT_FOOT_INDEX"]),
}

# Mixamo rig mapping
MIXAMO_MAPPING = {
    "mixamorig:Hips": (MP_LANDMARK["LEFT_HIP"], MP_LANDMARK["RIGHT_HIP"]),
    "mixamorig:Spine": (None, None),
    "mixamorig:Spine1": (None, None),
    "mixamorig:Spine2": (MP_LANDMARK["LEFT_SHOULDER"], MP_LANDMARK["RIGHT_SHOULDER"]),
    "mixamorig:Neck": (None, MP_LANDMARK["NOSE"]),
    "mixamorig:Head": (MP_LANDMARK["NOSE"], None),

    "mixamorig:LeftShoulder": (None, MP_LANDMARK["LEFT_SHOULDER"]),
    "mixamorig:LeftArm": (MP_LANDMARK["LEFT_SHOULDER"], MP_LANDMARK["LEFT_ELBOW"]),
    "mixamorig:LeftForeArm": (MP_LANDMARK["LEFT_ELBOW"], MP_LANDMARK["LEFT_WRIST"]),
    "mixamorig:LeftHand": (MP_LANDMARK["LEFT_WRIST"], MP_LANDMARK["LEFT_INDEX"]),

    "mixamorig:RightShoulder": (None, MP_LANDMARK["RIGHT_SHOULDER"]),
    "mixamorig:RightArm": (MP_LANDMARK["RIGHT_SHOULDER"], MP_LANDMARK["RIGHT_ELBOW"]),
    "mixamorig:RightForeArm": (MP_LANDMARK["RIGHT_ELBOW"], MP_LANDMARK["RIGHT_WRIST"]),
    "mixamorig:RightHand": (MP_LANDMARK["RIGHT_WRIST"], MP_LANDMARK["RIGHT_INDEX"]),

    "mixamorig:LeftUpLeg": (MP_LANDMARK["LEFT_HIP"], MP_LANDMARK["LEFT_KNEE"]),
    "mixamorig:LeftLeg": (MP_LANDMARK["LEFT_KNEE"], MP_LANDMARK["LEFT_ANKLE"]),
    "mixamorig:LeftFoot": (MP_LANDMARK["LEFT_ANKLE"], MP_LANDMARK["LEFT_FOOT_INDEX"]),

    "mixamorig:RightUpLeg": (MP_LANDMARK["RIGHT_HIP"], MP_LANDMARK["RIGHT_KNEE"]),
    "mixamorig:RightLeg": (MP_LANDMARK["RIGHT_KNEE"], MP_LANDMARK["RIGHT_ANKLE"]),
    "mixamorig:RightFoot": (MP_LANDMARK["RIGHT_ANKLE"], MP_LANDMARK["RIGHT_FOOT_INDEX"]),
}


# Auto Rig Pro mapping (FK bones with c_ prefix, .l/.r/.x suffix)
# Auto Rig Pro uses FK bones for motion capture retargeting.
# Bone names: c_<name>.l / c_<name>.r / c_<name>.x
AUTO_RIG_PRO_MAPPING = {
    # Spine chain
    "c_root_master.x": (MP_LANDMARK["LEFT_HIP"], MP_LANDMARK["RIGHT_HIP"]),
    "c_spine_01.x": (None, None),
    "c_spine_02.x": (None, None),
    "c_spine_03.x": (MP_LANDMARK["LEFT_SHOULDER"], MP_LANDMARK["RIGHT_SHOULDER"]),

    # Neck / Head
    "c_neck.x": (None, MP_LANDMARK["NOSE"]),
    "c_head.x": (MP_LANDMARK["NOSE"], None),

    # Left arm
    "c_shoulder.l": (None, MP_LANDMARK["LEFT_SHOULDER"]),
    "c_arm_fk.l": (MP_LANDMARK["LEFT_SHOULDER"], MP_LANDMARK["LEFT_ELBOW"]),
    "c_forearm_fk.l": (MP_LANDMARK["LEFT_ELBOW"], MP_LANDMARK["LEFT_WRIST"]),
    "c_hand_fk.l": (MP_LANDMARK["LEFT_WRIST"], MP_LANDMARK["LEFT_INDEX"]),

    # Right arm
    "c_shoulder.r": (None, MP_LANDMARK["RIGHT_SHOULDER"]),
    "c_arm_fk.r": (MP_LANDMARK["RIGHT_SHOULDER"], MP_LANDMARK["RIGHT_ELBOW"]),
    "c_forearm_fk.r": (MP_LANDMARK["RIGHT_ELBOW"], MP_LANDMARK["RIGHT_WRIST"]),
    "c_hand_fk.r": (MP_LANDMARK["RIGHT_WRIST"], MP_LANDMARK["RIGHT_INDEX"]),

    # Left leg
    "c_thigh_fk.l": (MP_LANDMARK["LEFT_HIP"], MP_LANDMARK["LEFT_KNEE"]),
    "c_leg_fk.l": (MP_LANDMARK["LEFT_KNEE"], MP_LANDMARK["LEFT_ANKLE"]),
    "c_foot_fk.l": (MP_LANDMARK["LEFT_ANKLE"], MP_LANDMARK["LEFT_FOOT_INDEX"]),
    "c_toes_fk.l": (MP_LANDMARK["LEFT_FOOT_INDEX"], None),

    # Right leg
    "c_thigh_fk.r": (MP_LANDMARK["RIGHT_HIP"], MP_LANDMARK["RIGHT_KNEE"]),
    "c_leg_fk.r": (MP_LANDMARK["RIGHT_KNEE"], MP_LANDMARK["RIGHT_ANKLE"]),
    "c_foot_fk.r": (MP_LANDMARK["RIGHT_ANKLE"], MP_LANDMARK["RIGHT_FOOT_INDEX"]),
    "c_toes_fk.r": (MP_LANDMARK["RIGHT_FOOT_INDEX"], None),
}


def get_mapping_for_rig(rig_type):
    """Return the appropriate bone mapping for the given rig type."""
    mappings = {
        "RIGIFY": RIGIFY_MAPPING,
        "SIMPLE": SIMPLE_MAPPING,
        "MIXAMO": MIXAMO_MAPPING,
        "AUTO_RIG_PRO": AUTO_RIG_PRO_MAPPING,
    }
    return mappings.get(rig_type, SIMPLE_MAPPING)
