"""
AI Mocap Studio - Math utilities for pose calculations.
"""

from mathutils import Vector, Quaternion


def landmarks_to_vectors(landmarks, indices):
    """Convert MediaPipe landmarks at given indices to mathutils Vectors."""
    vectors = []
    for idx in indices:
        lm = landmarks[idx]
        vectors.append(Vector((lm.x, lm.y, lm.z)))
    return vectors


def midpoint(v1, v2):
    """Calculate midpoint between two vectors."""
    return (v1 + v2) / 2.0


def direction_vector(v_from, v_to):
    """Calculate normalized direction vector from one point to another."""
    d = v_to - v_from
    if d.length > 0.0001:
        d.normalize()
    return d


def vector_to_rotation(vec, up=Vector((0, 0, 1))):
    """Convert a direction vector to a quaternion rotation."""
    if vec.length < 0.0001:
        return Quaternion()
    vec = vec.normalized()
    return up.rotation_difference(vec)


def compute_bone_rotation(head_pos, tail_pos, rest_direction=Vector((0, 1, 0))):
    """
    Compute the rotation quaternion for a bone given head and tail positions.
    rest_direction: the bone's direction in rest pose (typically Y-up in Blender).
    """
    bone_dir = tail_pos - head_pos
    if bone_dir.length < 0.0001:
        return Quaternion()
    bone_dir.normalize()
    return rest_direction.rotation_difference(bone_dir)


def mediapipe_to_blender_coords(x, y, z, scale=1.0):
    """
    Convert MediaPipe coordinate system to Blender.
    MediaPipe: X right, Y down, Z toward camera
    Blender:   X right, Y forward, Z up
    """
    return Vector((
        x * scale,
        -z * scale,
        -y * scale,
    ))


def smooth_value(current, previous, factor=0.3):
    """
    Exponential smoothing between current and previous value.
    factor: 0.0 = no smoothing, 0.9 = heavy smoothing
    """
    if previous is None:
        return current
    return previous * factor + current * (1.0 - factor)


def smooth_vector(current, previous, factor=0.3):
    """Apply exponential smoothing to a Vector."""
    if previous is None:
        return current.copy()
    return previous.lerp(current, 1.0 - factor)


def smooth_quaternion(current, previous, factor=0.3):
    """Apply exponential smoothing to a Quaternion."""
    if previous is None:
        return current.copy()
    # Fix quaternion double-cover: ensure shortest path SLERP
    if previous.dot(current) < 0:
        current = Quaternion((-current.w, -current.x, -current.y, -current.z))
    return previous.slerp(current, 1.0 - factor)


def clamp(value, min_val, max_val):
    """Clamp a value between min and max."""
    return max(min_val, min(max_val, value))


def remap(value, from_min, from_max, to_min, to_max):
    """Remap a value from one range to another."""
    if abs(from_max - from_min) < 0.0001:
        return to_min
    normalized = (value - from_min) / (from_max - from_min)
    return to_min + normalized * (to_max - to_min)
