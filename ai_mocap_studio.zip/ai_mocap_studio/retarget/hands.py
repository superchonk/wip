"""
AI Mocap Studio - Hand retargeting: maps hand landmarks to finger bones.
"""

import bpy
import math
from mathutils import Vector, Quaternion

from ..core.constants import MP_HAND_LANDMARK
from ..utils.math_utils import (
    compute_bone_rotation,
    smooth_quaternion,
    mediapipe_to_blender_coords,
)


# Finger bone chain definitions for different rig types
FINGER_BONE_CHAINS = {
    "RIGIFY": {
        "thumb.L": {
            "bones": ["thumb.01.L", "thumb.02.L", "thumb.03.L"],
            "landmarks": [1, 2, 3, 4],  # CMC, MCP, IP, TIP
        },
        "index.L": {
            "bones": ["f_index.01.L", "f_index.02.L", "f_index.03.L"],
            "landmarks": [5, 6, 7, 8],  # MCP, PIP, DIP, TIP
        },
        "middle.L": {
            "bones": ["f_middle.01.L", "f_middle.02.L", "f_middle.03.L"],
            "landmarks": [9, 10, 11, 12],
        },
        "ring.L": {
            "bones": ["f_ring.01.L", "f_ring.02.L", "f_ring.03.L"],
            "landmarks": [13, 14, 15, 16],
        },
        "pinky.L": {
            "bones": ["f_pinky.01.L", "f_pinky.02.L", "f_pinky.03.L"],
            "landmarks": [17, 18, 19, 20],
        },
        "thumb.R": {
            "bones": ["thumb.01.R", "thumb.02.R", "thumb.03.R"],
            "landmarks": [1, 2, 3, 4],
        },
        "index.R": {
            "bones": ["f_index.01.R", "f_index.02.R", "f_index.03.R"],
            "landmarks": [5, 6, 7, 8],
        },
        "middle.R": {
            "bones": ["f_middle.01.R", "f_middle.02.R", "f_middle.03.R"],
            "landmarks": [9, 10, 11, 12],
        },
        "ring.R": {
            "bones": ["f_ring.01.R", "f_ring.02.R", "f_ring.03.R"],
            "landmarks": [13, 14, 15, 16],
        },
        "pinky.R": {
            "bones": ["f_pinky.01.R", "f_pinky.02.R", "f_pinky.03.R"],
            "landmarks": [17, 18, 19, 20],
        },
    },
    "MIXAMO": {
        "thumb.L": {
            "bones": [
                "mixamorig:LeftHandThumb1",
                "mixamorig:LeftHandThumb2",
                "mixamorig:LeftHandThumb3",
            ],
            "landmarks": [1, 2, 3, 4],
        },
        "index.L": {
            "bones": [
                "mixamorig:LeftHandIndex1",
                "mixamorig:LeftHandIndex2",
                "mixamorig:LeftHandIndex3",
            ],
            "landmarks": [5, 6, 7, 8],
        },
        "middle.L": {
            "bones": [
                "mixamorig:LeftHandMiddle1",
                "mixamorig:LeftHandMiddle2",
                "mixamorig:LeftHandMiddle3",
            ],
            "landmarks": [9, 10, 11, 12],
        },
        "ring.L": {
            "bones": [
                "mixamorig:LeftHandRing1",
                "mixamorig:LeftHandRing2",
                "mixamorig:LeftHandRing3",
            ],
            "landmarks": [13, 14, 15, 16],
        },
        "pinky.L": {
            "bones": [
                "mixamorig:LeftHandPinky1",
                "mixamorig:LeftHandPinky2",
                "mixamorig:LeftHandPinky3",
            ],
            "landmarks": [17, 18, 19, 20],
        },
        "thumb.R": {
            "bones": [
                "mixamorig:RightHandThumb1",
                "mixamorig:RightHandThumb2",
                "mixamorig:RightHandThumb3",
            ],
            "landmarks": [1, 2, 3, 4],
        },
        "index.R": {
            "bones": [
                "mixamorig:RightHandIndex1",
                "mixamorig:RightHandIndex2",
                "mixamorig:RightHandIndex3",
            ],
            "landmarks": [5, 6, 7, 8],
        },
        "middle.R": {
            "bones": [
                "mixamorig:RightHandMiddle1",
                "mixamorig:RightHandMiddle2",
                "mixamorig:RightHandMiddle3",
            ],
            "landmarks": [9, 10, 11, 12],
        },
        "ring.R": {
            "bones": [
                "mixamorig:RightHandRing1",
                "mixamorig:RightHandRing2",
                "mixamorig:RightHandRing3",
            ],
            "landmarks": [13, 14, 15, 16],
        },
        "pinky.R": {
            "bones": [
                "mixamorig:RightHandPinky1",
                "mixamorig:RightHandPinky2",
                "mixamorig:RightHandPinky3",
            ],
            "landmarks": [17, 18, 19, 20],
        },
    },
    "SIMPLE": {
        "thumb.L": {
            "bones": ["LeftThumb1", "LeftThumb2", "LeftThumb3"],
            "landmarks": [1, 2, 3, 4],
        },
        "index.L": {
            "bones": ["LeftIndex1", "LeftIndex2", "LeftIndex3"],
            "landmarks": [5, 6, 7, 8],
        },
        "middle.L": {
            "bones": ["LeftMiddle1", "LeftMiddle2", "LeftMiddle3"],
            "landmarks": [9, 10, 11, 12],
        },
        "ring.L": {
            "bones": ["LeftRing1", "LeftRing2", "LeftRing3"],
            "landmarks": [13, 14, 15, 16],
        },
        "pinky.L": {
            "bones": ["LeftPinky1", "LeftPinky2", "LeftPinky3"],
            "landmarks": [17, 18, 19, 20],
        },
        "thumb.R": {
            "bones": ["RightThumb1", "RightThumb2", "RightThumb3"],
            "landmarks": [1, 2, 3, 4],
        },
        "index.R": {
            "bones": ["RightIndex1", "RightIndex2", "RightIndex3"],
            "landmarks": [5, 6, 7, 8],
        },
        "middle.R": {
            "bones": ["RightMiddle1", "RightMiddle2", "RightMiddle3"],
            "landmarks": [9, 10, 11, 12],
        },
        "ring.R": {
            "bones": ["RightRing1", "RightRing2", "RightRing3"],
            "landmarks": [13, 14, 15, 16],
        },
        "pinky.R": {
            "bones": ["RightPinky1", "RightPinky2", "RightPinky3"],
            "landmarks": [17, 18, 19, 20],
        },
    },
    "AUTO_RIG_PRO": {
        "thumb.L": {
            "bones": ["c_thumb1.l", "c_thumb2.l", "c_thumb3.l"],
            "landmarks": [1, 2, 3, 4],
        },
        "index.L": {
            "bones": ["c_index1.l", "c_index2.l", "c_index3.l"],
            "landmarks": [5, 6, 7, 8],
        },
        "middle.L": {
            "bones": ["c_middle1.l", "c_middle2.l", "c_middle3.l"],
            "landmarks": [9, 10, 11, 12],
        },
        "ring.L": {
            "bones": ["c_ring1.l", "c_ring2.l", "c_ring3.l"],
            "landmarks": [13, 14, 15, 16],
        },
        "pinky.L": {
            "bones": ["c_pinky1.l", "c_pinky2.l", "c_pinky3.l"],
            "landmarks": [17, 18, 19, 20],
        },
        "thumb.R": {
            "bones": ["c_thumb1.r", "c_thumb2.r", "c_thumb3.r"],
            "landmarks": [1, 2, 3, 4],
        },
        "index.R": {
            "bones": ["c_index1.r", "c_index2.r", "c_index3.r"],
            "landmarks": [5, 6, 7, 8],
        },
        "middle.R": {
            "bones": ["c_middle1.r", "c_middle2.r", "c_middle3.r"],
            "landmarks": [9, 10, 11, 12],
        },
        "ring.R": {
            "bones": ["c_ring1.r", "c_ring2.r", "c_ring3.r"],
            "landmarks": [13, 14, 15, 16],
        },
        "pinky.R": {
            "bones": ["c_pinky1.r", "c_pinky2.r", "c_pinky3.r"],
            "landmarks": [17, 18, 19, 20],
        },
    },
}


class HandRetargeter:
    """Maps hand landmarks to finger bones on an armature."""

    def __init__(self, armature_obj, rig_type="SIMPLE"):
        self.armature = armature_obj
        self.rig_type = rig_type
        self.finger_chains = FINGER_BONE_CHAINS.get(rig_type, FINGER_BONE_CHAINS["SIMPLE"])
        self._prev_rotations = {}
        self._rest_directions = {}
        self._cache_rest_directions()

    def _cache_rest_directions(self):
        """Cache rest pose bone directions for each finger bone."""
        if self.armature is None or self.armature.type != 'ARMATURE':
            return
        for chain_name, chain_data in self.finger_chains.items():
            for bone_name in chain_data["bones"]:
                bone = self.armature.data.bones.get(bone_name)
                if bone:
                    direction = bone.tail_local - bone.head_local
                    if direction.length > 0.0001:
                        self._rest_directions[bone_name] = direction.normalized()
                    else:
                        self._rest_directions[bone_name] = Vector((0, 1, 0))

    def apply_hand(self, hand_landmarks, side, frame=None, smoothing=0.3):
        """
        Apply hand landmarks to finger bones.
        hand_landmarks: MediaPipe hand landmarks (21 points)
        side: 'L' or 'R'
        frame: if set, insert keyframes
        smoothing: temporal smoothing factor
        """
        if self.armature is None or hand_landmarks is None:
            return

        # Get landmark positions
        if hasattr(hand_landmarks, 'landmark'):
            lm_list = hand_landmarks.landmark
        else:
            lm_list = hand_landmarks

        positions = [
            mediapipe_to_blender_coords(lm.x, lm.y, lm.z)
            for lm in lm_list
        ]

        # Apply each finger chain
        for chain_name, chain_data in self.finger_chains.items():
            if not chain_name.endswith(f".{side}"):
                continue

            bone_names = chain_data["bones"]
            landmark_indices = chain_data["landmarks"]

            for i, bone_name in enumerate(bone_names):
                pose_bone = self.armature.pose.bones.get(bone_name)
                if pose_bone is None:
                    continue

                # Head and tail from landmark positions
                head_idx = landmark_indices[i]
                tail_idx = landmark_indices[i + 1] if i + 1 < len(landmark_indices) else None

                if tail_idx is None or head_idx >= len(positions) or tail_idx >= len(positions):
                    continue

                head_pos = positions[head_idx]
                tail_pos = positions[tail_idx]

                rest_dir = self._rest_directions.get(bone_name, Vector((0, 1, 0)))
                rotation = compute_bone_rotation(head_pos, tail_pos, rest_dir)

                # Smooth
                key = f"{bone_name}_{side}"
                prev = self._prev_rotations.get(key)
                if prev is not None and smoothing > 0:
                    rotation = smooth_quaternion(rotation, prev, smoothing)
                self._prev_rotations[key] = rotation.copy()

                pose_bone.rotation_mode = 'QUATERNION'
                pose_bone.rotation_quaternion = rotation

                if frame is not None:
                    pose_bone.keyframe_insert(
                        data_path="rotation_quaternion", frame=frame
                    )

    def apply_from_holistic(self, holistic_result, frame=None, smoothing=0.3):
        """Apply hand data from a HolisticResult."""
        if holistic_result.has_left_hand:
            self.apply_hand(
                holistic_result.left_hand_landmarks, "L",
                frame=frame, smoothing=smoothing
            )
        if holistic_result.has_right_hand:
            self.apply_hand(
                holistic_result.right_hand_landmarks, "R",
                frame=frame, smoothing=smoothing
            )

    def reset(self):
        """Reset all finger bones to rest pose."""
        if self.armature is None:
            return
        for chain_data in self.finger_chains.values():
            for bone_name in chain_data["bones"]:
                pose_bone = self.armature.pose.bones.get(bone_name)
                if pose_bone:
                    pose_bone.rotation_quaternion = Quaternion()
        self._prev_rotations.clear()
