"""
AI Mocap Studio - Retargeting: maps detected landmarks to armature bones.
"""

import bpy
from mathutils import Vector, Quaternion, Matrix

from ..core.constants import MP_LANDMARK
from ..utils.math_utils import (
    midpoint,
    compute_bone_rotation,
    mediapipe_to_blender_coords,
    smooth_quaternion,
)
from ..utils.bone_mapping import get_mapping_for_rig


class PoseRetargeter:
    """Maps MediaPipe pose landmarks onto a Blender armature."""

    def __init__(self, armature_obj, rig_type="SIMPLE", scale=1.0):
        self.armature = armature_obj
        self.rig_type = rig_type
        self.scale = scale
        self.bone_mapping = get_mapping_for_rig(rig_type)
        self._prev_rotations = {}
        self._rest_matrices = {}
        self._cache_rest_pose()

    def _cache_rest_pose(self):
        """Cache rest pose bone matrices and directions for rotation computation."""
        if self.armature is None or self.armature.type != 'ARMATURE':
            return
        for bone in self.armature.data.bones:
            direction = bone.tail_local - bone.head_local
            if direction.length > 0.0001:
                self._rest_matrices[bone.name] = {
                    "direction": direction.normalized(),
                    "matrix": bone.matrix_local.copy(),
                    "parent_matrix": bone.parent.matrix_local.copy() if bone.parent else Matrix.Identity(4),
                }
            else:
                self._rest_matrices[bone.name] = {
                    "direction": Vector((0, 1, 0)),
                    "matrix": Matrix.Identity(4),
                    "parent_matrix": Matrix.Identity(4),
                }

    def _compute_derived_positions(self, positions):
        """
        Compute derived landmark positions for bones that don't map
        directly to two MediaPipe landmarks (spine, neck, head, shoulders).
        Returns a dict of bone_description -> Vector.
        """
        left_hip = positions[MP_LANDMARK["LEFT_HIP"]]
        right_hip = positions[MP_LANDMARK["RIGHT_HIP"]]
        left_shoulder = positions[MP_LANDMARK["LEFT_SHOULDER"]]
        right_shoulder = positions[MP_LANDMARK["RIGHT_SHOULDER"]]
        nose = positions[MP_LANDMARK["NOSE"]]

        hip_center = midpoint(left_hip, right_hip)
        shoulder_center = midpoint(left_shoulder, right_shoulder)

        # Spine chain: interpolate between hips and shoulders
        spine_dir = shoulder_center - hip_center
        spine_01 = hip_center + spine_dir * 0.33
        spine_02 = hip_center + spine_dir * 0.66

        # Neck: from shoulder center toward nose
        neck_base = shoulder_center
        neck_top = shoulder_center + (nose - shoulder_center) * 0.5

        # Head: from neck_top to above nose
        head_top = nose + (nose - neck_top)

        return {
            "hip_center": hip_center,
            "shoulder_center": shoulder_center,
            "spine_01": spine_01,
            "spine_02": spine_02,
            "neck_base": neck_base,
            "neck_top": neck_top,
            "head_top": head_top,
        }

    def _resolve_bone_positions(self, bone_name, head_idx, tail_idx, positions, derived):
        """
        Resolve head and tail positions for a bone, using derived positions
        when landmark indices are None.
        Returns (head_pos, tail_pos) or None if cannot resolve.
        """
        # Direct landmark mapping
        head_pos = positions[head_idx] if head_idx is not None else None
        tail_pos = positions[tail_idx] if tail_idx is not None else None

        # Both available — use directly
        if head_pos is not None and tail_pos is not None:
            return head_pos, tail_pos

        # Resolve missing positions based on bone name patterns
        name_lower = bone_name.lower()

        # Spine intermediates (spine.001, spine_01, etc.)
        if any(k in name_lower for k in ["spine_01", "spine.001"]):
            return derived["hip_center"], derived["spine_01"]
        if any(k in name_lower for k in ["spine_02", "spine.002", "spine1"]):
            return derived["spine_01"], derived["spine_02"]
        if any(k in name_lower for k in ["spine_03", "spine.003", "spine2"]):
            return derived["spine_02"], derived["shoulder_center"]

        # Neck
        if "neck" in name_lower:
            return derived["neck_base"], derived["neck_top"]

        # Head
        if "head" in name_lower:
            return derived["neck_top"], derived["head_top"]

        # Shoulders — from shoulder center to shoulder landmark
        if "shoulder" in name_lower:
            if any(s in name_lower for s in [".l", "left"]):
                return derived["shoulder_center"], positions[MP_LANDMARK["LEFT_SHOULDER"]]
            if any(s in name_lower for s in [".r", "right"]):
                return derived["shoulder_center"], positions[MP_LANDMARK["RIGHT_SHOULDER"]]

        # Toes — from foot index forward (estimate)
        if "toe" in name_lower:
            if head_pos is not None:
                # Estimate: extend foot direction slightly
                toe_tip = head_pos + Vector((0, 0.02, -0.01))
                return head_pos, toe_tip

        # Spine with no other match — general case
        if "spine" in name_lower and head_pos is None and tail_pos is None:
            return derived["hip_center"], derived["shoulder_center"]

        # If only head is available, can't compute rotation
        if head_pos is not None and tail_pos is None:
            return None
        if head_pos is None and tail_pos is not None:
            return None

        return None

    def apply_pose(self, pose_result, frame=None, smoothing=0.3):
        """
        Apply detected pose to the armature.
        pose_result: PoseResult from detector.
        frame: If set, insert keyframes at this frame.
        smoothing: Smoothing factor for rotations (0 = none, 0.9 = heavy).
        """
        if self.armature is None or pose_result is None:
            return

        positions = pose_result.get_all_blender_positions(scale=self.scale)
        if not positions or len(positions) < 33:
            return

        # Ensure we're in pose mode context
        armature = self.armature
        if armature.pose is None:
            return

        # Compute derived positions for spine, neck, head, shoulders
        derived = self._compute_derived_positions(positions)

        # Apply root position (hips)
        self._apply_root_position(positions, derived, frame)

        # Apply bone rotations
        for bone_name, (head_idx, tail_idx) in self.bone_mapping.items():
            pose_bone = armature.pose.bones.get(bone_name)
            if pose_bone is None:
                continue

            result = self._resolve_bone_positions(
                bone_name, head_idx, tail_idx, positions, derived
            )
            if result is None:
                continue

            head_pos, tail_pos = result

            rotation = self._compute_local_rotation(bone_name, head_pos, tail_pos)

            # Apply smoothing
            prev = self._prev_rotations.get(bone_name)
            if prev is not None and smoothing > 0:
                rotation = smooth_quaternion(rotation, prev, smoothing)
            self._prev_rotations[bone_name] = rotation.copy()

            # Apply to pose bone
            pose_bone.rotation_mode = 'QUATERNION'
            pose_bone.rotation_quaternion = rotation

            if frame is not None:
                pose_bone.keyframe_insert(
                    data_path="rotation_quaternion", frame=frame
                )

    def _compute_local_rotation(self, bone_name, head_pos, tail_pos):
        """Compute rotation in bone-local space (suitable for pose_bone.rotation_quaternion)."""
        bone_dir = tail_pos - head_pos
        if bone_dir.length < 0.0001:
            return Quaternion()
        bone_dir.normalize()

        rest_info = self._rest_matrices.get(bone_name)
        if rest_info is None:
            return compute_bone_rotation(head_pos, tail_pos)

        rest_dir = rest_info["direction"]

        # Compute world-space rotation from rest to current direction
        world_rot = rest_dir.rotation_difference(bone_dir)

        # Convert to local space by removing parent's rest transform
        parent_mat = rest_info["parent_matrix"]
        bone_mat = rest_info["matrix"]

        # Local rest matrix = parent_inverse * bone_matrix
        local_rest_mat = parent_mat.inverted_safe() @ bone_mat
        local_rest_rot = local_rest_mat.to_quaternion()

        # Final local rotation: inverse(local_rest) * world_rot * local_rest
        local_rot = local_rest_rot.inverted() @ world_rot @ local_rest_rot
        return local_rot

    def _apply_root_position(self, positions, derived, frame=None):
        """Apply hip/root bone position from landmarks."""
        hip_center = derived["hip_center"]

        # Find root bone
        root_names = [
            "spine", "Hips", "mixamorig:Hips", "root", "Root",
            "c_root_master.x", "c_root.x",
        ]
        root_bone = None
        for name in root_names:
            root_bone = self.armature.pose.bones.get(name)
            if root_bone is not None:
                break

        if root_bone is None and len(self.armature.pose.bones) > 0:
            # Use first bone as root
            root_bone = self.armature.pose.bones[0]

        if root_bone is not None:
            root_bone.location = hip_center
            if frame is not None:
                root_bone.keyframe_insert(data_path="location", frame=frame)

    def apply_triangulated_pose(self, points_3d, scale=1.0, frame=None, smoothing=0.3):
        """
        Apply triangulated 3D points (from multi-camera) to the armature.
        points_3d: np.array (N, 3) — already in Blender coordinates.
        """
        if self.armature is None or points_3d is None:
            return

        n = len(points_3d)
        if n < 33:
            return

        positions = [
            Vector((p[0] * scale, p[1] * scale, p[2] * scale))
            for p in points_3d
        ]

        armature = self.armature
        if armature.pose is None:
            return

        derived = self._compute_derived_positions(positions)
        self._apply_root_position(positions, derived, frame)

        for bone_name, (head_idx, tail_idx) in self.bone_mapping.items():
            pose_bone = armature.pose.bones.get(bone_name)
            if pose_bone is None:
                continue

            result = self._resolve_bone_positions(
                bone_name, head_idx, tail_idx, positions, derived
            )
            if result is None:
                continue

            head_pos, tail_pos = result

            rotation = self._compute_local_rotation(bone_name, head_pos, tail_pos)

            prev = self._prev_rotations.get(bone_name)
            if prev is not None and smoothing > 0:
                rotation = smooth_quaternion(rotation, prev, smoothing)
            self._prev_rotations[bone_name] = rotation.copy()

            pose_bone.rotation_mode = 'QUATERNION'
            pose_bone.rotation_quaternion = rotation

            if frame is not None:
                pose_bone.keyframe_insert(
                    data_path="rotation_quaternion", frame=frame
                )

    def reset_pose(self):
        """Reset armature to rest pose."""
        if self.armature is None:
            return
        for pose_bone in self.armature.pose.bones:
            pose_bone.rotation_quaternion = Quaternion()
            pose_bone.location = Vector()
        self._prev_rotations.clear()

    def clear_keyframes(self):
        """Remove all keyframes from the armature."""
        if self.armature is None:
            return
        if self.armature.animation_data and self.armature.animation_data.action:
            bpy.data.actions.remove(self.armature.animation_data.action)
