"""
AI Mocap Studio - Face retargeting: maps blendshapes to mesh Shape Keys.
"""

import bpy
from mathutils import Euler

from ..core.constants import ARKIT_BLENDSHAPES
from ..utils.math_utils import smooth_value


class FaceRetargeter:
    """Maps ARKit blendshapes to Blender mesh Shape Keys and head bone rotation."""

    def __init__(self, mesh_obj=None, armature_obj=None):
        self.mesh = mesh_obj
        self.armature = armature_obj
        self._prev_values = {}
        self._prev_head_rotation = None
        self._shape_key_map = {}
        self._build_shape_key_map()

    def _build_shape_key_map(self):
        """
        Build mapping from ARKit blendshape names to mesh Shape Key names.
        Tries multiple naming conventions.
        """
        if self.mesh is None or self.mesh.data.shape_keys is None:
            return

        key_blocks = self.mesh.data.shape_keys.key_blocks

        for arkit_name in ARKIT_BLENDSHAPES:
            # Try exact match
            if arkit_name in key_blocks:
                self._shape_key_map[arkit_name] = arkit_name
                continue

            # Try with prefix "arkit_"
            prefixed = f"arkit_{arkit_name}"
            if prefixed in key_blocks:
                self._shape_key_map[arkit_name] = prefixed
                continue

            # Try lowercase
            lower = arkit_name.lower()
            for kb in key_blocks:
                if kb.name.lower() == lower:
                    self._shape_key_map[arkit_name] = kb.name
                    break

    def set_mesh(self, mesh_obj):
        """Set or change the target mesh."""
        self.mesh = mesh_obj
        self._shape_key_map.clear()
        self._build_shape_key_map()

    def set_armature(self, armature_obj):
        """Set or change the armature for head rotation."""
        self.armature = armature_obj

    def apply_blendshapes(self, blendshapes, frame=None, smoothing=0.3):
        """
        Apply blendshape values to mesh Shape Keys.
        blendshapes: dict of {name: value (0.0-1.0)}
        frame: if set, insert keyframes
        smoothing: temporal smoothing factor
        """
        if self.mesh is None or self.mesh.data.shape_keys is None:
            return

        key_blocks = self.mesh.data.shape_keys.key_blocks

        for arkit_name, value in blendshapes.items():
            sk_name = self._shape_key_map.get(arkit_name)
            if sk_name is None or sk_name not in key_blocks:
                continue

            # Smooth
            prev = self._prev_values.get(arkit_name, value)
            if smoothing > 0:
                value = smooth_value(value, prev, smoothing)
            self._prev_values[arkit_name] = value

            # Apply
            key_blocks[sk_name].value = value

            if frame is not None:
                key_blocks[sk_name].keyframe_insert(
                    data_path="value", frame=frame
                )

    def apply_head_rotation(self, pitch, yaw, roll, frame=None, smoothing=0.3):
        """
        Apply head rotation to the head bone.
        pitch, yaw, roll in radians.
        """
        if self.armature is None:
            return

        # Find head bone
        head_names = [
            "head", "Head", "spine.006", "spine.005",
            "mixamorig:Head", "DEF-spine.006",
        ]
        head_bone = None
        for name in head_names:
            head_bone = self.armature.pose.bones.get(name)
            if head_bone is not None:
                break

        if head_bone is None:
            return

        rotation = Euler((pitch, yaw, roll), 'XYZ')

        # Smooth
        if self._prev_head_rotation is not None and smoothing > 0:
            rotation.x = smooth_value(rotation.x, self._prev_head_rotation.x, smoothing)
            rotation.y = smooth_value(rotation.y, self._prev_head_rotation.y, smoothing)
            rotation.z = smooth_value(rotation.z, self._prev_head_rotation.z, smoothing)
        self._prev_head_rotation = rotation.copy()

        head_bone.rotation_mode = 'XYZ'
        head_bone.rotation_euler = rotation

        if frame is not None:
            head_bone.keyframe_insert(data_path="rotation_euler", frame=frame)

    def apply_from_holistic(self, holistic_result, frame=None, smoothing=0.3):
        """Apply face data from a HolisticResult."""
        if not holistic_result.has_face:
            return

        # Apply blendshapes
        blendshapes = holistic_result.get_face_blendshapes()
        if blendshapes:
            self.apply_blendshapes(blendshapes, frame=frame, smoothing=smoothing)

        # Apply head rotation
        pitch, yaw, roll = holistic_result.get_head_rotation()
        self.apply_head_rotation(pitch, yaw, roll, frame=frame, smoothing=smoothing)

    def create_shape_keys(self):
        """
        Create all 52 ARKit blendshape Shape Keys on the mesh.
        Useful for setting up a mesh that doesn't have them yet.
        """
        if self.mesh is None:
            return 0

        # Ensure basis shape key exists
        if self.mesh.data.shape_keys is None:
            self.mesh.shape_key_add(name="Basis")

        created = 0
        for name in ARKIT_BLENDSHAPES:
            if name not in self.mesh.data.shape_keys.key_blocks:
                self.mesh.shape_key_add(name=name)
                created += 1

        # Rebuild map
        self._build_shape_key_map()
        return created

    @property
    def mapped_count(self):
        """Number of successfully mapped blendshapes."""
        return len(self._shape_key_map)

    @property
    def total_blendshapes(self):
        """Total number of ARKit blendshapes."""
        return len(ARKIT_BLENDSHAPES)

    def get_mapping_report(self):
        """Return a report of which blendshapes are mapped and which are missing."""
        mapped = list(self._shape_key_map.keys())
        missing = [name for name in ARKIT_BLENDSHAPES if name not in self._shape_key_map]
        return {"mapped": mapped, "missing": missing}

    def reset(self):
        """Reset all blendshapes to 0 and head rotation to identity."""
        if self.mesh and self.mesh.data.shape_keys:
            for kb in self.mesh.data.shape_keys.key_blocks:
                if kb.name != "Basis":
                    kb.value = 0.0

        self._prev_values.clear()
        self._prev_head_rotation = None
