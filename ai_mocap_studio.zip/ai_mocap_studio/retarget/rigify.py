"""
AI Mocap Studio - Rigify-specific retargeting preset.
"""

from .mapper import PoseRetargeter


class RigifyRetargeter(PoseRetargeter):
    """Retargeter preconfigured for Rigify rigs."""

    def __init__(self, armature_obj, scale=1.0):
        super().__init__(armature_obj, rig_type="RIGIFY", scale=scale)

    def find_rigify_bones(self):
        """Detect if the armature is a Rigify rig and return available bones."""
        if self.armature is None:
            return []

        rigify_indicators = [
            "spine", "spine.001", "spine.002", "spine.003",
            "upper_arm.L", "upper_arm.R",
            "thigh.L", "thigh.R",
        ]

        found = []
        for name in rigify_indicators:
            if name in self.armature.data.bones:
                found.append(name)

        return found

    @property
    def is_rigify(self):
        """Check if the armature appears to be a Rigify rig."""
        return len(self.find_rigify_bones()) >= 4
