"""
AI Mocap Studio - Addon preferences panel.
"""

import bpy
from bpy.types import AddonPreferences
from bpy.props import (
    EnumProperty,
    FloatProperty,
    IntProperty,
    BoolProperty,
    StringProperty,
)

from .core.constants import ADDON_NAME


class AIMocapPreferences(AddonPreferences):
    bl_idname = ADDON_NAME

    # Detection model
    detection_model: EnumProperty(
        name="Detection Model",
        description="AI model used for pose detection",
        items=[
            ("MEDIAPIPE", "MediaPipe", "Google MediaPipe Pose — fast, CPU-friendly, 33 keypoints"),
            ("YOLO_POSE", "YOLO-Pose", "Ultralytics YOLO — fast multi-person, GPU, 17 keypoints"),
            ("MOTIONBERT", "MotionBERT", "2D→3D lifting — SOTA 3D accuracy, temporal consistency"),
        ],
        default="MEDIAPIPE",
    )

    # YOLO variant
    yolo_variant: EnumProperty(
        name="YOLO Variant",
        description="YOLO model size (larger = more accurate, slower)",
        items=[
            ("yolo11n-pose", "Nano (6 MB)", "Fastest, lower accuracy"),
            ("yolo11s-pose", "Small (23 MB)", "Balanced speed/accuracy"),
            ("yolo11m-pose", "Medium (51 MB)", "Higher accuracy"),
            ("yolo11l-pose", "Large (87 MB)", "Best accuracy"),
        ],
        default="yolo11s-pose",
    )

    # GPU acceleration
    use_gpu: BoolProperty(
        name="Use GPU Acceleration",
        description="Use GPU for model inference (CUDA/Metal/CoreML/DirectML)",
        default=True,
    )

    # Detection confidence
    min_detection_confidence: FloatProperty(
        name="Min Detection Confidence",
        description="Minimum confidence for initial pose detection",
        default=0.5,
        min=0.0,
        max=1.0,
        step=5,
    )

    min_tracking_confidence: FloatProperty(
        name="Min Tracking Confidence",
        description="Minimum confidence for pose tracking between frames",
        default=0.5,
        min=0.0,
        max=1.0,
        step=5,
    )

    # Capture settings
    capture_fps: IntProperty(
        name="Capture FPS",
        description="Frames per second for capture",
        default=30,
        min=1,
        max=120,
    )

    camera_index: IntProperty(
        name="Camera Index",
        description="Webcam device index (0 = default camera)",
        default=0,
        min=0,
        max=10,
    )

    capture_width: IntProperty(
        name="Capture Width",
        description="Camera capture width in pixels",
        default=1280,
        min=320,
        max=3840,
    )

    capture_height: IntProperty(
        name="Capture Height",
        description="Camera capture height in pixels",
        default=720,
        min=240,
        max=2160,
    )

    # Smoothing
    use_smoothing: BoolProperty(
        name="Enable Smoothing",
        description="Apply smoothing filter to captured motion",
        default=True,
    )

    smoothing_factor: FloatProperty(
        name="Smoothing Factor",
        description="Amount of smoothing applied (higher = smoother but more lag)",
        default=0.3,
        min=0.0,
        max=0.9,
        step=5,
    )

    # Display
    show_landmarks: BoolProperty(
        name="Show Landmarks in Viewport",
        description="Draw detected landmarks in the 3D viewport",
        default=True,
    )

    landmark_scale: FloatProperty(
        name="Landmark Scale",
        description="Size of landmark points in viewport",
        default=1.0,
        min=0.1,
        max=5.0,
        step=10,
    )

    show_fps_counter: BoolProperty(
        name="Show FPS Counter",
        description="Display inference FPS in the viewport",
        default=False,
    )

    def draw(self, context):
        layout = self.layout

        # Dependencies section
        box = layout.box()
        box.label(text="Dependencies", icon='MODIFIER')
        row = box.row(align=True)
        row.operator("aimocap.install_dependencies", text="Install Core", icon='IMPORT')
        row.operator("aimocap.install_model_deps", text="Install Model Deps", icon='IMPORT')

        # GPU info
        box = layout.box()
        box.label(text="GPU & Performance", icon='PREFERENCES')
        box.prop(self, "use_gpu")
        box.operator("aimocap.detect_gpu", text="Detect GPU", icon='VIEWZOOM')

        # Model settings
        box = layout.box()
        box.label(text="Detection Model", icon='MOD_ARMATURE')
        box.prop(self, "detection_model")

        if self.detection_model == "YOLO_POSE":
            box.prop(self, "yolo_variant")
            box.label(text="Multi-person support", icon='INFO')

        elif self.detection_model == "MOTIONBERT":
            box.label(text="Requires 2D detector + ONNX model", icon='INFO')
            box.label(text="SOTA 3D accuracy with temporal consistency")

        box.prop(self, "min_detection_confidence")
        box.prop(self, "min_tracking_confidence")

        # Model management
        box = layout.box()
        box.label(text="Model Management", icon='FILE_FOLDER')
        row = box.row(align=True)
        row.operator("aimocap.load_model", icon='IMPORT')
        row.operator("aimocap.unload_model", icon='X')
        box.operator("aimocap.model_info", icon='INFO')

        # Capture settings
        box = layout.box()
        box.label(text="Capture Settings", icon='CAMERA_DATA')
        box.prop(self, "camera_index")
        row = box.row()
        row.prop(self, "capture_width")
        row.prop(self, "capture_height")
        box.prop(self, "capture_fps")

        # Smoothing
        box = layout.box()
        box.label(text="Smoothing", icon='SMOOTHCURVE')
        box.prop(self, "use_smoothing")
        if self.use_smoothing:
            box.prop(self, "smoothing_factor")

        # Display
        box = layout.box()
        box.label(text="Viewport Display", icon='HIDE_OFF')
        box.prop(self, "show_landmarks")
        if self.show_landmarks:
            box.prop(self, "landmark_scale")
        box.prop(self, "show_fps_counter")
