"""
AI Mocap Studio - Camera calibration using checkerboard pattern.

Handles:
- Intrinsic calibration (single camera lens parameters)
- Stereo calibration (relative pose between camera pairs)
- Extrinsic calibration (camera position in world space)
- Calibration data save/load
"""

import json
import os
import numpy as np

try:
    import cv2
except ImportError:
    cv2 = None


# ============================================================
# Calibration data structures
# ============================================================

class CameraIntrinsics:
    """Single camera intrinsic parameters."""

    def __init__(self):
        self.camera_matrix = None      # 3x3 intrinsic matrix
        self.dist_coeffs = None        # distortion coefficients
        self.image_size = (0, 0)       # (width, height)
        self.reprojection_error = 0.0
        self.calibrated = False

    def to_dict(self):
        if not self.calibrated:
            return {"calibrated": False}
        return {
            "calibrated": True,
            "camera_matrix": self.camera_matrix.tolist(),
            "dist_coeffs": self.dist_coeffs.tolist(),
            "image_size": list(self.image_size),
            "reprojection_error": self.reprojection_error,
        }

    @classmethod
    def from_dict(cls, d):
        obj = cls()
        if not d.get("calibrated", False):
            return obj
        obj.camera_matrix = np.array(d["camera_matrix"], dtype=np.float64)
        obj.dist_coeffs = np.array(d["dist_coeffs"], dtype=np.float64)
        obj.image_size = tuple(d["image_size"])
        obj.reprojection_error = d.get("reprojection_error", 0.0)
        obj.calibrated = True
        return obj


class StereoPair:
    """Stereo calibration between two cameras."""

    def __init__(self, cam_a_index=0, cam_b_index=1):
        self.cam_a_index = cam_a_index
        self.cam_b_index = cam_b_index
        self.rotation = None       # 3x3 rotation matrix
        self.translation = None    # 3x1 translation vector
        self.essential = None      # 3x3 essential matrix
        self.fundamental = None    # 3x3 fundamental matrix
        self.reprojection_error = 0.0
        self.calibrated = False

    def to_dict(self):
        if not self.calibrated:
            return {
                "calibrated": False,
                "cam_a": self.cam_a_index,
                "cam_b": self.cam_b_index,
            }
        return {
            "calibrated": True,
            "cam_a": self.cam_a_index,
            "cam_b": self.cam_b_index,
            "rotation": self.rotation.tolist(),
            "translation": self.translation.tolist(),
            "essential": self.essential.tolist(),
            "fundamental": self.fundamental.tolist(),
            "reprojection_error": self.reprojection_error,
        }

    @classmethod
    def from_dict(cls, d):
        obj = cls(d.get("cam_a", 0), d.get("cam_b", 1))
        if not d.get("calibrated", False):
            return obj
        obj.rotation = np.array(d["rotation"], dtype=np.float64)
        obj.translation = np.array(d["translation"], dtype=np.float64)
        obj.essential = np.array(d["essential"], dtype=np.float64)
        obj.fundamental = np.array(d["fundamental"], dtype=np.float64)
        obj.reprojection_error = d.get("reprojection_error", 0.0)
        obj.calibrated = True
        return obj


# ============================================================
# Calibration session
# ============================================================

class CalibrationSession:
    """
    Manages the full calibration workflow:
    1. Collect checkerboard frames from each camera
    2. Compute intrinsics per camera
    3. Compute stereo pairs for triangulation
    """

    def __init__(self, board_size=(9, 6), square_size=0.025):
        """
        board_size: (cols, rows) inner corners of checkerboard
        square_size: physical size of one square in meters
        """
        self.board_size = board_size
        self.square_size = square_size

        # Per-camera collected data: {cam_index: list of (corners, frame_shape)}
        self._collected = {}
        # Calibration results
        self.intrinsics = {}      # {cam_index: CameraIntrinsics}
        self.stereo_pairs = {}    # {(cam_a, cam_b): StereoPair}

        # Object points template (same for all views)
        self._obj_points_template = self._make_object_points()

    def _make_object_points(self):
        """Create 3D object points for the checkerboard."""
        objp = np.zeros((self.board_size[0] * self.board_size[1], 3), np.float32)
        objp[:, :2] = np.mgrid[
            0:self.board_size[0], 0:self.board_size[1]
        ].T.reshape(-1, 2)
        objp *= self.square_size
        return objp

    # ------ Frame collection ------

    def find_checkerboard(self, frame, cam_index):
        """
        Try to find checkerboard corners in a frame.

        frame: BGR image (numpy array)
        cam_index: camera identifier

        Returns: (found, corners, annotated_frame)
        """
        if cv2 is None:
            return False, None, frame

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        flags = (
            cv2.CALIB_CB_ADAPTIVE_THRESH
            | cv2.CALIB_CB_NORMALIZE_IMAGE
            | cv2.CALIB_CB_FAST_CHECK
        )
        found, corners = cv2.findChessboardCorners(gray, self.board_size, flags)

        annotated = frame.copy()
        if found:
            # Refine corners to sub-pixel accuracy
            criteria = (
                cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER,
                30, 0.001,
            )
            corners = cv2.cornerSubPix(gray, corners, (11, 11), (-1, -1), criteria)
            cv2.drawChessboardCorners(annotated, self.board_size, corners, found)

        return found, corners, annotated

    def add_frame(self, corners, cam_index, frame_shape):
        """
        Store detected corners for a camera.

        corners: np.array from find_checkerboard
        cam_index: camera identifier
        frame_shape: (height, width) of the frame
        """
        if cam_index not in self._collected:
            self._collected[cam_index] = []
        self._collected[cam_index].append((corners, frame_shape))

    def get_frame_count(self, cam_index):
        """Number of collected frames for a camera."""
        return len(self._collected.get(cam_index, []))

    # ------ Intrinsic calibration ------

    def calibrate_intrinsics(self, cam_index, min_frames=8):
        """
        Compute intrinsic parameters for a single camera.

        cam_index: camera identifier
        min_frames: minimum number of collected frames

        Returns: CameraIntrinsics (also stored in self.intrinsics)
        """
        if cv2 is None:
            raise RuntimeError("OpenCV is required for calibration")

        frames = self._collected.get(cam_index, [])
        if len(frames) < min_frames:
            raise ValueError(
                f"Need at least {min_frames} frames, got {len(frames)}"
            )

        obj_points = []
        img_points = []
        image_size = None

        for corners, shape in frames:
            obj_points.append(self._obj_points_template)
            img_points.append(corners)
            image_size = (shape[1], shape[0])  # (width, height)

        ret, mtx, dist, rvecs, tvecs = cv2.calibrateCamera(
            obj_points, img_points, image_size, None, None
        )

        intr = CameraIntrinsics()
        intr.camera_matrix = mtx
        intr.dist_coeffs = dist
        intr.image_size = image_size
        intr.reprojection_error = ret
        intr.calibrated = True

        self.intrinsics[cam_index] = intr
        return intr

    # ------ Stereo calibration ------

    def calibrate_stereo(self, cam_a, cam_b):
        """
        Compute stereo calibration between two cameras.
        Both cameras must have intrinsic calibration and matching frame counts.

        Returns: StereoPair (also stored in self.stereo_pairs)
        """
        if cv2 is None:
            raise RuntimeError("OpenCV is required for calibration")

        intr_a = self.intrinsics.get(cam_a)
        intr_b = self.intrinsics.get(cam_b)

        if not intr_a or not intr_a.calibrated:
            raise ValueError(f"Camera {cam_a} not calibrated")
        if not intr_b or not intr_b.calibrated:
            raise ValueError(f"Camera {cam_b} not calibrated")

        frames_a = self._collected.get(cam_a, [])
        frames_b = self._collected.get(cam_b, [])

        # Use the minimum number of matching frames
        n_frames = min(len(frames_a), len(frames_b))
        if n_frames < 8:
            raise ValueError(f"Need at least 8 matching frames, got {n_frames}")

        obj_points = []
        img_a = []
        img_b = []

        for i in range(n_frames):
            obj_points.append(self._obj_points_template)
            img_a.append(frames_a[i][0])
            img_b.append(frames_b[i][0])

        criteria = (
            cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER,
            100, 1e-5,
        )
        flags = cv2.CALIB_FIX_INTRINSIC

        ret, _, _, _, _, R, T, E, F = cv2.stereoCalibrate(
            obj_points, img_a, img_b,
            intr_a.camera_matrix, intr_a.dist_coeffs,
            intr_b.camera_matrix, intr_b.dist_coeffs,
            intr_a.image_size,
            criteria=criteria,
            flags=flags,
        )

        pair = StereoPair(cam_a, cam_b)
        pair.rotation = R
        pair.translation = T
        pair.essential = E
        pair.fundamental = F
        pair.reprojection_error = ret
        pair.calibrated = True

        self.stereo_pairs[(cam_a, cam_b)] = pair
        return pair

    # ------ Projection matrices ------

    def get_projection_matrices(self, cam_a, cam_b):
        """
        Get 3x4 projection matrices for a calibrated stereo pair.

        Returns: (P1, P2) — projection matrices for cam_a and cam_b
        """
        intr_a = self.intrinsics.get(cam_a)
        intr_b = self.intrinsics.get(cam_b)
        pair = self.stereo_pairs.get((cam_a, cam_b))

        if not all([intr_a, intr_b, pair]):
            raise ValueError("Cameras not fully calibrated")

        # Camera A at origin
        P1 = intr_a.camera_matrix @ np.hstack([np.eye(3), np.zeros((3, 1))])
        # Camera B relative to A
        P2 = intr_b.camera_matrix @ np.hstack([pair.rotation, pair.translation])

        return P1, P2

    # ------ Save / Load ------

    def save(self, filepath):
        """Save calibration data to JSON."""
        data = {
            "board_size": list(self.board_size),
            "square_size": self.square_size,
            "intrinsics": {
                str(k): v.to_dict() for k, v in self.intrinsics.items()
            },
            "stereo_pairs": {
                f"{k[0]}_{k[1]}": v.to_dict()
                for k, v in self.stereo_pairs.items()
            },
        }
        os.makedirs(os.path.dirname(filepath) or ".", exist_ok=True)
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=2)

    @classmethod
    def load(cls, filepath):
        """Load calibration data from JSON."""
        with open(filepath, 'r') as f:
            data = json.load(f)

        session = cls(
            board_size=tuple(data["board_size"]),
            square_size=data["square_size"],
        )

        for k, v in data.get("intrinsics", {}).items():
            session.intrinsics[int(k)] = CameraIntrinsics.from_dict(v)

        for k, v in data.get("stereo_pairs", {}).items():
            parts = k.split("_")
            key = (int(parts[0]), int(parts[1]))
            session.stereo_pairs[key] = StereoPair.from_dict(v)

        return session


# ============================================================
# Undistortion utility
# ============================================================

def undistort_frame(frame, intrinsics):
    """Remove lens distortion from a frame using calibration data."""
    if cv2 is None or not intrinsics.calibrated:
        return frame

    h, w = frame.shape[:2]
    new_mtx, roi = cv2.getOptimalNewCameraMatrix(
        intrinsics.camera_matrix, intrinsics.dist_coeffs,
        (w, h), 1, (w, h),
    )
    undistorted = cv2.undistort(
        frame, intrinsics.camera_matrix, intrinsics.dist_coeffs,
        None, new_mtx,
    )
    x, y, w2, h2 = roi
    if w2 > 0 and h2 > 0:
        undistorted = undistorted[y:y+h2, x:x+w2]
    return undistorted


def undistort_points(points_2d, intrinsics):
    """
    Undistort 2D points using camera intrinsics.

    points_2d: np.array (N, 2) — pixel coordinates
    Returns: np.array (N, 2) — undistorted coordinates
    """
    if cv2 is None or not intrinsics.calibrated:
        return points_2d

    pts = points_2d.reshape(-1, 1, 2).astype(np.float64)
    undistorted = cv2.undistortPoints(
        pts,
        intrinsics.camera_matrix,
        intrinsics.dist_coeffs,
        P=intrinsics.camera_matrix,
    )
    return undistorted.reshape(-1, 2)
