"""
AI Mocap Studio - Multi-camera stream synchronization.

Handles:
- Opening and managing multiple camera streams
- Frame synchronization across cameras (timestamp-based)
- Synchronized frame reading
- Automatic frame dropping for slow cameras
"""

import time
import threading
import numpy as np

try:
    import cv2
except ImportError:
    cv2 = None


class CameraStream:
    """
    Threaded camera stream reader.
    Continuously reads frames in a background thread so the main
    thread always gets the latest available frame with minimal latency.
    """

    def __init__(self, camera_index, width=1280, height=720):
        self.camera_index = camera_index
        self.width = width
        self.height = height

        self._cap = None
        self._frame = None
        self._timestamp = 0.0
        self._frame_id = 0
        self._lock = threading.Lock()
        self._running = False
        self._thread = None

    def open(self):
        """Open the camera stream and start reading thread."""
        if cv2 is None:
            raise RuntimeError("OpenCV is required")

        self._cap = cv2.VideoCapture(self.camera_index)
        if not self._cap.isOpened():
            raise RuntimeError(f"Cannot open camera {self.camera_index}")

        self._cap.set(cv2.CAP_PROP_FRAME_WIDTH, self.width)
        self._cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self.height)

        self._running = True
        self._thread = threading.Thread(target=self._read_loop, daemon=True)
        self._thread.start()

    def _read_loop(self):
        """Background thread: continuously read frames."""
        while self._running:
            if self._cap is None:
                break
            ret, frame = self._cap.read()
            if ret:
                with self._lock:
                    self._frame = frame
                    self._timestamp = time.monotonic()
                    self._frame_id += 1
            else:
                time.sleep(0.001)

    def get_frame(self):
        """
        Get the latest frame and its timestamp.
        Returns: (frame, timestamp, frame_id) or (None, 0, 0) if no frame
        """
        with self._lock:
            if self._frame is None:
                return None, 0.0, 0
            return self._frame.copy(), self._timestamp, self._frame_id

    def release(self):
        """Stop reading and release the camera."""
        self._running = False
        if self._thread:
            self._thread.join(timeout=2.0)
        if self._cap:
            self._cap.release()
            self._cap = None
        self._frame = None

    @property
    def is_open(self):
        return self._running and self._cap is not None


class MultiCameraSync:
    """
    Synchronize frame capture across multiple cameras.

    Uses timestamp-based synchronization: reads the latest frame from
    each camera and groups them if timestamps are within the sync
    tolerance window.
    """

    def __init__(self, camera_indices, width=1280, height=720, sync_tolerance=0.033):
        """
        camera_indices: list of int — camera device indices
        width, height: resolution for all cameras
        sync_tolerance: maximum timestamp difference (seconds) for frames
                        to be considered synchronized (default ~1 frame at 30fps)
        """
        self.camera_indices = list(camera_indices)
        self.sync_tolerance = sync_tolerance
        self.streams = {}
        self._width = width
        self._height = height
        self._running = False

        # Stats
        self.sync_hits = 0
        self.sync_misses = 0
        self.total_reads = 0

    def open_all(self):
        """Open all camera streams."""
        errors = []
        for idx in self.camera_indices:
            stream = CameraStream(idx, self._width, self._height)
            try:
                stream.open()
                self.streams[idx] = stream
            except RuntimeError as e:
                errors.append((idx, str(e)))

        if errors:
            # Close any that opened successfully
            if len(self.streams) == 0:
                raise RuntimeError(
                    f"Failed to open any cameras: {errors}"
                )
            # Partial success — report which failed
            print(f"Warning: some cameras failed to open: {errors}")

        self._running = True
        # Wait briefly for first frames
        time.sleep(0.2)

    def read_synchronized(self):
        """
        Read one synchronized frame set from all cameras.

        Returns: dict {cam_index: frame} or None if sync failed.
        All frames in the dict are within sync_tolerance of each other.
        """
        if not self._running:
            return None

        self.total_reads += 1
        frames = {}
        timestamps = {}

        for idx, stream in self.streams.items():
            frame, ts, fid = stream.get_frame()
            if frame is not None:
                frames[idx] = frame
                timestamps[idx] = ts

        if len(frames) < 2:
            self.sync_misses += 1
            return frames if frames else None

        # Check synchronization
        ts_values = list(timestamps.values())
        ts_spread = max(ts_values) - min(ts_values)

        if ts_spread <= self.sync_tolerance:
            self.sync_hits += 1
            return frames
        else:
            # Frames are not well synchronized — return them anyway
            # but mark as desync (caller can check sync_rate)
            self.sync_misses += 1
            return frames

    @property
    def sync_rate(self):
        """Percentage of reads that were well-synchronized."""
        if self.total_reads == 0:
            return 0.0
        return self.sync_hits / self.total_reads

    @property
    def camera_count(self):
        return len(self.streams)

    def release_all(self):
        """Release all camera streams."""
        self._running = False
        for stream in self.streams.values():
            stream.release()
        self.streams.clear()


class VideoMultiSync:
    """
    Synchronize multiple video files by frame number.
    Assumes videos were recorded simultaneously at the same FPS.
    """

    def __init__(self, video_paths):
        """
        video_paths: dict {cam_index: filepath}
        """
        self.video_paths = video_paths
        self._caps = {}
        self._frame_counts = {}
        self._fps_values = {}
        self._current_frame = 0

    def open_all(self):
        """Open all video files."""
        if cv2 is None:
            raise RuntimeError("OpenCV is required")

        for idx, path in self.video_paths.items():
            cap = cv2.VideoCapture(path)
            if not cap.isOpened():
                raise RuntimeError(f"Cannot open video: {path}")
            self._caps[idx] = cap
            self._frame_counts[idx] = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
            self._fps_values[idx] = cap.get(cv2.CAP_PROP_FPS)

        self._current_frame = 0

    def read_frame(self):
        """
        Read next frame from all videos.

        Returns: dict {cam_index: frame} or None if all videos ended
        """
        frames = {}
        for idx, cap in self._caps.items():
            ret, frame = cap.read()
            if ret:
                frames[idx] = frame

        if not frames:
            return None

        self._current_frame += 1
        return frames

    def seek(self, frame_number):
        """Seek all videos to a specific frame."""
        for cap in self._caps.values():
            cap.set(cv2.CAP_PROP_POS_FRAMES, frame_number)
        self._current_frame = frame_number

    @property
    def total_frames(self):
        """Minimum frame count across all videos."""
        if not self._frame_counts:
            return 0
        return min(self._frame_counts.values())

    @property
    def fps(self):
        """FPS of the first video (assumed same for all)."""
        if not self._fps_values:
            return 30.0
        return next(iter(self._fps_values.values()))

    @property
    def current_frame(self):
        return self._current_frame

    @property
    def progress(self):
        total = self.total_frames
        if total == 0:
            return 0.0
        return self._current_frame / total

    def release_all(self):
        """Release all video captures."""
        for cap in self._caps.values():
            cap.release()
        self._caps.clear()
