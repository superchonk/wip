"""
AI Mocap Studio - Multi-camera capture module.

Provides camera calibration, stream synchronization,
and triangulation for accurate 3D pose reconstruction.
"""
