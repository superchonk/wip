"""
AI Mocap Studio - 3D triangulation from multiple camera views.

Handles:
- DLT (Direct Linear Transform) triangulation from 2+ views
- Multi-view triangulation with outlier rejection
- Confidence-weighted triangulation
- Occlusion resolution (use best visible views)
"""

import numpy as np

try:
    import cv2
except ImportError:
    cv2 = None


# ============================================================
# Core triangulation
# ============================================================

def triangulate_point_dlt(P1, P2, pt1, pt2):
    """
    Triangulate a single 3D point from two 2D observations
    using the Direct Linear Transform (DLT) method.

    P1, P2: 3x4 projection matrices
    pt1, pt2: 2D points (x, y) in pixel coordinates

    Returns: np.array (3,) — 3D point in world coordinates
    """
    A = np.array([
        pt1[0] * P1[2] - P1[0],
        pt1[1] * P1[2] - P1[1],
        pt2[0] * P2[2] - P2[0],
        pt2[1] * P2[2] - P2[1],
    ])

    _, _, Vt = np.linalg.svd(A)
    X = Vt[-1]
    return X[:3] / X[3]


def triangulate_point_opencv(P1, P2, pt1, pt2):
    """
    Triangulate using OpenCV's triangulatePoints (more numerically stable).

    P1, P2: 3x4 projection matrices
    pt1, pt2: 2D points (x, y)

    Returns: np.array (3,) — 3D point
    """
    if cv2 is None:
        return triangulate_point_dlt(P1, P2, pt1, pt2)

    pts1 = np.array(pt1, dtype=np.float64).reshape(2, 1)
    pts2 = np.array(pt2, dtype=np.float64).reshape(2, 1)

    X = cv2.triangulatePoints(P1, P2, pts1, pts2)
    X = X.flatten()
    return X[:3] / X[3]


# ============================================================
# Multi-point triangulation
# ============================================================

def triangulate_landmarks(projection_matrices, landmarks_per_view, confidences_per_view=None):
    """
    Triangulate multiple landmarks from multiple camera views.

    projection_matrices: dict {cam_index: np.array (3, 4)}
    landmarks_per_view: dict {cam_index: np.array (N, 2)} — 2D landmarks per camera
    confidences_per_view: dict {cam_index: np.array (N,)} — optional confidence per landmark

    Returns: np.array (N, 3) — triangulated 3D points
    """
    cam_indices = sorted(projection_matrices.keys())
    if len(cam_indices) < 2:
        raise ValueError("Need at least 2 camera views for triangulation")

    # Determine number of landmarks from first view
    first_cam = cam_indices[0]
    n_landmarks = len(landmarks_per_view[first_cam])

    points_3d = np.zeros((n_landmarks, 3))

    for lm_idx in range(n_landmarks):
        points_3d[lm_idx] = _triangulate_single_landmark(
            lm_idx, cam_indices, projection_matrices,
            landmarks_per_view, confidences_per_view,
        )

    return points_3d


def _triangulate_single_landmark(
    lm_idx, cam_indices, projection_matrices,
    landmarks_per_view, confidences_per_view,
):
    """Triangulate a single landmark from all available views."""
    # Collect valid observations
    valid_cams = []
    for cam_idx in cam_indices:
        lm = landmarks_per_view.get(cam_idx)
        if lm is None or lm_idx >= len(lm):
            continue

        pt = lm[lm_idx]
        # Skip points at (0, 0) — typically means not detected
        if pt[0] == 0 and pt[1] == 0:
            continue

        # Check confidence if available
        if confidences_per_view:
            conf = confidences_per_view.get(cam_idx)
            if conf is not None and lm_idx < len(conf) and conf[lm_idx] < 0.3:
                continue

        valid_cams.append(cam_idx)

    if len(valid_cams) < 2:
        # Cannot triangulate — return zero
        return np.zeros(3)

    # Use best two views (highest confidence) or all views
    if len(valid_cams) == 2:
        cam_a, cam_b = valid_cams
        P1 = projection_matrices[cam_a]
        P2 = projection_matrices[cam_b]
        pt1 = landmarks_per_view[cam_a][lm_idx]
        pt2 = landmarks_per_view[cam_b][lm_idx]
        return triangulate_point_opencv(P1, P2, pt1, pt2)

    # Multi-view: build DLT system from all views
    return _triangulate_multiview(
        valid_cams, lm_idx, projection_matrices,
        landmarks_per_view, confidences_per_view,
    )


def _triangulate_multiview(
    cam_indices, lm_idx, projection_matrices,
    landmarks_per_view, confidences_per_view,
):
    """
    Triangulate from 3+ views using weighted DLT.
    Each view contributes two equations to the system.
    """
    rows = []
    for cam_idx in cam_indices:
        P = projection_matrices[cam_idx]
        pt = landmarks_per_view[cam_idx][lm_idx]

        # Weight by confidence
        w = 1.0
        if confidences_per_view:
            conf = confidences_per_view.get(cam_idx)
            if conf is not None and lm_idx < len(conf):
                w = float(conf[lm_idx])

        rows.append(w * (pt[0] * P[2] - P[0]))
        rows.append(w * (pt[1] * P[2] - P[1]))

    A = np.array(rows)
    _, _, Vt = np.linalg.svd(A)
    X = Vt[-1]
    return X[:3] / X[3]


# ============================================================
# Reprojection error
# ============================================================

def compute_reprojection_error(point_3d, projection_matrix, point_2d):
    """
    Compute reprojection error for a triangulated point.

    point_3d: np.array (3,)
    projection_matrix: np.array (3, 4)
    point_2d: np.array (2,) — observed 2D point

    Returns: float — Euclidean distance in pixels
    """
    X = np.append(point_3d, 1.0)
    projected = projection_matrix @ X
    projected = projected[:2] / projected[2]
    return np.linalg.norm(projected - point_2d)


def compute_mean_reprojection_error(
    points_3d, projection_matrices, landmarks_per_view,
):
    """
    Compute mean reprojection error across all points and views.

    Returns: float — mean error in pixels
    """
    total_error = 0.0
    count = 0

    for cam_idx, P in projection_matrices.items():
        lm = landmarks_per_view.get(cam_idx)
        if lm is None:
            continue

        n = min(len(points_3d), len(lm))
        for i in range(n):
            pt = lm[i]
            if pt[0] == 0 and pt[1] == 0:
                continue
            err = compute_reprojection_error(points_3d[i], P, pt)
            total_error += err
            count += 1

    return total_error / max(count, 1)


# ============================================================
# Occlusion resolution
# ============================================================

def resolve_occlusions(
    projection_matrices, landmarks_per_view, confidences_per_view,
    reprojection_threshold=10.0,
):
    """
    Triangulate landmarks and reject views with high reprojection error
    (likely occluded or misdetected). Re-triangulates without those views.

    projection_matrices: dict {cam_index: np.array (3, 4)}
    landmarks_per_view: dict {cam_index: np.array (N, 2)}
    confidences_per_view: dict {cam_index: np.array (N,)}
    reprojection_threshold: max acceptable reprojection error in pixels

    Returns: (points_3d, per_point_errors)
    """
    cam_indices = sorted(projection_matrices.keys())
    first_cam = cam_indices[0]
    n_landmarks = len(landmarks_per_view[first_cam])

    points_3d = np.zeros((n_landmarks, 3))
    errors = np.zeros(n_landmarks)

    for lm_idx in range(n_landmarks):
        # Initial triangulation with all views
        point = _triangulate_single_landmark(
            lm_idx, cam_indices, projection_matrices,
            landmarks_per_view, confidences_per_view,
        )

        # Check reprojection error per view
        good_cams = []
        for cam_idx in cam_indices:
            lm = landmarks_per_view.get(cam_idx)
            if lm is None or lm_idx >= len(lm):
                continue
            pt = lm[lm_idx]
            if pt[0] == 0 and pt[1] == 0:
                continue

            err = compute_reprojection_error(
                point, projection_matrices[cam_idx], pt,
            )
            if err < reprojection_threshold:
                good_cams.append(cam_idx)

        # Re-triangulate with only good views if we lost some
        if len(good_cams) >= 2 and len(good_cams) < len(cam_indices):
            point = _triangulate_single_landmark(
                lm_idx, good_cams, projection_matrices,
                landmarks_per_view, confidences_per_view,
            )

        points_3d[lm_idx] = point

        # Compute final mean error
        err_sum = 0.0
        err_count = 0
        for cam_idx in cam_indices:
            lm = landmarks_per_view.get(cam_idx)
            if lm is None or lm_idx >= len(lm):
                continue
            pt = lm[lm_idx]
            if pt[0] == 0 and pt[1] == 0:
                continue
            err_sum += compute_reprojection_error(
                point, projection_matrices[cam_idx], pt,
            )
            err_count += 1
        errors[lm_idx] = err_sum / max(err_count, 1)

    return points_3d, errors


# ============================================================
# Coordinate conversion
# ============================================================

def triangulated_to_blender(points_3d):
    """
    Convert triangulated 3D points from OpenCV coordinate system
    to Blender coordinate system.

    OpenCV: X right, Y down, Z forward
    Blender: X right, Y forward, Z up

    points_3d: np.array (N, 3)
    Returns: np.array (N, 3)
    """
    result = np.empty_like(points_3d)
    result[:, 0] = points_3d[:, 0]     # X stays
    result[:, 1] = points_3d[:, 2]     # Z -> Y (forward)
    result[:, 2] = -points_3d[:, 1]    # -Y -> Z (up)
    return result
