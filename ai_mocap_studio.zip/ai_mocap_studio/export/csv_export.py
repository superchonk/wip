"""
AI Mocap Studio - CSV export.
Exports per-frame bone rotations and positions to CSV.
Two modes: WIDE (one row = one frame) and LONG (one row = one bone per frame).
"""

import csv
import bpy
from pathlib import Path
from mathutils import Vector


def export_csv(armature_obj, filepath, frame_start=None, frame_end=None,
               mode='WIDE', include_position=True, include_rotation=True):
    """
    Export armature animation data to CSV.

    Args:
        armature_obj: Blender armature object.
        filepath: Output file path.
        frame_start: First frame.
        frame_end: Last frame.
        mode: 'WIDE' or 'LONG'.
        include_position: Include world-space bone head positions.
        include_rotation: Include quaternion rotations.

    Returns:
        (success: bool, message: str)
    """
    if armature_obj is None or armature_obj.type != 'ARMATURE':
        return False, "No valid armature selected"

    filepath = str(filepath)
    if not filepath.lower().endswith('.csv'):
        filepath += '.csv'

    Path(filepath).parent.mkdir(parents=True, exist_ok=True)

    scene = bpy.context.scene
    if frame_start is None:
        frame_start = scene.frame_start
    if frame_end is None:
        frame_end = scene.frame_end

    bone_names = [b.name for b in armature_obj.pose.bones]

    try:
        with open(filepath, 'w', newline='') as f:
            writer = csv.writer(f)

            if mode == 'WIDE':
                _write_wide(writer, armature_obj, bone_names,
                            frame_start, frame_end,
                            include_position, include_rotation)
            else:
                _write_long(writer, armature_obj, bone_names,
                            frame_start, frame_end,
                            include_position, include_rotation)

        return True, filepath
    except Exception as e:
        return False, str(e)


def _write_wide(writer, armature_obj, bone_names, frame_start, frame_end,
                include_position, include_rotation):
    """One row per frame, all bones as columns."""
    header = ['frame']
    for name in bone_names:
        if include_position:
            header.extend([f'{name}_px', f'{name}_py', f'{name}_pz'])
        if include_rotation:
            header.extend([f'{name}_qw', f'{name}_qx', f'{name}_qy', f'{name}_qz'])
    writer.writerow(header)

    scene = bpy.context.scene
    for frame in range(frame_start, frame_end + 1):
        scene.frame_set(frame)
        row = [frame]
        for name in bone_names:
            pbone = armature_obj.pose.bones[name]
            if include_position:
                world_pos = armature_obj.matrix_world @ pbone.head
                row.extend([round(world_pos.x, 6),
                            round(world_pos.y, 6),
                            round(world_pos.z, 6)])
            if include_rotation:
                q = pbone.rotation_quaternion
                row.extend([round(q.w, 6), round(q.x, 6),
                            round(q.y, 6), round(q.z, 6)])
        writer.writerow(row)


def _write_long(writer, armature_obj, bone_names, frame_start, frame_end,
                include_position, include_rotation):
    """One row per bone per frame."""
    header = ['frame', 'bone']
    if include_position:
        header.extend(['px', 'py', 'pz'])
    if include_rotation:
        header.extend(['qw', 'qx', 'qy', 'qz'])
    writer.writerow(header)

    scene = bpy.context.scene
    for frame in range(frame_start, frame_end + 1):
        scene.frame_set(frame)
        for name in bone_names:
            pbone = armature_obj.pose.bones[name]
            row = [frame, name]
            if include_position:
                world_pos = armature_obj.matrix_world @ pbone.head
                row.extend([round(world_pos.x, 6),
                            round(world_pos.y, 6),
                            round(world_pos.z, 6)])
            if include_rotation:
                q = pbone.rotation_quaternion
                row.extend([round(q.w, 6), round(q.x, 6),
                            round(q.y, 6), round(q.z, 6)])
            writer.writerow(row)
