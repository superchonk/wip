"""
AI Mocap Studio - C3D binary export.
Exports bone positions as 3D marker data in C3D format.
Pure Python implementation using struct — no external dependencies.
"""

import struct
import bpy
from pathlib import Path


# C3D constants
_BLOCK_SIZE = 512
_ANALOG_RATE = 0.0
_POINT_SCALE = -1.0  # Negative = floating point data


def export_c3d(armature_obj, filepath, frame_start=None, frame_end=None,
               scale_to_mm=1000.0):
    """
    Export armature bone positions to C3D file.

    Bone head positions are treated as 3D marker positions.

    Args:
        armature_obj: Blender armature object.
        filepath: Output file path.
        frame_start: First frame.
        frame_end: Last frame.
        scale_to_mm: Multiply Blender metres by this to get mm (default 1000).

    Returns:
        (success: bool, message: str)
    """
    if armature_obj is None or armature_obj.type != 'ARMATURE':
        return False, "No valid armature selected"

    filepath = str(filepath)
    if not filepath.lower().endswith('.c3d'):
        filepath += '.c3d'

    Path(filepath).parent.mkdir(parents=True, exist_ok=True)

    scene = bpy.context.scene
    if frame_start is None:
        frame_start = scene.frame_start
    if frame_end is None:
        frame_end = scene.frame_end

    bone_names = [b.name for b in armature_obj.pose.bones]
    num_markers = len(bone_names)
    num_frames = frame_end - frame_start + 1
    fps = scene.render.fps

    # Collect marker data: list of frames, each frame is list of (x, y, z)
    frames_data = []
    for frame in range(frame_start, frame_end + 1):
        scene.frame_set(frame)
        frame_markers = []
        for name in bone_names:
            pbone = armature_obj.pose.bones[name]
            world_pos = armature_obj.matrix_world @ pbone.head
            frame_markers.append((
                world_pos.x * scale_to_mm,
                world_pos.y * scale_to_mm,
                world_pos.z * scale_to_mm,
            ))
        frames_data.append(frame_markers)

    try:
        _write_c3d(filepath, bone_names, frames_data, fps, num_markers,
                   num_frames, frame_start)
        return True, filepath
    except Exception as e:
        return False, str(e)


def _write_c3d(filepath, marker_names, frames_data, fps, num_markers,
               num_frames, first_frame):
    """Write a minimal valid C3D file."""
    with open(filepath, 'wb') as f:
        # We'll write: header block, parameter blocks, data blocks
        # Calculate sizes
        param_data = _build_parameters(marker_names, fps, num_markers,
                                       num_frames, first_frame)
        num_param_blocks = (len(param_data) + _BLOCK_SIZE - 1) // _BLOCK_SIZE
        data_start_block = 1 + num_param_blocks + 1  # 1-indexed: header + params

        # --- Header block (block 1) ---
        header = bytearray(_BLOCK_SIZE)
        # Byte 0: parameter block number (1-indexed, block 2)
        header[0] = 2
        # Byte 1: C3D signature = 0x50
        header[1] = 0x50
        # Word 2 (bytes 2-3): number of markers
        struct.pack_into('<H', header, 2, num_markers)
        # Word 3 (bytes 4-5): number of analog channels per frame
        struct.pack_into('<H', header, 4, 0)
        # Word 4 (bytes 6-7): first frame number
        struct.pack_into('<H', header, 6, min(first_frame, 65535))
        # Word 5 (bytes 8-9): last frame number
        struct.pack_into('<H', header, 8, min(first_frame + num_frames - 1, 65535))
        # Word 6 (bytes 10-11): max interpolation gap
        struct.pack_into('<H', header, 10, 0)
        # Word 7-8 (bytes 12-15): scale factor (float)
        struct.pack_into('<f', header, 12, _POINT_SCALE)
        # Word 9 (bytes 16-17): data start block
        struct.pack_into('<H', header, 16, data_start_block)
        # Word 10 (bytes 18-19): analog samples per frame
        struct.pack_into('<H', header, 18, 0)
        # Word 11-12 (bytes 20-23): frame rate (float)
        struct.pack_into('<f', header, 20, float(fps))
        f.write(header)

        # --- Parameter blocks (starting at block 2) ---
        # Pad parameter data to full blocks
        padded_params = param_data + bytes(num_param_blocks * _BLOCK_SIZE - len(param_data))
        f.write(padded_params)

        # --- Data blocks ---
        for frame_markers in frames_data:
            for x, y, z in frame_markers:
                # Each point: X, Y, Z as float32 + word (camera info + residual)
                f.write(struct.pack('<fff', x, y, z))
                # Camera byte and residual (set to valid marker)
                f.write(struct.pack('<f', 0.0))


def _build_parameters(marker_names, fps, num_markers, num_frames, first_frame):
    """Build the C3D parameter section."""
    params = bytearray()

    # Parameter section header (4 bytes at start of block 2)
    params.extend(struct.pack('<BB', 0, 0))  # reserved bytes
    params.extend(struct.pack('<B', 0))       # number of parameter blocks (filled later)
    params.extend(struct.pack('<B', 0x54))    # processor type: Intel (little-endian)

    # --- POINT group (ID=1) ---
    params.extend(_make_group(1, "POINT"))

    # POINT:USED
    params.extend(_make_param_int16(1, "USED", num_markers))
    # POINT:FRAMES
    params.extend(_make_param_int16(1, "FRAMES", min(num_frames, 65535)))
    # POINT:SCALE
    params.extend(_make_param_float(1, "SCALE", _POINT_SCALE))
    # POINT:RATE
    params.extend(_make_param_float(1, "RATE", float(fps)))
    # POINT:DATA_START
    data_start_block = 1 + ((len(params) + 512) // _BLOCK_SIZE) + 1
    params.extend(_make_param_int16(1, "DATA_START", data_start_block))
    # POINT:LABELS
    params.extend(_make_param_string_array(1, "LABELS", marker_names))

    # --- ANALOG group (ID=2) ---
    params.extend(_make_group(2, "ANALOG"))
    params.extend(_make_param_int16(2, "USED", 0))
    params.extend(_make_param_float(2, "RATE", _ANALOG_RATE))

    # Recalculate data_start now that we know param size
    num_param_blocks = (len(params) + _BLOCK_SIZE - 1) // _BLOCK_SIZE
    actual_data_start = 1 + num_param_blocks + 1

    # Update the DATA_START value — find it and overwrite
    # For simplicity, just rebuild with correct value
    params2 = bytearray()
    params2.extend(struct.pack('<BB', 0, 0))
    params2.extend(struct.pack('<B', num_param_blocks))
    params2.extend(struct.pack('<B', 0x54))

    params2.extend(_make_group(1, "POINT"))
    params2.extend(_make_param_int16(1, "USED", num_markers))
    params2.extend(_make_param_int16(1, "FRAMES", min(num_frames, 65535)))
    params2.extend(_make_param_float(1, "SCALE", _POINT_SCALE))
    params2.extend(_make_param_float(1, "RATE", float(fps)))
    params2.extend(_make_param_int16(1, "DATA_START", actual_data_start))
    params2.extend(_make_param_string_array(1, "LABELS", marker_names))
    params2.extend(_make_group(2, "ANALOG"))
    params2.extend(_make_param_int16(2, "USED", 0))
    params2.extend(_make_param_float(2, "RATE", _ANALOG_RATE))

    return bytes(params2)


def _make_group(group_id, name):
    """Create a parameter group entry."""
    name_bytes = name.encode('ascii')
    name_len = len(name_bytes)
    data = bytearray()
    # Name length (negative = group, positive = parameter)
    data.append((-name_len) & 0xFF)
    data.append(group_id)
    data.extend(name_bytes)
    # Offset to next item (2 bytes) — description length + 2
    desc = name.encode('ascii')
    offset = 2 + len(desc)
    data.extend(struct.pack('<h', offset))
    data.append(len(desc))
    data.extend(desc)
    return bytes(data)


def _make_param_int16(group_id, name, value):
    """Create an integer parameter entry."""
    name_bytes = name.encode('ascii')
    data = bytearray()
    data.append(len(name_bytes))
    data.append(group_id)
    data.extend(name_bytes)
    # Offset to next: data_size(2) + dim_count(1) + value(2) + desc_len(1)
    payload = bytearray()
    payload.extend(struct.pack('<b', 2))   # data type: int16
    payload.append(0)                       # 0 dimensions (scalar)
    payload.extend(struct.pack('<h', value))
    payload.append(0)                       # description length
    offset = len(payload) + 2
    data.extend(struct.pack('<h', offset))
    data.extend(payload)
    return bytes(data)


def _make_param_float(group_id, name, value):
    """Create a float parameter entry."""
    name_bytes = name.encode('ascii')
    data = bytearray()
    data.append(len(name_bytes))
    data.append(group_id)
    data.extend(name_bytes)
    payload = bytearray()
    payload.extend(struct.pack('<b', 4))   # data type: float
    payload.append(0)                       # 0 dimensions
    payload.extend(struct.pack('<f', value))
    payload.append(0)
    offset = len(payload) + 2
    data.extend(struct.pack('<h', offset))
    data.extend(payload)
    return bytes(data)


def _make_param_string_array(group_id, name, strings):
    """Create a string array parameter (LABELS)."""
    name_bytes = name.encode('ascii')
    max_len = max((len(s) for s in strings), default=0)
    max_len = max(max_len, 4)  # Minimum 4 chars

    data = bytearray()
    data.append(len(name_bytes))
    data.append(group_id)
    data.extend(name_bytes)
    payload = bytearray()
    payload.extend(struct.pack('<b', -1))  # data type: char
    payload.append(2)                       # 2 dimensions
    payload.extend(struct.pack('<BB', max_len, len(strings)))
    for s in strings:
        encoded = s.encode('ascii')[:max_len]
        payload.extend(encoded)
        payload.extend(b' ' * (max_len - len(encoded)))
    payload.append(0)  # description length
    offset = len(payload) + 2
    data.extend(struct.pack('<h', offset))
    data.extend(payload)
    return bytes(data)
