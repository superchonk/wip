"""
AI Mocap Studio - FBX export.
Wraps Blender's native FBX exporter with mocap-friendly settings.
"""

import bpy
from pathlib import Path


def export_fbx(armature_obj, filepath, frame_start=None, frame_end=None,
               scale=1.0, bake_anim=True):
    """
    Export armature animation to FBX file.

    Args:
        armature_obj: Blender armature object.
        filepath: Output file path.
        frame_start: First frame (defaults to scene start).
        frame_end: Last frame (defaults to scene end).
        scale: Global scale factor (1.0 = metres, 100.0 for UE cm).
        bake_anim: Whether to bake animation curves.

    Returns:
        (success: bool, message: str)
    """
    if armature_obj is None or armature_obj.type != 'ARMATURE':
        return False, "No valid armature selected"

    filepath = str(filepath)
    if not filepath.lower().endswith('.fbx'):
        filepath += '.fbx'

    Path(filepath).parent.mkdir(parents=True, exist_ok=True)

    scene = bpy.context.scene
    if frame_start is None:
        frame_start = scene.frame_start
    if frame_end is None:
        frame_end = scene.frame_end

    # Select only the armature (and optionally its mesh children)
    bpy.ops.object.select_all(action='DESELECT')
    armature_obj.select_set(True)
    for child in armature_obj.children:
        if child.type == 'MESH':
            child.select_set(True)
    bpy.context.view_layer.objects.active = armature_obj

    try:
        bpy.ops.export_scene.fbx(
            filepath=filepath,
            use_selection=True,
            object_types={'ARMATURE', 'MESH'},
            use_mesh_modifiers=True,
            add_leaf_bones=False,
            primary_bone_axis='Y',
            secondary_bone_axis='X',
            use_armature_deform_only=True,
            bake_anim=bake_anim,
            bake_anim_use_all_bones=True,
            bake_anim_use_nla_strips=False,
            bake_anim_use_all_actions=False,
            bake_anim_force_startend_keying=True,
            bake_anim_step=1.0,
            bake_anim_simplify_factor=0.0,
            global_scale=scale,
            apply_scale_options='FBX_SCALE_ALL',
            axis_forward='-Z',
            axis_up='Y',
        )
        return True, filepath
    except Exception as e:
        return False, str(e)
