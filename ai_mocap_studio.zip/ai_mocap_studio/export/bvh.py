"""
AI Mocap Studio - BVH export.
"""

import bpy
from pathlib import Path


def export_bvh(armature_obj, filepath, frame_start=None, frame_end=None):
    """
    Export armature animation to BVH file.
    Uses Blender's built-in BVH exporter.
    """
    if armature_obj is None or armature_obj.type != 'ARMATURE':
        return False, "No valid armature selected"

    # Ensure filepath has .bvh extension
    filepath = str(filepath)
    if not filepath.lower().endswith('.bvh'):
        filepath += '.bvh'

    # Ensure directory exists
    Path(filepath).parent.mkdir(parents=True, exist_ok=True)

    # Determine frame range
    scene = bpy.context.scene
    if frame_start is None:
        frame_start = scene.frame_start
    if frame_end is None:
        frame_end = scene.frame_end

    # Select armature
    bpy.ops.object.select_all(action='DESELECT')
    armature_obj.select_set(True)
    bpy.context.view_layer.objects.active = armature_obj

    try:
        bpy.ops.export_anim.bvh(
            filepath=filepath,
            frame_start=frame_start,
            frame_end=frame_end,
            rotate_mode='NATIVE',
            root_transform_only=False,
        )
        return True, filepath
    except Exception as e:
        return False, str(e)
