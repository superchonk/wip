"""
AI Mocap Studio - Streaming package.
Provides real-time pose streaming over UDP to external applications.
"""
