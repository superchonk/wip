"""
AI Mocap Studio - VMC protocol streaming for VTubing.
Sends bone transforms using VMC protocol (OSC over UDP).

Includes a minimal built-in OSC message builder (~30 lines, no dependencies).

Coordinate conversion: Blender Z-up right-hand → Unity Y-up left-hand
Position:  (-X, Z, Y)
Quaternion: (qx, -qz, -qy, qw)

VMC messages:
    /VMC/Ext/Root/Pos — root bone position + quaternion
    /VMC/Ext/Bone/Pos — per-bone name, position, rotation
    /VMC/Ext/Blend/Val — blendshape value
    /VMC/Ext/Blend/Apply — apply blendshapes
    /VMC/Ext/OK — status
    /VMC/Ext/T — timestamp
"""

import struct
import socket
import time
import threading


# ============================================================
# Minimal OSC builder (no external dependencies)
# ============================================================

def _osc_string(s):
    """Encode an OSC string: null-terminated, padded to 4-byte boundary."""
    encoded = s.encode('utf-8') + b'\x00'
    padding = (4 - len(encoded) % 4) % 4
    return encoded + b'\x00' * padding


def _osc_int(value):
    """Encode an OSC int32."""
    return struct.pack('>i', int(value))


def _osc_float(value):
    """Encode an OSC float32."""
    return struct.pack('>f', float(value))


def osc_message(address, *args):
    """
    Build an OSC message.

    Args:
        address: OSC address string (e.g. '/VMC/Ext/Bone/Pos')
        *args: tuples of (type_tag, value) where type_tag is 's', 'i', or 'f'

    Returns:
        bytes — the complete OSC message
    """
    buf = bytearray()
    buf.extend(_osc_string(address))

    # Type tag string
    tags = ','
    for tag, _ in args:
        tags += tag
    buf.extend(_osc_string(tags))

    # Arguments
    for tag, value in args:
        if tag == 's':
            buf.extend(_osc_string(str(value)))
        elif tag == 'i':
            buf.extend(_osc_int(value))
        elif tag == 'f':
            buf.extend(_osc_float(value))

    return bytes(buf)


def osc_bundle(timetag, *messages):
    """
    Build an OSC bundle.

    Args:
        timetag: NTP timestamp as int64 (0 = immediately)
        *messages: bytes of individual OSC messages

    Returns:
        bytes — the complete OSC bundle
    """
    buf = bytearray()
    buf.extend(b'#bundle\x00')
    buf.extend(struct.pack('>Q', timetag))
    for msg in messages:
        buf.extend(struct.pack('>I', len(msg)))
        buf.extend(msg)
    return bytes(buf)


# ============================================================
# VMC Stream
# ============================================================

class VMCStream:
    """Streams bone transforms and blendshapes using VMC protocol over UDP."""

    def __init__(self, ip="127.0.0.1", port=39539, send_blendshapes=True):
        self.ip = ip
        self.port = port
        self.send_blendshapes = send_blendshapes
        self._socket = None
        self._running = False
        self._lock = threading.Lock()

    @property
    def is_running(self):
        return self._running

    def start(self):
        """Open UDP socket."""
        if self._running:
            return
        self._socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self._running = True

    def stop(self):
        """Close UDP socket."""
        self._running = False
        with self._lock:
            if self._socket is not None:
                try:
                    self._socket.close()
                except OSError:
                    pass
                self._socket = None

    def send_pose(self, bone_transforms, blendshapes=None):
        """
        Send a full pose frame via VMC protocol.

        Args:
            bone_transforms: list of dicts with keys:
                'name': str — bone name
                'location': (x, y, z) in Blender space
                'rotation': (w, x, y, z) quaternion in Blender space
                'is_root': bool (optional) — True for the root bone
            blendshapes: dict of {name: float_value} (ARKit 52 blendshapes)
        """
        if not self._running or self._socket is None:
            return

        messages = []

        # Status message
        messages.append(osc_message('/VMC/Ext/OK', ('i', 1)))

        # Timestamp
        messages.append(osc_message('/VMC/Ext/T', ('f', time.time())))

        # Bone transforms
        for bt in bone_transforms:
            bx, by, bz = bt.get('location', (0, 0, 0))
            qw, qx, qy, qz = bt.get('rotation', (1, 0, 0, 0))

            # Blender → Unity coordinate conversion
            ux = -bx
            uy = bz
            uz = by

            uqx = qx
            uqy = -qz
            uqz = -qy
            uqw = qw

            name = bt['name']

            if bt.get('is_root', False):
                messages.append(osc_message(
                    '/VMC/Ext/Root/Pos',
                    ('s', name),
                    ('f', ux), ('f', uy), ('f', uz),
                    ('f', uqx), ('f', uqy), ('f', uqz), ('f', uqw),
                ))
            else:
                messages.append(osc_message(
                    '/VMC/Ext/Bone/Pos',
                    ('s', name),
                    ('f', ux), ('f', uy), ('f', uz),
                    ('f', uqx), ('f', uqy), ('f', uqz), ('f', uqw),
                ))

        # Blendshapes
        if self.send_blendshapes and blendshapes:
            for bs_name, bs_value in blendshapes.items():
                messages.append(osc_message(
                    '/VMC/Ext/Blend/Val',
                    ('s', bs_name),
                    ('f', float(bs_value)),
                ))
            messages.append(osc_message('/VMC/Ext/Blend/Apply'))

        # Send as bundle
        bundle = osc_bundle(0, *messages)

        with self._lock:
            if self._socket is not None:
                try:
                    self._socket.sendto(bundle, (self.ip, self.port))
                except OSError:
                    pass
