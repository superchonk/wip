"""
AI Mocap Studio - Live Link streaming for Unreal Engine.
Sends bone transforms over UDP using the Live Link binary protocol.

Coordinate conversion: Blender Z-up right-hand (m)
                    → UE Z-up left-hand (cm)
Position:  (Y*100, X*100, Z*100)
Quaternion: (qy, qx, qz, qw)
"""

import struct
import socket
import time
import threading


class LiveLinkStream:
    """Streams bone transforms to Unreal Engine via Live Link UDP protocol."""

    def __init__(self, ip="127.0.0.1", port=11111, subject_name="AIMocap"):
        self.ip = ip
        self.port = port
        self.subject_name = subject_name
        self._socket = None
        self._running = False
        self._lock = threading.Lock()
        self._frame_counter = 0

    @property
    def is_running(self):
        return self._running

    def start(self):
        """Open UDP socket."""
        if self._running:
            return
        self._socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self._running = True
        self._frame_counter = 0

    def stop(self):
        """Close UDP socket."""
        self._running = False
        with self._lock:
            if self._socket is not None:
                try:
                    self._socket.close()
                except OSError:
                    pass
                self._socket = None

    def send_pose(self, bone_transforms):
        """
        Send a full pose frame to Unreal Engine.

        Args:
            bone_transforms: list of dicts with keys:
                'name': str — bone name
                'location': (x, y, z) in Blender space (metres)
                'rotation': (w, x, y, z) quaternion in Blender space
        """
        if not self._running or self._socket is None:
            return

        packet = self._build_packet(bone_transforms)
        if packet is None:
            return

        with self._lock:
            if self._socket is not None:
                try:
                    self._socket.sendto(packet, (self.ip, self.port))
                except OSError:
                    pass

        self._frame_counter += 1

    def _build_packet(self, bone_transforms):
        """Build a Live Link compatible UDP packet."""
        buf = bytearray()

        # --- Header ---
        # Version (uint8)
        buf.extend(struct.pack('<B', 6))
        # Device ID (FGuid: 4 x uint32) — use a fixed ID
        buf.extend(struct.pack('<IIII', 0xA10C0001, 0, 0, 1))
        # Frame counter
        buf.extend(struct.pack('<I', self._frame_counter))

        # --- Subject name (FString: length + chars) ---
        name_bytes = self.subject_name.encode('utf-8')
        buf.extend(struct.pack('<I', len(name_bytes) + 1))
        buf.extend(name_bytes)
        buf.extend(b'\x00')

        # --- Number of bones ---
        num_bones = len(bone_transforms)
        buf.extend(struct.pack('<I', num_bones))

        # --- Bone names ---
        for bt in bone_transforms:
            bname = bt['name'].encode('utf-8')
            buf.extend(struct.pack('<I', len(bname) + 1))
            buf.extend(bname)
            buf.extend(b'\x00')

        # --- Bone transforms (location + rotation + scale) ---
        for bt in bone_transforms:
            bx, by, bz = bt.get('location', (0, 0, 0))
            qw, qx, qy, qz = bt.get('rotation', (1, 0, 0, 0))

            # Convert Blender → UE coordinates
            ue_x = by * 100.0
            ue_y = bx * 100.0
            ue_z = bz * 100.0

            ue_qx = qy
            ue_qy = qx
            ue_qz = qz
            ue_qw = qw

            # Location (3 x double)
            buf.extend(struct.pack('<ddd', ue_x, ue_y, ue_z))
            # Rotation as quaternion (4 x double): x, y, z, w
            buf.extend(struct.pack('<dddd', ue_qx, ue_qy, ue_qz, ue_qw))
            # Scale (3 x double)
            buf.extend(struct.pack('<ddd', 1.0, 1.0, 1.0))

        return bytes(buf)
