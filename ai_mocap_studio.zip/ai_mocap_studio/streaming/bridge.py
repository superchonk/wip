"""
AI Mocap Studio - Streaming bridge.
Reads pose bone data from the armature and feeds it to active streams.

    Capture Loop → PoseRetargeter.apply_pose() → armature pose updated
                                                ↓
                                  bridge.feed_body_frame()
                                        ↓            ↓
                                LiveLinkStream   VMCStream
"""

import bpy
from .livelink import LiveLinkStream
from .vmc import VMCStream

# Global stream instances
_livelink_stream = None
_vmc_stream = None


def get_livelink_stream():
    """Return the current LiveLink stream instance (or None)."""
    return _livelink_stream


def get_vmc_stream():
    """Return the current VMC stream instance (or None)."""
    return _vmc_stream


def start_livelink(ip="127.0.0.1", port=11111, subject="AIMocap"):
    """Create and start a LiveLink stream."""
    global _livelink_stream
    stop_livelink()
    _livelink_stream = LiveLinkStream(ip=ip, port=port, subject_name=subject)
    _livelink_stream.start()
    return _livelink_stream


def stop_livelink():
    """Stop and dispose of the LiveLink stream."""
    global _livelink_stream
    if _livelink_stream is not None:
        _livelink_stream.stop()
        _livelink_stream = None


def start_vmc(ip="127.0.0.1", port=39539, send_blendshapes=True):
    """Create and start a VMC stream."""
    global _vmc_stream
    stop_vmc()
    _vmc_stream = VMCStream(ip=ip, port=port, send_blendshapes=send_blendshapes)
    _vmc_stream.start()
    return _vmc_stream


def stop_vmc():
    """Stop and dispose of the VMC stream."""
    global _vmc_stream
    if _vmc_stream is not None:
        _vmc_stream.stop()
        _vmc_stream = None


def stop_all():
    """Stop all active streams."""
    stop_livelink()
    stop_vmc()


def is_any_streaming():
    """Return True if any stream is currently active."""
    return ((_livelink_stream is not None and _livelink_stream.is_running) or
            (_vmc_stream is not None and _vmc_stream.is_running))


def feed_body_frame(armature_obj, blendshapes=None):
    """
    Read current pose bones from the armature and send to all active streams.

    Should be called after PoseRetargeter.apply_pose() has updated the
    armature's pose bones.

    Args:
        armature_obj: The Blender armature object with updated pose.
        blendshapes: Optional dict of {name: float} for face blendshapes.
    """
    if armature_obj is None or armature_obj.type != 'ARMATURE':
        return

    if not is_any_streaming():
        return

    bone_transforms = _collect_bone_transforms(armature_obj)

    if _livelink_stream is not None and _livelink_stream.is_running:
        _livelink_stream.send_pose(bone_transforms)

    if _vmc_stream is not None and _vmc_stream.is_running:
        _vmc_stream.send_pose(bone_transforms, blendshapes=blendshapes)


def _collect_bone_transforms(armature_obj):
    """Collect bone transforms from the armature's current pose."""
    transforms = []
    root_bones = [b for b in armature_obj.pose.bones if b.parent is None]

    for pbone in armature_obj.pose.bones:
        world_matrix = armature_obj.matrix_world @ pbone.matrix
        loc = world_matrix.to_translation()
        rot = pbone.rotation_quaternion.copy()

        is_root = pbone.parent is None

        transforms.append({
            'name': pbone.name,
            'location': (loc.x, loc.y, loc.z),
            'rotation': (rot.w, rot.x, rot.y, rot.z),
            'is_root': is_root,
        })

    return transforms
