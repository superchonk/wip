"""
AI Mocap Studio - Main UI panels in 3D Viewport N-panel.
"""

import bpy
from bpy.types import Panel

from ..operators.capture_ops import _capture_state


class AIMOCAP_PT_main_panel(Panel):
    """Main AI Mocap Studio panel"""
    bl_label = "AI Mocap Studio"
    bl_idname = "AIMOCAP_PT_main_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "AI Mocap"

    def draw(self, context):
        layout = self.layout

        # Dependencies check
        from ..core.dependencies import check_dependencies
        deps_ok, missing = check_dependencies()

        if not deps_ok:
            box = layout.box()
            box.alert = True
            box.label(text="Missing dependencies:", icon='ERROR')
            for pkg in missing:
                box.label(text=f"  • {pkg}")
            box.operator("aimocap.install_dependencies", icon='IMPORT')
            return

        # Status indicator
        is_running = _capture_state["running"]
        is_recording = _capture_state["recording"]
        mode = _capture_state["capture_mode"]

        if is_running:
            row = layout.row()
            row.alert = True
            if is_recording:
                row.label(text=f"● REC [{mode}]", icon='REC')
                row.label(text=f"Frame: {_capture_state['frame_counter']}")
            else:
                row.label(text=f"● LIVE [{mode}]", icon='CAMERA_DATA')


class AIMOCAP_PT_capture_panel(Panel):
    """Capture controls"""
    bl_label = "Capture"
    bl_idname = "AIMOCAP_PT_capture_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "AI Mocap"
    bl_parent_id = "AIMOCAP_PT_main_panel"

    def draw(self, context):
        layout = self.layout
        is_running = _capture_state["running"]

        # Capture mode selector (only when not running)
        if not is_running:
            layout.prop(context.scene, "aimocap_capture_mode", text="Mode")

        # Webcam controls
        col = layout.column(align=True)
        if not is_running:
            col.operator("aimocap.start_webcam", text="Start Webcam", icon='CAMERA_DATA')
            col.operator("aimocap.capture_from_video", text="Capture from Video", icon='FILE_MOVIE')
            col.operator("aimocap.capture_from_image", text="Capture from Image", icon='FILE_IMAGE')
        else:
            col.operator("aimocap.stop_capture", text="Stop Capture", icon='CANCEL')
            col.separator()

            # Recording toggle
            is_recording = _capture_state["recording"]
            if is_recording:
                col.operator("aimocap.toggle_recording", text="Stop Recording", icon='PAUSE', depress=True)
            else:
                col.operator("aimocap.toggle_recording", text="Start Recording", icon='REC')


class AIMOCAP_PT_armature_panel(Panel):
    """Armature and retarget settings"""
    bl_label = "Armature"
    bl_idname = "AIMOCAP_PT_armature_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "AI Mocap"
    bl_parent_id = "AIMOCAP_PT_main_panel"

    def draw(self, context):
        layout = self.layout

        # Target armature info
        obj = context.active_object
        if obj and obj.type == 'ARMATURE':
            layout.label(text=f"Target: {obj.name}", icon='ARMATURE_DATA')
        else:
            layout.label(text="Select an armature", icon='INFO')

        # Rig type selection
        row = layout.row(align=True)
        row.prop(context.scene, "aimocap_rig_type", text="Rig Type")
        row.operator("aimocap.auto_detect_rig", text="", icon='VIEWZOOM')

        # Scale
        layout.prop(context.scene, "aimocap_scale", text="Scale")

        # Actions
        col = layout.column(align=True)
        col.operator("aimocap.reset_pose", icon='LOOP_BACK')
        col.operator("aimocap.clear_keyframes", icon='TRASH')


class AIMOCAP_PT_face_panel(Panel):
    """Face capture settings"""
    bl_label = "Face Capture"
    bl_idname = "AIMOCAP_PT_face_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "AI Mocap"
    bl_parent_id = "AIMOCAP_PT_main_panel"

    @classmethod
    def poll(cls, context):
        mode = context.scene.aimocap_capture_mode
        return mode in ("FACE", "HOLISTIC")

    def draw(self, context):
        layout = self.layout

        # Face mesh target
        layout.prop_search(
            context.scene, "aimocap_face_mesh",
            bpy.data, "objects",
            text="Face Mesh",
            icon='MESH_DATA',
        )

        # Info about face mesh
        face_mesh_name = context.scene.aimocap_face_mesh
        if face_mesh_name:
            face_obj = bpy.data.objects.get(face_mesh_name)
            if face_obj and face_obj.type == 'MESH':
                if face_obj.data.shape_keys:
                    n_keys = len(face_obj.data.shape_keys.key_blocks) - 1  # minus Basis
                    layout.label(text=f"Shape Keys: {n_keys}/52", icon='SHAPEKEY_DATA')
                else:
                    layout.label(text="No Shape Keys found", icon='INFO')
                    layout.operator("aimocap.create_face_shapekeys", icon='ADD')
            elif face_obj:
                layout.label(text="Object is not a mesh", icon='ERROR')
        else:
            layout.label(text="Select a mesh for face blendshapes", icon='INFO')

        layout.separator()

        # Create shape keys button (always accessible)
        layout.operator("aimocap.create_face_shapekeys", text="Create ARKit Shape Keys", icon='SHAPEKEY_DATA')


class AIMOCAP_PT_hands_panel(Panel):
    """Hand capture info"""
    bl_label = "Hand Capture"
    bl_idname = "AIMOCAP_PT_hands_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "AI Mocap"
    bl_parent_id = "AIMOCAP_PT_main_panel"

    @classmethod
    def poll(cls, context):
        mode = context.scene.aimocap_capture_mode
        return mode in ("HANDS", "HOLISTIC")

    def draw(self, context):
        layout = self.layout

        # Info
        obj = context.active_object
        if obj and obj.type == 'ARMATURE':
            rig_type = context.scene.aimocap_rig_type

            # Count finger bones found
            from ..retarget.hands import FINGER_BONE_CHAINS
            chains = FINGER_BONE_CHAINS.get(rig_type, {})
            found = 0
            total = 0
            for chain_data in chains.values():
                for bone_name in chain_data["bones"]:
                    total += 1
                    if bone_name in obj.data.bones:
                        found += 1

            if total > 0:
                layout.label(text=f"Finger bones: {found}/{total}", icon='BONE_DATA')
                if found == 0:
                    layout.label(text="No matching finger bones", icon='ERROR')
                    layout.label(text=f"Expected: {rig_type} naming")
            else:
                layout.label(text="No finger mapping for rig type", icon='INFO')
        else:
            layout.label(text="Select armature with finger bones", icon='INFO')

        # Tracking info
        box = layout.box()
        box.label(text="21 landmarks per hand", icon='INFO')
        box.label(text="All finger segments tracked")
        box.label(text="Thumb, Index, Middle, Ring, Pinky")


class AIMOCAP_PT_multicam_panel(Panel):
    """Multi-camera capture and calibration"""
    bl_label = "Multi-Camera"
    bl_idname = "AIMOCAP_PT_multicam_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "AI Mocap"
    bl_parent_id = "AIMOCAP_PT_main_panel"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout

        from ..operators.multicam_ops import _multicam_state

        # Camera indices
        layout.prop(context.scene, "aimocap_multicam_indices", text="Cameras")
        layout.prop(context.scene, "aimocap_multicam_sync_tolerance", text="Sync Tolerance")
        layout.prop(context.scene, "aimocap_multicam_occlusion_resolve")

        layout.separator()

        # Calibration
        col = layout.column(align=True)
        col.label(text="Calibration:", icon='VIEW_CAMERA')

        calib = _multicam_state["calibration"]
        if calib and calib.stereo_pairs:
            n_cams = len(calib.intrinsics)
            n_pairs = len(calib.stereo_pairs)
            col.label(text=f"Calibrated: {n_cams} cameras, {n_pairs} pairs", icon='CHECKMARK')

            # Show reprojection errors
            for cam_idx, intr in calib.intrinsics.items():
                if intr.calibrated:
                    col.label(text=f"  Cam {cam_idx}: err={intr.reprojection_error:.4f}")
        else:
            col.label(text="Not calibrated", icon='INFO')

        row = col.row(align=True)
        row.operator("aimocap.start_calibration", text="Calibrate", icon='VIEW_CAMERA')
        row.operator("aimocap.load_calibration", text="Load", icon='FILE_FOLDER')

        layout.separator()

        # Multi-cam capture
        col = layout.column(align=True)
        col.label(text="Multi-Camera Capture:", icon='CAMERA_STEREO')

        is_running = _multicam_state["running"]
        is_calibrating = _multicam_state["calibrating"]

        if is_calibrating:
            col.label(text="Calibrating...", icon='TIME')
        elif not is_running:
            col.operator("aimocap.start_multicam", text="Start Multi-Cam", icon='CAMERA_STEREO')
            col.operator("aimocap.capture_from_multi_video", text="From Multi-Video", icon='FILE_MOVIE')
        else:
            col.operator("aimocap.stop_multicam", text="Stop Multi-Cam", icon='CANCEL')
            col.separator()

            is_recording = _multicam_state["recording"]
            if is_recording:
                col.operator("aimocap.toggle_multicam_recording",
                             text="Stop Recording", icon='PAUSE', depress=True)
                col.label(text=f"Frame: {_multicam_state['frame_counter']}")
            else:
                col.operator("aimocap.toggle_multicam_recording",
                             text="Start Recording", icon='REC')

            # Sync stats
            sync = _multicam_state["sync"]
            if sync:
                box = layout.box()
                box.label(text=f"Cameras: {sync.camera_count}", icon='CAMERA_DATA')
                box.label(text=f"Sync rate: {sync.sync_rate:.0%}")


class AIMOCAP_PT_multiperson_panel(Panel):
    """Multi-person tracking and capture"""
    bl_label = "Multi-Person"
    bl_idname = "AIMOCAP_PT_multiperson_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "AI Mocap"
    bl_parent_id = "AIMOCAP_PT_main_panel"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout

        from ..operators.multiperson_ops import _mp_state

        is_running = _mp_state["running"]
        is_recording = _mp_state["recording"]

        if not is_running:
            col = layout.column(align=True)
            col.operator("aimocap.start_multiperson", icon='GROUP')
        else:
            col = layout.column(align=True)
            col.operator("aimocap.stop_multiperson", text="Stop", icon='CANCEL')
            col.separator()

            # Recording
            if is_recording:
                col.operator("aimocap.toggle_multiperson_recording",
                             text="Stop Recording", icon='PAUSE', depress=True)
                col.label(text=f"Frame: {_mp_state['frame_counter']}")
            else:
                col.operator("aimocap.toggle_multiperson_recording",
                             text="Start Recording", icon='REC')

            layout.separator()

            # Tracked persons info
            tracker = _mp_state.get("tracker")
            if tracker:
                box = layout.box()
                box.label(text=f"Tracked: {tracker.num_tracked} persons", icon='GROUP')

                for track_id, track in tracker.active_tracks.items():
                    row = box.row()
                    has_arm = track_id in _mp_state["armatures"]
                    icon = 'CHECKMARK' if has_arm else 'BLANK1'
                    arm_name = _mp_state["armatures"][track_id].name if has_arm else "---"
                    row.label(text=f"  P{track_id}: {arm_name}", icon=icon)

                    if not has_arm:
                        op = row.operator("aimocap.assign_person_armature",
                                          text="", icon='LINK_BLEND')
                        op.person_id = track_id

            layout.separator()
            layout.operator("aimocap.auto_assign_armatures", icon='LINKED')

            # Active person filter
            layout.separator()
            row = layout.row(align=True)
            row.label(text="Record:")
            op = row.operator("aimocap.select_active_person", text="All")
            op.person_id = -1
            active = _mp_state["active_person"]
            if active >= 0:
                row.label(text=f"(P{active})")


class AIMOCAP_PT_batch_panel(Panel):
    """Batch processing and video queue"""
    bl_label = "Batch Processing"
    bl_idname = "AIMOCAP_PT_batch_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "AI Mocap"
    bl_parent_id = "AIMOCAP_PT_main_panel"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout

        col = layout.column(align=True)
        col.label(text="Single-Person Batch:", icon='FILE_MOVIE')
        col.operator("aimocap.batch_process", icon='RENDER_ANIMATION')

        layout.separator()

        col = layout.column(align=True)
        col.label(text="Multi-Person Batch:", icon='GROUP')
        col.operator("aimocap.batch_multiperson", icon='RENDER_ANIMATION')


class AIMOCAP_PT_takes_panel(Panel):
    """Take management"""
    bl_label = "Takes"
    bl_idname = "AIMOCAP_PT_takes_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "AI Mocap"
    bl_parent_id = "AIMOCAP_PT_main_panel"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout

        from ..capture.takes import get_take_manager
        mgr = get_take_manager()
        mgr.load_from_scene(context.scene)

        takes = mgr.get_all_takes()

        if not takes:
            layout.label(text="No takes recorded yet", icon='INFO')
            layout.operator("aimocap.refresh_takes", icon='FILE_REFRESH')
            return

        layout.label(text=f"{len(takes)} takes:", icon='ACTION')

        for take in takes:
            box = layout.box()

            # Header row
            row = box.row()
            row.label(text=take.name, icon='ACTION')
            if take.person_id >= 0:
                row.label(text=f"P{take.person_id}", icon='GROUP')

            # Info
            row = box.row()
            row.label(text=f"{take.frame_count} frames")
            row.label(text=f"{take.capture_mode}")
            if take.source != "webcam":
                row.label(text=take.source)

            # Actions row
            row = box.row(align=True)
            op = row.operator("aimocap.activate_take", text="", icon='PLAY')
            op.take_name = take.name

            op = row.operator("aimocap.rename_take", text="", icon='GREASEPENCIL')
            op.take_name = take.name

            op = row.operator("aimocap.duplicate_take", text="", icon='DUPLICATE')
            op.take_name = take.name

            op = row.operator("aimocap.add_take_note", text="", icon='TEXT')
            op.take_name = take.name

            op = row.operator("aimocap.delete_take", text="", icon='TRASH')
            op.take_name = take.name

            # Notes
            if take.notes:
                box.label(text=take.notes, icon='TEXT')

        layout.separator()
        layout.operator("aimocap.refresh_takes", icon='FILE_REFRESH')


class AIMOCAP_PT_processing_panel(Panel):
    """Post-processing tools"""
    bl_label = "Post-Processing"
    bl_idname = "AIMOCAP_PT_processing_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "AI Mocap"
    bl_parent_id = "AIMOCAP_PT_main_panel"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout

        obj = context.active_object
        has_action = (
            obj and obj.type == 'ARMATURE'
            and obj.animation_data
            and obj.animation_data.action
        )

        if not has_action:
            layout.label(text="Record animation first", icon='INFO')
            return

        action = obj.animation_data.action
        n_curves = len(action.fcurves)
        n_keys = sum(len(fc.keyframe_points) for fc in action.fcurves)
        layout.label(text=f"Action: {action.name}", icon='ACTION')
        layout.label(text=f"{n_curves} channels, {n_keys} keyframes")

        layout.separator()

        # Smoothing
        col = layout.column(align=True)
        col.label(text="Smoothing:", icon='SMOOTHCURVE')
        col.operator("aimocap.smooth_animation", icon='MOD_SMOOTH')

        layout.separator()

        # Cleanup
        col = layout.column(align=True)
        col.label(text="Cleanup:", icon='BRUSH_DATA')
        col.operator("aimocap.cleanup_animation", icon='PARTICLEMODE')

        layout.separator()

        # Foot Lock
        col = layout.column(align=True)
        col.label(text="Feet:", icon='CON_FLOOR')
        col.operator("aimocap.apply_foot_lock", icon='CONSTRAINT_BONE')

        layout.separator()

        # Keyframe tools
        col = layout.column(align=True)
        col.label(text="Keyframes:", icon='KEYFRAME')
        col.operator("aimocap.reduce_keyframes", icon='MOD_DECIM')
        col.operator("aimocap.resample_animation", icon='TIME')


class AIMOCAP_PT_export_panel(Panel):
    """Export controls"""
    bl_label = "Export"
    bl_idname = "AIMOCAP_PT_export_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "AI Mocap"
    bl_parent_id = "AIMOCAP_PT_main_panel"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout

        col = layout.column(align=True)
        col.label(text="Animation Formats:", icon='EXPORT')
        col.operator("aimocap.export_bvh", text="Export BVH", icon='ANIM_DATA')
        col.operator("aimocap.export_fbx", text="Export FBX", icon='MESH_DATA')
        col.operator("aimocap.export_csv", text="Export CSV", icon='FILE_TEXT')
        col.operator("aimocap.export_c3d", text="Export C3D", icon='TRACKER')


class AIMOCAP_PT_settings_panel(Panel):
    """Quick settings"""
    bl_label = "Settings"
    bl_idname = "AIMOCAP_PT_settings_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "AI Mocap"
    bl_parent_id = "AIMOCAP_PT_main_panel"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        prefs = context.preferences.addons["ai_mocap_studio"].preferences

        layout.prop(prefs, "min_detection_confidence")
        layout.prop(prefs, "min_tracking_confidence")
        layout.prop(prefs, "capture_fps")
        layout.prop(prefs, "camera_index")

        layout.separator()
        layout.prop(prefs, "use_smoothing")
        if prefs.use_smoothing:
            layout.prop(prefs, "smoothing_factor")

        layout.separator()
        layout.prop(prefs, "show_landmarks")
        if prefs.show_landmarks:
            layout.prop(prefs, "landmark_scale")


class AIMOCAP_PT_model_panel(Panel):
    """AI Model selection and management"""
    bl_label = "AI Model"
    bl_idname = "AIMOCAP_PT_model_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "AI Mocap"
    bl_parent_id = "AIMOCAP_PT_main_panel"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        prefs = context.preferences.addons["ai_mocap_studio"].preferences

        # Model selector
        layout.prop(prefs, "detection_model", text="Model")

        if prefs.detection_model == "YOLO_POSE":
            layout.prop(prefs, "yolo_variant", text="Size")

        # GPU toggle
        layout.prop(prefs, "use_gpu")

        # Active model status
        from ..models.manager import get_model_manager
        manager = get_model_manager()

        box = layout.box()
        if manager.active_model_name:
            model = manager.active_model
            box.label(text=f"Active: {manager.active_model_name}", icon='CHECKMARK')
            if model:
                box.label(text=f"Device: {model.device}")
                if hasattr(model, 'SUPPORTS_MULTI_PERSON') and model.SUPPORTS_MULTI_PERSON:
                    box.label(text="Multi-person: Yes", icon='GROUP')
                if hasattr(model, 'SUPPORTS_3D') and model.SUPPORTS_3D:
                    box.label(text="3D Pose: Yes", icon='ORIENTATION_GLOBAL')
        else:
            box.label(text="No model loaded", icon='INFO')

        # Actions
        row = layout.row(align=True)
        row.operator("aimocap.load_model", text="Load", icon='IMPORT')
        row.operator("aimocap.unload_model", text="Unload", icon='X')
        layout.operator("aimocap.install_model_deps", text="Install Dependencies", icon='MODIFIER')
        layout.operator("aimocap.detect_gpu", text="Detect GPU", icon='PREFERENCES')


class AIMOCAP_PT_streaming_panel(Panel):
    """Real-time streaming to external applications"""
    bl_label = "Streaming"
    bl_idname = "AIMOCAP_PT_streaming_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "AI Mocap"
    bl_parent_id = "AIMOCAP_PT_main_panel"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        from ..streaming.bridge import get_livelink_stream, get_vmc_stream

        # --- Live Link ---
        box = layout.box()
        box.label(text="Live Link (Unreal Engine)", icon='LINKED')

        ll_stream = get_livelink_stream()
        ll_running = ll_stream is not None and ll_stream.is_running

        col = box.column(align=True)
        col.prop(scene, "aimocap_livelink_ip", text="IP")
        col.prop(scene, "aimocap_livelink_port", text="Port")
        col.prop(scene, "aimocap_livelink_subject", text="Subject")

        if ll_running:
            box.operator("aimocap.stop_livelink", text="Stop Live Link",
                         icon='CANCEL', depress=True)
        else:
            box.operator("aimocap.start_livelink", text="Start Live Link",
                         icon='PLAY')

        # --- VMC ---
        box = layout.box()
        box.label(text="VMC (VTubing)", icon='USER')

        vmc_stream = get_vmc_stream()
        vmc_running = vmc_stream is not None and vmc_stream.is_running

        col = box.column(align=True)
        col.prop(scene, "aimocap_vmc_ip", text="IP")
        col.prop(scene, "aimocap_vmc_port", text="Port")
        col.prop(scene, "aimocap_vmc_blendshapes", text="Send Blendshapes")

        if vmc_running:
            box.operator("aimocap.stop_vmc", text="Stop VMC",
                         icon='CANCEL', depress=True)
        else:
            box.operator("aimocap.start_vmc", text="Start VMC",
                         icon='PLAY')

        # --- Stop All ---
        layout.separator()
        if ll_running or vmc_running:
            layout.operator("aimocap.stop_all_streaming", icon='X')


classes = [
    AIMOCAP_PT_main_panel,
    AIMOCAP_PT_capture_panel,
    AIMOCAP_PT_armature_panel,
    AIMOCAP_PT_face_panel,
    AIMOCAP_PT_hands_panel,
    AIMOCAP_PT_model_panel,
    AIMOCAP_PT_multicam_panel,
    AIMOCAP_PT_multiperson_panel,
    AIMOCAP_PT_batch_panel,
    AIMOCAP_PT_takes_panel,
    AIMOCAP_PT_processing_panel,
    AIMOCAP_PT_export_panel,
    AIMOCAP_PT_streaming_panel,
    AIMOCAP_PT_settings_panel,
]
