"""
AI Mocap Studio - Viewport overlay drawing for landmarks (body, hands, face).
"""

import bpy
import gpu
import threading
from gpu_extras.batch import batch_for_shader

from ..core.constants import (
    POSE_CONNECTIONS, HAND_CONNECTIONS,
    FACE_OVAL_INDICES, LEFT_EYE_INDICES, RIGHT_EYE_INDICES,
    LIPS_OUTER_INDICES, LIPS_INNER_INDICES,
    COLOR_BONE, COLOR_JOINT, COLOR_CONFIDENCE_LOW,
    COLOR_HAND_BONE, COLOR_HAND_JOINT,
    COLOR_FACE_POINT, COLOR_FACE_MESH,
)

# Thread lock for _draw_data
_draw_lock = threading.Lock()


def _get_builtin_shader():
    """Get the uniform color shader, compatible with Blender 3.x and 4.x."""
    try:
        return gpu.shader.from_builtin('UNIFORM_COLOR')
    except ValueError:
        return gpu.shader.from_builtin('3D_UNIFORM_COLOR')


# Global state for draw handler
_draw_handler = None
_draw_data = {
    "body_positions": [],
    "body_confidences": [],
    "left_hand_positions": [],
    "right_hand_positions": [],
    "face_positions": [],
    "enabled": False,
    "scale": 1.0,
    # Legacy compat
    "positions": [],
    "confidences": [],
}


def update_draw_data(positions, confidences=None, scale=1.0):
    """Update body draw data (legacy/body-only API)."""
    with _draw_lock:
        _draw_data["positions"] = positions
        _draw_data["body_positions"] = positions
        _draw_data["confidences"] = confidences or [1.0] * len(positions)
        _draw_data["body_confidences"] = _draw_data["confidences"]
        _draw_data["scale"] = scale


def update_holistic_draw_data(
    body_positions=None, body_confidences=None,
    left_hand_positions=None, right_hand_positions=None,
    face_positions=None, scale=1.0,
):
    """Update draw data for all tracking modalities."""
    with _draw_lock:
        _draw_data["body_positions"] = body_positions or []
        _draw_data["body_confidences"] = body_confidences or []
        _draw_data["left_hand_positions"] = left_hand_positions or []
        _draw_data["right_hand_positions"] = right_hand_positions or []
        _draw_data["face_positions"] = face_positions or []
        _draw_data["scale"] = scale
        # Legacy compat
        _draw_data["positions"] = _draw_data["body_positions"]
        _draw_data["confidences"] = _draw_data["body_confidences"]


def _draw_callback():
    """GPU draw callback for the 3D viewport."""
    if not _draw_data["enabled"]:
        return

    # Copy data under lock to avoid race with update threads
    with _draw_lock:
        body_pos = list(_draw_data["body_positions"])
        body_conf = list(_draw_data["body_confidences"])
        left_hand_pos = list(_draw_data["left_hand_positions"])
        right_hand_pos = list(_draw_data["right_hand_positions"])
        face_pos = list(_draw_data["face_positions"])
        draw_scale = _draw_data["scale"]

    has_any = body_pos or left_hand_pos or right_hand_pos or face_pos
    if not has_any:
        return

    shader = _get_builtin_shader()

    _draw_body(shader, body_pos, body_conf, draw_scale)
    _draw_hand(shader, left_hand_pos, draw_scale)
    _draw_hand(shader, right_hand_pos, draw_scale)
    _draw_face(shader, face_pos, draw_scale)

    # Reset state
    gpu.state.line_width_set(1.0)
    gpu.state.point_size_set(1.0)


def _draw_body(shader, positions, confidences, draw_scale):
    """Draw body skeleton."""
    if len(positions) < 33:
        return

    # Draw connections
    gpu.state.line_width_set(3.0)
    for start_idx, end_idx in POSE_CONNECTIONS:
        if start_idx >= len(positions) or end_idx >= len(positions):
            continue

        conf = min(
            confidences[start_idx] if start_idx < len(confidences) else 1.0,
            confidences[end_idx] if end_idx < len(confidences) else 1.0,
        )
        color = COLOR_CONFIDENCE_LOW if conf < 0.5 else COLOR_BONE

        batch = batch_for_shader(shader, 'LINES', {"pos": [positions[start_idx], positions[end_idx]]})
        shader.bind()
        shader.uniform_float("color", color)
        batch.draw(shader)

    # Draw joints
    gpu.state.point_size_set(8.0 * draw_scale)
    batch = batch_for_shader(shader, 'POINTS', {"pos": list(positions)})
    shader.bind()
    shader.uniform_float("color", COLOR_JOINT)
    batch.draw(shader)


def _draw_hand(shader, positions, draw_scale):
    """Draw a single hand skeleton."""
    if not positions or len(positions) < 21:
        return

    # Draw connections
    gpu.state.line_width_set(2.0)
    for start_idx, end_idx in HAND_CONNECTIONS:
        if start_idx >= len(positions) or end_idx >= len(positions):
            continue

        batch = batch_for_shader(shader, 'LINES', {"pos": [positions[start_idx], positions[end_idx]]})
        shader.bind()
        shader.uniform_float("color", COLOR_HAND_BONE)
        batch.draw(shader)

    # Draw joints
    gpu.state.point_size_set(5.0 * draw_scale)
    batch = batch_for_shader(shader, 'POINTS', {"pos": list(positions)})
    shader.bind()
    shader.uniform_float("color", COLOR_HAND_JOINT)
    batch.draw(shader)

    # Highlight fingertips
    tips = [positions[i] for i in (4, 8, 12, 16, 20) if i < len(positions)]
    if tips:
        gpu.state.point_size_set(8.0 * draw_scale)
        batch = batch_for_shader(shader, 'POINTS', {"pos": tips})
        shader.bind()
        shader.uniform_float("color", (1.0, 1.0, 0.2, 1.0))
        batch.draw(shader)


def _draw_face(shader, positions, draw_scale):
    """Draw face mesh contours."""
    if not positions or len(positions) < 468:
        return

    gpu.state.line_width_set(1.5)

    # Draw face contours
    contours = [
        (FACE_OVAL_INDICES, COLOR_FACE_MESH),
        (LEFT_EYE_INDICES, COLOR_FACE_POINT),
        (RIGHT_EYE_INDICES, COLOR_FACE_POINT),
        (LIPS_OUTER_INDICES, (1.0, 0.3, 0.3, 0.8)),
        (LIPS_INNER_INDICES, (1.0, 0.2, 0.2, 0.8)),
    ]

    for indices, color in contours:
        line_coords = []
        for i in range(len(indices) - 1):
            idx_a = indices[i]
            idx_b = indices[i + 1]
            if idx_a < len(positions) and idx_b < len(positions):
                line_coords.append(positions[idx_a])
                line_coords.append(positions[idx_b])

        if line_coords:
            batch = batch_for_shader(shader, 'LINES', {"pos": line_coords})
            shader.bind()
            shader.uniform_float("color", color)
            batch.draw(shader)

    # Draw key landmark points (eyes, nose, mouth corners, brows)
    key_indices = [
        1, 10, 152,  # nose, forehead, chin
        33, 133, 362, 263,  # eye corners
        61, 291,  # mouth corners
        13, 14,   # lips
        107, 70, 336, 300,  # brows
    ]

    key_points = [positions[i] for i in key_indices if i < len(positions)]
    if key_points:
        gpu.state.point_size_set(4.0 * draw_scale)
        batch = batch_for_shader(shader, 'POINTS', {"pos": key_points})
        shader.bind()
        shader.uniform_float("color", COLOR_FACE_POINT)
        batch.draw(shader)

    # Draw iris points if available (468-477)
    if len(positions) > 473:
        iris_points = [positions[468], positions[473]]
        gpu.state.point_size_set(6.0 * draw_scale)
        batch = batch_for_shader(shader, 'POINTS', {"pos": iris_points})
        shader.bind()
        shader.uniform_float("color", (0.2, 1.0, 1.0, 1.0))
        batch.draw(shader)


def enable_viewport_draw():
    """Register the draw handler for the 3D viewport."""
    global _draw_handler
    if _draw_handler is not None:
        return

    _draw_data["enabled"] = True
    _draw_handler = bpy.types.SpaceView3D.draw_handler_add(
        _draw_callback, (), 'WINDOW', 'POST_VIEW'
    )


def disable_viewport_draw():
    """Unregister the draw handler."""
    global _draw_handler
    _draw_data["enabled"] = False
    if _draw_handler is not None:
        bpy.types.SpaceView3D.draw_handler_remove(_draw_handler, 'WINDOW')
        _draw_handler = None
    _draw_data["body_positions"] = []
    _draw_data["body_confidences"] = []
    _draw_data["left_hand_positions"] = []
    _draw_data["right_hand_positions"] = []
    _draw_data["face_positions"] = []
    _draw_data["positions"] = []
    _draw_data["confidences"] = []


def is_draw_enabled():
    """Check if viewport drawing is enabled."""
    return _draw_handler is not None and _draw_data["enabled"]
