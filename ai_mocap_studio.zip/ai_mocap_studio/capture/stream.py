"""
AI Mocap Studio - Base stream interface for video capture.
"""

from abc import ABC, abstractmethod


class CaptureStream(ABC):
    """Abstract base class for video capture sources."""

    def __init__(self):
        self._is_open = False
        self._width = 0
        self._height = 0
        self._fps = 0

    @abstractmethod
    def open(self):
        """Open the capture source. Returns True on success."""
        pass

    @abstractmethod
    def read(self):
        """Read a frame. Returns (success, frame) tuple."""
        pass

    @abstractmethod
    def release(self):
        """Release the capture source."""
        pass

    @property
    def is_open(self):
        return self._is_open

    @property
    def width(self):
        return self._width

    @property
    def height(self):
        return self._height

    @property
    def fps(self):
        return self._fps

    def __enter__(self):
        self.open()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.release()
        return False
