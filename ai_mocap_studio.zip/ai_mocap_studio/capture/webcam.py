"""
AI Mocap Studio - Webcam capture.
"""

from .stream import CaptureStream


class WebcamCapture(CaptureStream):
    """Capture video from a webcam device."""

    def __init__(self, camera_index=0, width=1280, height=720, fps=30):
        super().__init__()
        self.camera_index = camera_index
        self._requested_width = width
        self._requested_height = height
        self._requested_fps = fps
        self._cap = None

    def open(self):
        import cv2
        self._cap = cv2.VideoCapture(self.camera_index)
        if not self._cap.isOpened():
            self._is_open = False
            return False

        self._cap.set(cv2.CAP_PROP_FRAME_WIDTH, self._requested_width)
        self._cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self._requested_height)
        self._cap.set(cv2.CAP_PROP_FPS, self._requested_fps)

        # Read actual values after setting
        self._width = int(self._cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        self._height = int(self._cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        self._fps = self._cap.get(cv2.CAP_PROP_FPS) or self._requested_fps

        self._is_open = True
        return True

    def read(self):
        if self._cap is None or not self._cap.isOpened():
            return False, None
        return self._cap.read()

    def release(self):
        if self._cap is not None:
            self._cap.release()
            self._cap = None
        self._is_open = False

    @property
    def frame_count(self):
        return -1  # Webcam has unlimited frames
