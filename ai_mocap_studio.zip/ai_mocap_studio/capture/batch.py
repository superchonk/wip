"""
AI Mocap Studio - Batch video processing.

Process multiple video files sequentially, creating a separate
take/action for each video. Supports progress reporting and cancellation.
"""

import os
from dataclasses import dataclass, field
from typing import List, Optional, Callable


@dataclass
class BatchItem:
    """A single item in the batch processing queue."""
    filepath: str
    filename: str = ""
    status: str = "pending"       # pending, processing, done, error, skipped
    frames_total: int = 0
    frames_processed: int = 0
    take_name: str = ""
    error_message: str = ""

    def __post_init__(self):
        if not self.filename:
            self.filename = os.path.basename(self.filepath)

    @property
    def progress(self):
        if self.frames_total == 0:
            return 0.0
        return self.frames_processed / self.frames_total


@dataclass
class BatchResult:
    """Result of batch processing."""
    total_files: int = 0
    processed: int = 0
    skipped: int = 0
    errors: int = 0
    total_frames: int = 0
    items: List[BatchItem] = field(default_factory=list)


class BatchProcessor:
    """
    Process multiple video files for motion capture.

    Usage:
        batch = BatchProcessor()
        batch.add_files(["/path/video1.mp4", "/path/video2.mp4"])
        batch.process_all(context, detector_factory, retargeter_factory)
    """

    VIDEO_EXTENSIONS = {'.mp4', '.avi', '.mov', '.mkv', '.webm', '.flv', '.wmv'}

    def __init__(self):
        self._queue: List[BatchItem] = []
        self._cancelled = False
        self._current_index = -1
        self._on_progress: Optional[Callable] = None
        self._on_item_complete: Optional[Callable] = None

    def add_file(self, filepath):
        """Add a single video file to the queue."""
        ext = os.path.splitext(filepath)[1].lower()
        if ext not in self.VIDEO_EXTENSIONS:
            return False
        if not os.path.exists(filepath):
            return False
        self._queue.append(BatchItem(filepath=filepath))
        return True

    def add_files(self, filepaths):
        """Add multiple files."""
        added = 0
        for fp in filepaths:
            if self.add_file(fp):
                added += 1
        return added

    def add_directory(self, directory, recursive=False):
        """Add all video files from a directory."""
        added = 0
        if recursive:
            for root, dirs, files in os.walk(directory):
                for f in sorted(files):
                    if self.add_file(os.path.join(root, f)):
                        added += 1
        else:
            for f in sorted(os.listdir(directory)):
                filepath = os.path.join(directory, f)
                if os.path.isfile(filepath) and self.add_file(filepath):
                    added += 1
        return added

    @property
    def queue(self) -> List[BatchItem]:
        return self._queue

    @property
    def total_items(self):
        return len(self._queue)

    @property
    def current_index(self):
        return self._current_index

    @property
    def is_cancelled(self):
        return self._cancelled

    def cancel(self):
        """Request cancellation of the batch."""
        self._cancelled = True

    def set_progress_callback(self, callback):
        """Set callback: callback(batch_item, overall_progress)."""
        self._on_progress = callback

    def set_item_complete_callback(self, callback):
        """Set callback: callback(batch_item)."""
        self._on_item_complete = callback

    def process_all(self, context, process_func):
        """
        Process all items in the queue.

        process_func: callable(context, batch_item) -> int (frames processed)
            Should handle opening video, detecting, retargeting, and creating take.
            Returns number of processed frames, or -1 on error.
        """
        self._cancelled = False
        result = BatchResult(total_files=len(self._queue))

        for i, item in enumerate(self._queue):
            if self._cancelled:
                item.status = "skipped"
                result.skipped += 1
                continue

            self._current_index = i
            item.status = "processing"

            try:
                frames = process_func(context, item)
                if frames >= 0:
                    item.frames_processed = frames
                    item.status = "done"
                    result.processed += 1
                    result.total_frames += frames
                else:
                    item.status = "error"
                    result.errors += 1
            except Exception as e:
                item.status = "error"
                item.error_message = str(e)
                result.errors += 1

            if self._on_item_complete:
                self._on_item_complete(item)

        result.items = self._queue
        self._current_index = -1
        return result

    def clear(self):
        """Clear the queue."""
        self._queue.clear()
        self._current_index = -1
        self._cancelled = False


def find_videos_in_directory(directory, recursive=False):
    """
    Find all video files in a directory.
    Returns: list of absolute file paths
    """
    video_exts = BatchProcessor.VIDEO_EXTENSIONS
    results = []

    if recursive:
        for root, dirs, files in os.walk(directory):
            for f in sorted(files):
                if os.path.splitext(f)[1].lower() in video_exts:
                    results.append(os.path.join(root, f))
    else:
        for f in sorted(os.listdir(directory)):
            filepath = os.path.join(directory, f)
            if os.path.isfile(filepath):
                if os.path.splitext(f)[1].lower() in video_exts:
                    results.append(filepath)

    return results
