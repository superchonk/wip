"""
AI Mocap Studio - Take management system.

Organizes capture sessions into named takes with metadata.
Each take corresponds to a Blender Action and stores capture info.
"""

import bpy
import json
import time
from dataclasses import dataclass, field, asdict
from typing import Dict, List, Optional


@dataclass
class TakeInfo:
    """Metadata for a capture take."""
    name: str
    action_name: str = ""
    armature_name: str = ""
    capture_mode: str = "BODY"
    frame_start: int = 1
    frame_end: int = 1
    frame_count: int = 0
    fps: float = 30.0
    timestamp: float = 0.0
    person_id: int = -1             # -1 = single person, 0+ = tracked person
    source: str = "webcam"          # "webcam", "video", "multicam", "batch"
    source_path: str = ""
    notes: str = ""

    def to_dict(self):
        return asdict(self)

    @classmethod
    def from_dict(cls, d):
        return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})


class TakeManager:
    """
    Manages capture takes.

    Takes are stored as custom properties on the Scene for persistence.
    Each take wraps a Blender Action assigned to an armature.
    """

    PROP_KEY = "aimocap_takes"

    def __init__(self):
        self._takes: Dict[str, TakeInfo] = {}

    def load_from_scene(self, scene):
        """Load takes from scene custom properties."""
        raw = scene.get(self.PROP_KEY, "{}")
        try:
            data = json.loads(raw)
            self._takes = {
                k: TakeInfo.from_dict(v) for k, v in data.items()
            }
        except (json.JSONDecodeError, TypeError):
            self._takes = {}

    def save_to_scene(self, scene):
        """Save takes to scene custom properties."""
        data = {k: v.to_dict() for k, v in self._takes.items()}
        scene[self.PROP_KEY] = json.dumps(data)

    # ------ Take operations ------

    def create_take(self, scene, armature_obj, name=None, capture_mode="BODY",
                    person_id=-1, source="webcam", source_path=""):
        """
        Create a new take with a fresh Action.

        Returns: TakeInfo
        """
        if name is None:
            name = self._generate_name(capture_mode)

        # Create Blender action
        action_name = f"AIMocap_{name}"
        action = bpy.data.actions.new(name=action_name)
        action.use_fake_user = True

        # Assign to armature
        if armature_obj and armature_obj.type == 'ARMATURE':
            if armature_obj.animation_data is None:
                armature_obj.animation_data_create()
            armature_obj.animation_data.action = action

        take = TakeInfo(
            name=name,
            action_name=action_name,
            armature_name=armature_obj.name if armature_obj else "",
            capture_mode=capture_mode,
            frame_start=scene.frame_start,
            frame_end=scene.frame_start,
            frame_count=0,
            fps=scene.render.fps,
            timestamp=time.time(),
            person_id=person_id,
            source=source,
            source_path=source_path,
        )

        self._takes[name] = take
        self.save_to_scene(scene)
        return take

    def finish_take(self, scene, name, frame_count):
        """Mark a take as finished and update its frame range."""
        take = self._takes.get(name)
        if take is None:
            return

        take.frame_count = frame_count
        take.frame_end = take.frame_start + frame_count - 1
        self.save_to_scene(scene)

    def delete_take(self, scene, name):
        """Delete a take and its associated Action."""
        take = self._takes.get(name)
        if take is None:
            return False

        # Remove the Blender action
        action = bpy.data.actions.get(take.action_name)
        if action:
            bpy.data.actions.remove(action)

        del self._takes[name]
        self.save_to_scene(scene)
        return True

    def rename_take(self, scene, old_name, new_name):
        """Rename a take and its Action."""
        take = self._takes.get(old_name)
        if take is None or new_name in self._takes:
            return False

        # Rename the action
        action = bpy.data.actions.get(take.action_name)
        if action:
            new_action_name = f"AIMocap_{new_name}"
            action.name = new_action_name
            take.action_name = new_action_name

        take.name = new_name
        self._takes[new_name] = take
        del self._takes[old_name]
        self.save_to_scene(scene)
        return True

    def get_take(self, name) -> Optional[TakeInfo]:
        return self._takes.get(name)

    def get_all_takes(self) -> List[TakeInfo]:
        """Get all takes sorted by timestamp."""
        return sorted(self._takes.values(), key=lambda t: t.timestamp)

    def get_takes_for_armature(self, armature_name) -> List[TakeInfo]:
        """Get takes associated with a specific armature."""
        return [
            t for t in self._takes.values()
            if t.armature_name == armature_name
        ]

    def activate_take(self, name, context):
        """
        Set the take's Action as active on its armature.
        Also sets the scene frame range.
        """
        take = self._takes.get(name)
        if take is None:
            return False

        armature = bpy.data.objects.get(take.armature_name)
        action = bpy.data.actions.get(take.action_name)

        if armature and action:
            if armature.animation_data is None:
                armature.animation_data_create()
            armature.animation_data.action = action
            context.scene.frame_start = take.frame_start
            context.scene.frame_end = take.frame_end
            return True

        return False

    def duplicate_take(self, scene, name):
        """Duplicate a take (copies the Action)."""
        take = self._takes.get(name)
        if take is None:
            return None

        action = bpy.data.actions.get(take.action_name)
        if action is None:
            return None

        new_name = self._generate_unique_name(name)
        new_action = action.copy()
        new_action.name = f"AIMocap_{new_name}"
        new_action.use_fake_user = True

        new_take = TakeInfo(
            name=new_name,
            action_name=new_action.name,
            armature_name=take.armature_name,
            capture_mode=take.capture_mode,
            frame_start=take.frame_start,
            frame_end=take.frame_end,
            frame_count=take.frame_count,
            fps=take.fps,
            timestamp=time.time(),
            person_id=take.person_id,
            source=take.source,
            source_path=take.source_path,
            notes=f"Copy of {name}",
        )

        self._takes[new_name] = new_take
        self.save_to_scene(scene)
        return new_take

    # ------ Helpers ------

    def _generate_name(self, capture_mode):
        """Generate a unique take name."""
        base = f"Take_{capture_mode}"
        return self._generate_unique_name(base)

    def _generate_unique_name(self, base):
        """Generate a unique name by appending number."""
        if base not in self._takes:
            return base
        i = 1
        while f"{base}_{i:03d}" in self._takes:
            i += 1
        return f"{base}_{i:03d}"

    @property
    def count(self):
        return len(self._takes)


# Singleton
_take_manager = None


def get_take_manager() -> TakeManager:
    global _take_manager
    if _take_manager is None:
        _take_manager = TakeManager()
    return _take_manager
