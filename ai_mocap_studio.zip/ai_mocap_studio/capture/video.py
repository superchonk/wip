"""
AI Mocap Studio - Video file capture.
"""

from .stream import CaptureStream


class VideoCapture(CaptureStream):
    """Capture video from a file."""

    def __init__(self, filepath):
        super().__init__()
        self.filepath = filepath
        self._cap = None
        self._frame_count = 0
        self._current_frame = 0

    def open(self):
        import cv2
        self._cap = cv2.VideoCapture(self.filepath)
        if not self._cap.isOpened():
            self._is_open = False
            return False

        self._width = int(self._cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        self._height = int(self._cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        self._fps = self._cap.get(cv2.CAP_PROP_FPS) or 30.0
        self._frame_count = int(self._cap.get(cv2.CAP_PROP_FRAME_COUNT))
        self._current_frame = 0

        self._is_open = True
        return True

    def read(self):
        if self._cap is None or not self._cap.isOpened():
            return False, None
        success, frame = self._cap.read()
        if success:
            self._current_frame += 1
        return success, frame

    def release(self):
        if self._cap is not None:
            self._cap.release()
            self._cap = None
        self._is_open = False

    def seek(self, frame_number):
        """Seek to a specific frame number."""
        if self._cap is not None:
            import cv2
            self._cap.set(cv2.CAP_PROP_POS_FRAMES, frame_number)
            self._current_frame = frame_number

    def reset(self):
        """Reset to the beginning of the video."""
        self.seek(0)

    @property
    def frame_count(self):
        return self._frame_count

    @property
    def current_frame(self):
        return self._current_frame

    @property
    def progress(self):
        """Return progress as a float 0.0 to 1.0."""
        if self._frame_count <= 0:
            return 0.0
        return self._current_frame / self._frame_count
